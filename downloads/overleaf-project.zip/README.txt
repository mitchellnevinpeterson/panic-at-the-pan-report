PANIC AT THE PAN - TEAM 12 REPORT

Upload the contents of this ZIP to a blank free Overleaf project. Set main.tex as the main document and compile with pdfLaTeX or XeLaTeX. No shell escape, paid service or external font is required. Compile code-listings.tex separately for the full integrated C/header appendix.

Team (alphabetical by surname): Samuel Kwasi Asiedu Awuah; Po-Yun Cheng; Mitch Nevin Peterson. All three contributed to game flow and integration; the contribution table records their respective work with equal formatting.

Current source: source/integrated-firmware, wire_management 0ffeea5175c98188fd3cb9563f022e43b71978c3. Repository-designated hardware-verified baseline: checked-off b8775301fabeb2aa1b48d9509523d2fc86319a38. Later changes are distinguished in the narrative. Source hashes and original reuse notices are preserved. Historical scaffold/prototype files remain separate.

Remaining inputs: demonstrated revision confirmation, as-built schematics, detailed mechanism dimensions, reused-part valuation and physical test records. See TEAM-INPUTS-NEEDED.txt. Parts-price subtotal $103.86 excluding tax/shipping; reused personal parts are not automatically exempt from market-value accounting.

Public website: https://mitchellnevinpeterson.github.io/panic-at-the-pan-report/
