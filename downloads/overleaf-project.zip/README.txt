PANIC AT THE PAN - TEAM 12 REPORT DRAFT, REVISION 2
Prepared November 23, 2026

OVERLEAF
1. New Project > Upload Project > choose the delivered ZIP.
2. Set main.tex as Main document; use pdfLaTeX and compile.
3. Edit settings.tex for names/prices and main.tex for the narrative.
4. Orange TEAM INPUT prompts identify remaining evidence or details.
5. Select code-listings.tex as Main document to compile the separate full source
   appendix; download that PDF, then switch back to main.tex.

Standard packages and supplied PDF/PNG/JPEG graphics only. No shell escape,
minted, custom font downloads, paid package or bibliography processor is needed.
The lengthy source appendix is separate to keep the narrative compilation light.
Both documents are compiled locally using Tectonic; Overleaf was not operated.

COURSE SUBMISSION FORMAT
The course requires an actual hosted stand-alone WEBSITE and submission of its
URL. This PDF/Overleaf draft does not replace that requirement.
Draft website URL: November 30, 2026, 4 p.m.
Peer review: December 1 in class; review submission by 11:30 a.m.
Final revised report: December 4, 2026, 5 p.m.

Full team names confirmed: Mitch Nevin Peterson; Po-Yun Cheng; Samuel Kwasi Asiedu Awuah.

WHAT CHANGED IN REVISION 2
- Finished-game account replaces outdated one-controller/stepper/pan-matrix story.
- Two controllers, green Start/red Stop, e-paper pan icons, servo sweep and two
  chained matrix assemblies recorded.
- All three members' contributions and reported successful/full-credit grading.
- $10 Gushers purchase: parts-price subtotal now $103.86; tax/shipping excluded.
- Individual pieces used because the dispenser could not fit a complete pouch.
- CAD rendering and final assembly photographs.
- Envelope 51 x 36.5 x 14 cm; 18 x 24 x 1/8 inch laser-cut wood stock.
- Checkpoint 2's newer two-controller circuit images replace the old appendix.
- Proposed UART2 3.3 V / 115200 8N1 link described with source qualification.

CODE STATUS
Po-Yun still needs to push the final flashed code, according to the team.
source/team-repository is the older b0ac9b1 scaffold, not the working grading code.
source/peripheral-prototype contains earlier display/sensor/audio development.
The final ingredients, recipe/scoring data, timing and message protocol cannot be
verified from those older sources. Main text identifies historical FSM pseudocode.
The code appendix prints the supplied snapshots with their existing attribution.
Neither source group is presented as a final integrated firmware release.

The peripheral snapshot draws from PIC32-Display-and-Ultrasonic/src and missing
source fallbacks in PIC32-Current-Code/src; source-manifest.json records origins.
The original firmware/hardware folders were not changed.

EVIDENCE
reference/checkpoint-1.pdf and checkpoint-2.pdf retain original supplied PDFs.
assets/cp2-*.pdf are raster schematic images extracted from checkpoint 2.
Earlier vector schematics and native KiCad remain in source/reference material.
The team reports full grading credit; no independent grading sheet was supplied.
No dimensions beyond those provided, trial counts, receipt values or final-code
behavior have been invented. Photographs demonstrate assembly, not timing.

The 51 cm envelope side exceeds the specification's 50 cm footprint side by 1 cm.
Actual reported dimensions are retained; full grading credit is not represented
as evidence of a dimensional waiver. Remaining mechanical details are prompted.

BUDGET
Samuel Kwasi Asiedu Awuah: $8.54 bearing item subtotal + $9.00 material = $17.54.
Jerry: $7.29 amplifier pack + $21.21 switches/buttons = $28.50.
Mitch: $10 Gushers, sensor five-pack $9.99, LCD $12.88, e-paper $24.95; speaker free.
Parts-price subtotal = $103.86, excluding tax/shipping. Bearing item cost is $8.54; the known $0.83 tax was removed. Other order amounts are used as supplied when no split is available.
The new hardware amounts are listing screenshots, not receipts. This is not the final course market-value BOM.
Other unlisted parts were lab-reclaimed or personal past-project stock with no new spending. Reused-part market values, exemption classification, pack allocation and refunds remain to reconcile.

KEY FILES
main.tex, settings.tex, main.pdf: editable narrative and compiled preview.
code-listings.tex / code-listings.pdf: complete supplied C/header source appendix.
TEAM-INPUTS-NEEDED.txt: updated list, including facts already recorded.
source-manifest.json: source hashes, origins and evidence provenance.
assets/: drawings, schematics, CAD rendering and resized assembly photos.
source/: unchanged historical source/hardware snapshots.
reference/: original checkpoint PDFs.

Preserve course/framework attribution. The repository flags checking course-author
terms before public hosting of copied framework/lab material. No new blanket
license is asserted here.
