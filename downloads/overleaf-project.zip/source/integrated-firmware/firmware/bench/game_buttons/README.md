# Final game: GameButtonsPIC1 + GameButtonsPIC2

This folder holds the final game firmware for both PICs. Behaviour follows
[final_game_spec.md](../../../final_game_spec.md).

**PIC1** runs:
- the game flow, through the ES services GameSM, IngredientSM, ScoreSM and CookSM;
- the LED score/timer strips and the E-ink pan;
- the joystick and spoon servo, and the treat servo.

**PIC2** runs:
- the MCP buttons, switches and lamps;
- the ultrasonic sensor;
- the LCD heat screen and the speaker.

The two PICs talk over UART2.

Everything builds, and the host tests pass. Commit b877530 (git tag `checked-off`) was verified on the built machine; the November 18 changes after it still need a hardware run.

## Program

1. With load power off, connect SNAP to **PIC2**. In MPLAB, select **GameButtonsPIC2**, then Clean and Build, then **Program Device**.
2. Move SNAP to **PIC1**, select **GameButtonsPIC1**, then Clean and Build, then **Program Device**.
3. Restore power with all ingredient switches **OFF** and the joystick centred.

## Boot checklist (debug UARTs at 115200 8N1; PIC1 TX16, PIC2 TX11)

| Board | Expect |
|---|---|
| PIC2 | `PIC2 PPS boot ... -> OK`, then the LCD draws PAN HEAT in about 2.5 s, then `PIC2 PPS init ... -> OK` |
| PIC2 | Status lines include `audio=OK`; background music plays |
| PIC1 | `[BOOT]` lines with servo routing `OK`; the treat moves to **closed** |
| Both | `Link: READY`; the **Start lamp** lights; the LCD sweeps with "WAITING FOR HEAT INPUTS" |

## Game checklist

1. **Start.** Press Start. The dish intro scrolls at 2× speed (about 7.8 s; 10 s for the stir-fry), then the dashboard shows 0 / 60. Each game's dish is random (never the same twice in a row): chicken fried rice, chicken and broccoli stir-fry or pasta aglio e olio. PIC1 prints `Dish n/3: ...` at each Start.
2. **Ingredients.** Each icon appears on the E-ink. Switches flipped together share one refresh.
   - Right ingredients add **+10**, wrong ones subtract 10 (the score never drops below 0). Fried rice: Vegetables wrong. Stir-fry: Carb wrong. Aglio e olio: Protein and Vegetables wrong.
3. **Heat.** After an ingredient, the LCD shows two band marks at that ingredient's target, and the label follows your hand: NOT ENOUGH, JUST RIGHT or TOO MUCH.
   - On target the score climbs about 1 point per second.
   - Holding TOO MUCH for 3 s shows **BURNT**, plays the buzz and costs **−10** once.
4. **Stirring.** The spoon follows the joystick left and right during cooking. Release returns it home.
   Each full joystick circle scores live: +1 up to the ingredient's ideal count (Protein 3, Carb 5, Spice 6), −1 for each circle beyond it (Vegetables and Oil: every circle −1). Press `j` on the PIC1 terminal to see `circles=`.
5. **Flip switch.** Each flip scores +2 up to the ingredient's ideal count (Protein 2, Carb 4, Vegetables 1, Spice 3), −2 for each flip beyond it (Oil: every flip −2).
   - The LCD's bottom line shows `STIRS n  FLIPS n` for the current ingredient; both restart at 0 with each new ingredient.
6. **Finish.** The Finish lamp lights at 30 s.
   - Press Finish: the top strip shows "GAME OVER" and the bottom strip shows the score.
   - At 60 s without Finish, it shows "TIME'S UP. GAME OVER".
7. **End.** Then the big score shows for 3 s.
   - The E-ink clears.
   - The treat releases if the score is ≥ 50.
   - Welcome returns. An open treat gate closes by itself 20 s after opening (`TREAT_OPEN_MS` in [Treat.h](Treat.h)), or sooner if Start is pressed.
8. **Idle timeout.** With no activity for 20 s, the game goes straight to Welcome with no treat.
   - Activity is ingredient switch ON/OFF, the flip switch, a hand within 40 cm, or a joystick push (held ≥ 150 ADC counts from rest for 100 ms) or completed stir circle; a resting stick's noise never counts. Press `j` to see `r=` (distance from rest) and `moves=` (activity count).

## Calibrate the treat and spoon

- **Treat** (PIC1 debug keyboard):
  - `o` moves to release, `c` moves to closed.
  - `+` / `-` nudge the last commanded position by 25 µs. Each key prints `TREAT closed=… release=… now=…`.
  - Write the final values into `TREAT_CLOSED_US` / `TREAT_RELEASE_US` in [Treat.h](Treat.h), then rebuild PIC1.
  - The treat servo holds its pulses while open; after closing, pulses stop 2.5 s later (`TREAT_DRIVE_MS`), so the MG995 cannot hunt at "closed" and flicker the displays. The `d` key prints the servo registers. With `o` they should read `OC2CON=8006 OC2R=5000 RPB5R=5`; if they do and the gate still doesn't move, check the hardware from pin 14 to the servo.
- **Spoon:** set `STIR_PULSE_MIN_US` / `STIR_PULSE_MAX_US` in [Stirrer.h](Stirrer.h). The target is about ±22.5°; home is `STIR_PULSE_CENTER_US`.

## Wiring added for the final game (physical DIP pins)

| Connection | Pins |
|---|---|
| Treat servo (MG995) | PIC1 pin14 / RB5 / OC2 → U2 input2 (remove its GND jumper, add a 10 kΩ pulldown) → U2 output18 → servo signal; servo power from the 5 V load rail |
| Spoon servo (S51) | PIC1 pin12 / RA4 / OC4 → U2 input17 → output3 → servo signal; **servo power from its own separate 5 V supply**, GND shared with the PICs |
| Joystick | VRx → PIC1 pin6, VRy → pin7, VCC 3.3 V, GND |
| Pan-flip limit switch | NO → MCP pin27 (GPA6) with 10 kΩ pull-up to 3.3 V; COM → GND; NC open |
| Ultrasonic | PIC2 TRIG6 (via U10 buffer), ECHO7 (via divider) |
| LCD | PIC2 MOSI14, SCK16, CS18 (10 kΩ pull-up), DC23, RST24 |
| Speaker | PIC2 pin26 → existing RC filter → PAM8302 A+ (A− to GND) |
| Reset (optional) | MCLR → 470 Ω → pushbutton → GND; for one button on both PICs, use a Schottky diode from each MCLR |

The earlier GameButtons wiring is unchanged:
- UART2 crossed between the PICs, with common GND;
- the score strips;
- the E-ink;
- MCP SPI, the ingredients, Start/Finish contacts and both lamp MOSFET circuits.

## Fault behaviour and diagnostics

- **Link glitch:** a brief link glitch resyncs within a 1.2 s grace period, and the round continues.
- **Link loss:** a longer link loss returns the game to Welcome (`RECOVER: ...`).
- **E-ink fault:** the pan display is disabled and the game continues.
- **Unrecoverable PIC1 fault:** PIC1 prints `FATAL: <reason>` and resets itself; the next boot prints the reason. After 3 quick repeats it stops and keeps printing `[HALT] repeated fault: <reason>`.
- **Status:** `s` on either debug UART prints status: link, lamps, CookSM output, spoon/treat, distance, UART error counters and PPS readback.

## If something misbehaves on hardware

- **Random crash** (spoon jerks, LED strips show garbage, at no fixed time): this was servo current dragging down the shared 5 V supply. The fix that worked was a **separate 5 V supply for the spoon servo**, with its GND tied to the common ground. PIC1's boot line `[BOOT] #N … reset cause` shows `BROWN-OUT` if a supply dip ever resets it again.

- **LCD garbled:** the faster LCD timing (`LCD_HALF_BIT_TICKS=8`) is untested on the panel.
  - Change it to `40` (the proven speed) in `.vscode/GameButtonsPIC2.mplab.json` and in `PIC2_CPPFLAGS` in the [Makefile](Makefile).
  - Reflash PIC2. Start-up drawing then takes about 9 s.
- **Silent speaker:** check that PIC2 status shows `audio=OK RPB15R=5`. If it does, check the amplifier wiring.
- **Rounds abort mid-game:** watch PIC1's `UART2 ... overrun= errors=` counters.

## Build and host tests

```sh
make -C firmware/bench/game_buttons all    # firmware/build/game_buttons/game_buttons_pic{1,2}.hex
make -C firmware/bench/game_buttons test
make -C firmware/tests/cook test; make -C firmware/tests/actuators test; make -C firmware/tests/heatview test
make -C firmware/pic2 test                 # link + PIC2 inputs
```
