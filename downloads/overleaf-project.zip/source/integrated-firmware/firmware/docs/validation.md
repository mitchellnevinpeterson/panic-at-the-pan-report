# Scaffold validation — 2026-11-07

`make -C firmware check` completed successfully on the development laptop with:

- MPLAB XC32 v6.00, target `32MX170F256B`.
- Microchip PIC32MX_DFP 1.7.380.
- GNU Make from the system toolchain.

All explicitly listed C sources compiled, the target ELF linked, and
`xc32-bin2hex` generated a HEX file. The provenance verifier checked all 34
preserved lab/framework files against their recorded SHA-256 values. No sibling
lab files were modified.

The compiler reported no warnings in the newly authored scaffold code. Preserved
sources reported warnings for unimplemented SPI API parameters/missing returns,
an unused display variable, a font bounds-expression precedence issue, an unused
SPI lookup table, and `#pragma mark` annotations. These remain visible and are
documented in the firmware README. The lab drivers are not called by the scaffold.

The first link exposed the runtime's heap requirement. The Makefile now reserves
1024 bytes of heap and 2048 bytes of stack; the subsequent link completed. These
are provisional build reservations, not measured memory requirements.

No device was flashed. No sensor, display, motor, queue-load, timing, or gameplay
test was performed. The build verifies structural/toolchain integration only.

## Timer/score design review — 2026-11-11

Independent **GPT-6 (`gpt-6-sol`), High reasoning** review: **pass for the countdown design and library organization**, after corrections. This is not a gameplay firmware or hardware validation.

- Confirmed 60 → 0 display behavior and separated the bench's +10/second demo from game scoring.
- Defined 60-second completion priority over a simultaneous idle timeout, timestamp-based Finish eligibility, and stale idle-event checks. The full FSM diagram and short contract agree.
- Clarified that a PIC reset replays the welcome banner; the bench's automatic repeat restarts only the counters.
- Verified all 40 recorded file hashes, including the six moved ADC/PWM sources and PDF guides. Both libraries remain outside active build source lists. The move also checked before/after hashes; the independent review checked the retained manifest.
- Still pending: gameplay handlers, timestamp/session transport, score payloads and final-stir ordering, stale scoring-event rejection, and extension from eight status MAX7219s to the ninth heat driver.

Review used source/document inspection, provenance verification and diff checks. No new gameplay build, flash or hardware test was performed.

[Reviewed timer/score contract](score_timer_state_machines.md).

### Top-down plan follow-up

The same GPT-6 High verifier reviewed the [GameSM-first overview](state_machine_overview.html), architecture and pin/interface TODOs. Final review found no remaining substantive documentation contradiction. Corrections clarified input-event ownership, the nonblocking display path, and the shared Timer2 setup needed by spoon OC4 and treat OC2. The first milestone remains an isolated GameSM test harness; no gameplay handlers or new hardware integration were implemented.

## Dedicated Start revision — 2026-11-11

GPT-6 High independently reviewed the repeating Welcome / Start-only entry contract, scaffold definitions and new input circuit; no remaining change-specific defect was found.

- `START_PRESSED`, `GAME_START`, 50 ms welcome-scroll timing and ES software timer 9 are reserved. IngredientSM initializes Locked; the button stub exposes Start.
- `make -C firmware check` passes, including all 40 preserved-file hashes. This checks scaffold compilation, not gameplay behavior.
- Independent KiCad export reports six sheets and zero ERC violations. All 191 connection checks pass. Start uses U11 GPA7/p28, 10 kΩ R37, SW27 and J26 (signal/GND); optional flip remains separate on GPA6.
- The refreshed input sheet was rendered and visually inspected. The complete-system SVG and top-down HTML were updated; document links and diff checks pass.

Runtime GameSM transitions, looping-banner mode, Start debounce/UART transport, timestamp/session encoding and physical validation remain pending. The standalone score/timer bench intentionally remains an automatic demo. No device was flashed.

## GameSM lifecycle bench — 2026-11-12

Independent **GPT-6 (`gpt-6-sol`), High reasoning** verifier: **pass for the isolated GameSM bench; no change-specific defect found**.

- XC32 6.00 / PIC32MX_DFP 1.7.380 release and SNAP debug builds pass. The verifier also forced both rebuilds and checked all four configuration words against the debug reservation.
- ASan/UBSan tests exercise the real GameSM: repeated Welcome, Start-only entry, 30-second Finish gate, 60-second completion, 20-second idle timeout, one treat request, 10/5-second holds, reset, queued/stale inputs, clock wrap and failure handling.
- Separate tests exercise the real BenchIO adapter: two 16-bit clock wraps, guarded UART reads/errors, batched dashboard fields, display failure and fault-post suppression.
- Existing display and joystick host tests pass. `make -C firmware check` passes and verifies all 40 preserved-file hashes; full-game hardware remains unconfigured.
- MPLAB JSON/fileset paths, single config-word owner, documentation links and diff whitespace checks pass. The prepared IDE project has not yet undergone an IDE-generated build.

The bench runs only GameSM, the status display and UART keyboard. Score stays 0; lamp, treat, pan and other-service outputs are explicit terminal stubs. UART timestamps capture foreground reads, not exact byte arrival. Physical button debounce, second-PIC timestamp/session transport and output integration remain TODO.

No device was flashed or new board behavior tested. Software tests cannot verify wiring or detect a disconnected MAX7219 chain.

[Run GameSMBench](../bench/game_sm/README.md).

## IngredientSM integration — 2026-11-12

Independent **GPT-6 (`gpt-6-sol`), High reasoning** verifier: **pass; no change-specific defect or current-document contradiction found**.

- GameSMBench now registers IngredientSM at priority 0 and GameSM at priority 1. Keys `1–5` post activity plus a timestamped ingredient switch; Start/End/Reset reach IngredientSM through checked queues.
- All four ASan/UBSan suites pass: GameSM, BenchIO, IngredientSM, and the real two-service integration. Cases include once-per-round acceptance, duplicate activity, Locked inputs, reset, stale inputs across Start/End, clock wrap, exact idle/game deadlines and partial-post/output failures.
- XC32 Make release and SNAP debug builds pass; the verifier independently forced both rebuilds. Full firmware checks pass, including all 40 preserved-file hashes.
- The actual MPLAB-generated default CMake build compiles IngredientSM and produces ELF/HEX. JSON source-list, documentation-link and whitespace checks pass. Regeneration/build of the separate MPLAB Production rules was not performed this turn.

No device was flashed or new ingredient behavior tested on hardware. Score stays 0. Physical switch debounce/rearm, MCP23S17, UART2 timestamps/sessions, and downstream Heat/Stir/Score/Pan integration remain TODO. Existing warnings come from preserved font/framework sources.

[Keyboard test steps](../bench/game_sm/README.md#ingredient-quick-check).

## ScoreSM and dish intro — 2026-11-12

Independent **GPT-6 (`gpt-6-sol`), High reasoning** verifier: **pass; no remaining change-specific defect found**.

- Start now runs one 15.6-second `YOUR DISH TODAY: chicken fried rice` scroll. Inputs stay locked and game/idle timers stay off. The full 60-second game and 20-second idle deadline begin at intro completion.
- ScoreSM adds the explicitly configured +10 bench points per new ingredient. Duplicate publications cannot score twice. Earned credit queued before End can drain during results using the playing-round ID; Reset clears internally without overwriting either banner.
- Five ASan/UBSan suites pass: GameSM, BenchIO, IngredientSM, ScoreSM and the real three-service integration. Tests cover intro timing/lockout, clock wrap, score/event ordering, duplicate protection, stale inputs, reset and failures.
- XC32 Make release/debug builds and the actual MPLAB-generated default build pass with ScoreSM included. The verifier forced both Make builds. Full firmware checks verify all 40 preserved-file hashes; source-list, document-link and whitespace checks pass.

No new image was flashed or tested on the board. Separate MPLAB Production rules still need regeneration when that configuration is used. Formal recipe membership/penalties, heat/burn/stir scoring, final-stir events, physical switches/MCP/UART2 and the full six-service integration remain TODO. Score accepts ingredient messages only from trusted IngredientSM acceptance, not raw input adapters.

[Run the updated bench](../bench/game_sm/README.md).

## E-ink standalone bench — 2026-11-13

Independent **GPT-6 (`gpt-6-sol`), High reasoning** verifier: **pass; no confirmed blocker in the standalone bench**.

- XC32 Make release and SNAP debug builds, plus the actual MPLAB-generated default build, pass. The verifier independently built both Make configurations. The separate MPLAB Production configuration was not exercised.
- ASan/UBSan tests cover the three controller profiles, upstream color-plane mapping, frame bounds, SPI/BUSY failures, latched faults, cooldown and clock wrap. Native-size previews rendered from the actual C frame were visually checked.
- Manual profile selection, approved ingredient masks, reviewed PIC1 pins and idle levels for connected auxiliary controls were checked. All 40 preserved lab/framework hashes still match.
- MPLAB source lists, JSON, documentation links and whitespace checks pass. Reference protocols are pinned to Adafruit_EPD revision `10d269c7134efcaad56ce6d5f52b5b9a6487577b`, with its license retained.

At the software-review stage, no device was flashed or physically tested. This synchronous bench is not integrated into GameSM and supports full refresh only.

### User hardware test — 2026-11-13

- The IL0373 / Z10 profile completed the test-pattern BUSY cycle with `Result: OK`. The user saw the I/II/III markers and checkerboard, then reported that the ingredient-icon display worked.
- User-observed refresh completion time: **approximately 3–5 seconds per refresh**. This is an approximate observation, not an instrumented measurement.
- Refresh duration is separate from the recommended interval between updates. The existing **180-second cooldown is unchanged**, including the manual wait across resets. Exact controller markings, separate color/orientation checks, supply measurements and operation at shorter update intervals remain unverified.

[Run EInkBench](../bench/eink/README.md).

## Joystick CW/CCW servo bench — 2026-11-13

Independent **GPT-6 (`gpt-6-sol`), High reasoning** verifier: **pass for the standalone bench; no confirmed firmware blocker**. The verifier independently ran the sanitizer suite and Make release/debug builds and checked the updated documentation, JSON and whitespace.

- JoystickServoBench now derives wrapped angular changes from both ADC axes. CW/CCW moves a relative servo target; endpoint saturation discards excess turns, and reversal cancels pending old-direction travel. Release returns home. Travel remains 1250–1750 us with a 10 us/20 ms slew limit.
- Initial centers were provisionally X=506, Y=320 from user readings; reported released Y fluctuated around 300–320. Both-axis arming, radial hysteresis, filtering and a 2-degree threshold reject small motion/noise. Physical axis signs and servo direction still need calibration.
- ASan/UBSan scenarios pass for both-axis startup, center/held-stick noise, CW/CCW gain, angular and clock wrap, hold/home, repeated endpoint saturation, reversal with pending motion, center crossings, axis inversion, bounded slew, invalid calibration and latched faults.
- XC32 Make release/SNAP debug and actual MPLAB-generated default/Production builds pass. Both build paths link the standard math library. No preserved lab/framework source was changed.

The user confirmed the previous X-only servo bench moved after enabling the external supply output. The new angular mode has not been flashed or tested on hardware by the agent. This change does not implement StirSM or alter GameSM; real mechanical travel, orientation, ADC stability and processing time remain board-test items.

[Run the angular servo bench](../bench/joystick_servo/README.md).

### Center calibration follow-up — 2026-11-13

The user saw CENTER with the joystick released at X=506, Y=240. The old Y=320 calibration rejected that pair, so an interim calibration used **506/240**. That regression reproduced the startup lock and verified the interim calibration could arm after 500 ms. Host ASan/UBSan, Make release/debug and MPLAB default/Production builds passed. This fixed-center workaround is superseded by the startup calibration below.

### Stable startup calibration — 2026-11-13

Independent **GPT-6 (`gpt-6-sol`), High reasoning** verifier: **pass for the standalone calibration change**. The verifier independently ran ASan/UBSan tests and reviewed startup gating, frozen centers, error handling, ADC sequencing and current documentation.

The user next reported Y=350 and clarified that released readings vary between boots but then stabilize. Startup now learns X/Y centers instead of requiring a hardcoded resting pair. Pulses remain disabled through 500 ms settling and a stable 1-second window; centers are frozen after activation. Calibration rejects the tested noisy, ramping and near-rail inputs, and times out after 8 seconds with CHECK XY. Release during startup is required; stable deflection or a stable floating input cannot be conclusively distinguished from rest in software.

- ASan/UBSan tests pass for boot centers 506/240, 506/320, 506/350 and 506/531 with the same firmware configuration, bounded noise, slow drift, rails, duplicate timestamps, timeout, frozen centers and the existing angular/servo scenarios.
- XC32 Make release/SNAP debug and actual MPLAB-generated default/Production builds pass. The independent verifier found no confirmed ADC channel/sequencing defect; JoystickADC and PWM drivers remain unchanged.
- No device was flashed by the agent. Calibrated angular motion, physical direction/travel and the cause of boot-to-boot Y variation remain unverified on hardware.

## X-only checkpoint fallback — 2026-11-13

Created **JoystickServoBench_2** at the user's request to restore the original position follower while deferring angular-control debugging. Only X controls arming and position; Y is diagnostic. Original center/deadband, 1250–1750 us travel, slew limit, display readings and existing wiring are retained. The angular bench and shared ADC/PWM sources are unchanged, checked by hashes.

Independent **GPT-6 High** focused review found no blocker. ASan/UBSan checks, XC32 Make release/SNAP debug and the actual MPLAB-generated default build pass. Tests explicitly cover Y=240/320/350 and other valid Y readings without blocking startup or changing motion. Source-list isolation, links and whitespace checks pass. Separate MPLAB Production generation was not exercised. No image was flashed; the recreated checkpoint image still requires the user's hardware run.

[Checkpoint run instructions](../bench/joystick_servo_2/README.md).

## Integrated two-controller firmware — 2026-11-15

Implemented by an Astra Extra High lead with two delegated Astra High agents. A separate **Astra High independent verifier** found and fixed one startup shutdown defect: GameIO could call an uninitialized peer clock after board/display initialization failed. Both failure paths now have passing sanitizer regressions. No further blocking software defect was found.

- `make -C firmware check` and `make -C firmware test` pass with XC32 6.00 / PIC32MX_DFP 1.7.380 and host ASan/UBSan. New application sources compile with warnings as errors; existing font/framework warnings remain unchanged.
- PIC1 and PIC2 release/SNAP debug builds pass. PIC1's optional `JOYSTICK_MODE=2 SPOON=1` variant also links. The integrated targets use Make; no new MPLAB project or production flash is claimed.
- Real six-service/GameIO/two-endpoint integration passes in default unconfigured mode and with a separate synthetic configured fixture. Covered: banner timing, unique ingredients, early/eligible Finish, 60-second completion, 20-second idle, one/no treat request, final scoring, heat/audio freshness, measured stir intervals, reset and link loss.
- E-ink asynchronous tests cover full IL0373 planes, BUSY/I/O faults, cooldown and wrap. Incremental rendering matches all 32 approved ingredient masks against the bench renderer. Physical e-ink is mocked/disabled in the complete-game host harness.
- Independent protocol probes additionally exercised controller reboot to epoch 1 while the sensor retained a newer epoch, and 65,540 input events across sequence wrap. Link/PIC2 tests cover CRC, ACK loss, retries, stale epochs, startup/release gating, debounce and echo failure paths.
- All 40 preserved lab/framework hashes and 48 saved bench/teammate file hashes match. The verifier also ran the four additional standalone bench test suites. No tested bench or teammate source was changed.

Default PIC1 static data/BSS is approximately 15.5 KiB, with 4 KiB stack and 1 KiB runtime heap reserved. Linker allocation is not a measured stack high-water mark.

No hardware was flashed. Formal tuning, mounted servo travel, ninth-driver heat output, dispenser mechanics, burnt-sound choice, combined UART/ADC/range/audio timing and supply behavior remain pending. E-ink retains its 180-second boot/refresh cooldown. Remote Finish timestamps use a conservative 20 ms allowance; scoring preserves awards processed before PIC1 receives End rather than retroactively truncating at the remote press time. See [current architecture](architecture.md) and [remaining decisions](pending_decisions.md).

## Final game images — 2026-11-17/18

- GameButtonsPIC1 and GameButtonsPIC2 ran on the built machine. Random crashes stopped once the spoon servo got its own 5 V supply (it had been dragging down the shared rail). The user then marked commit b877530 as the checked-off version (git tag `checked-off`).
- November 18 changes, one commit each after the tag:
  - the zone-change chime is removed (PIC2);
  - stirring is scored by full joystick circles;
  - the spoon is smoothed (median of 3, low-pass, 4 µs output hysteresis);
  - flip counts are per ingredient;
  - the treat gate stays open until the next game.
- Every commit passed all host ASan/UBSan suites and XC32 release and debug builds of both images before it was made. Mutation checks confirmed that the new stirrer tests fail when the median filter, the hysteresis, the centre reset or the sector-jump guard is removed.
- These changes have not yet been confirmed on hardware.
