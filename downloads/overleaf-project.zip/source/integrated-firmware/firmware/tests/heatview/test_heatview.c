/* Host test for firmware/pic2/HeatView.c against fake st7789 primitives that
 * paint a 320x240 framebuffer and charge each call its wire cost
 * (CASET 5 + RASET 5 + RAMWR 1 = 11 bytes, then 2 bytes per pixel, as st7789.c
 * sends them). The module is included so tests can read its tables. */
#include "../../pic2/HeatView.c"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static uint16_t fb[LCD_HEIGHT][LCD_WIDTH];
static uint16_t snap[LCD_HEIGHT][LCD_WIDTH];
static bool in_step;
static unsigned step_calls, step_bytes, max_step_bytes, failures, total_steps;

void display_spi_start(void) {}
bool display_spi_write(uint8_t value) { (void)value; return true; }
void st7789_prepare_pins(void) {}

static bool charge(unsigned x, unsigned y, unsigned w, unsigned h)
{
    if (x >= LCD_WIDTH || y >= LCD_HEIGHT || w == 0u || h == 0u || w > LCD_WIDTH - x || h > LCD_HEIGHT - y) {
        ++failures;
        return false;
    }
    if (in_step) {
        ++step_calls;
        step_bytes += 11u + 2u * w * h;
    }
    return true;
}

bool st7789_start(uint16_t background)
{
    for (unsigned y = 0; y < LCD_HEIGHT; ++y)
        for (unsigned x = 0; x < LCD_WIDTH; ++x) fb[y][x] = background;
    return true;
}

bool st7789_fill(unsigned x, unsigned y, unsigned w, unsigned h, uint16_t color)
{
    if (!charge(x, y, w, h)) return false;
    for (unsigned r = 0; r < h; ++r)
        for (unsigned c = 0; c < w; ++c) fb[y + r][x + c] = color;
    return true;
}

bool st7789_repeat_row(unsigned x, unsigned y, unsigned w, unsigned h, const uint16_t *pixels)
{
    if (!charge(x, y, w, h)) return false;
    for (unsigned r = 0; r < h; ++r)
        for (unsigned c = 0; c < w; ++c) fb[y + r][x + c] = pixels[c];
    return true;
}

bool st7789_draw_glyph(unsigned x, unsigned y, const uint8_t columns[5], unsigned scale,
                       uint16_t fg, uint16_t bg)
{
    if (scale > LCD_HEIGHT / 7u || !charge(x, y, 6u * scale, 7u * scale)) return false;
    for (unsigned r = 0; r < 7u * scale; ++r)
        for (unsigned c = 0; c < 6u * scale; ++c) {
            const unsigned col = c / scale;
            fb[y + r][x + c] = col < 5u && (columns[col] & (1u << (r / scale))) ? fg : bg;
        }
    return true;
}

/* ---- harness ---------------------------------------------------------- */

static bool step(void)
{
    step_calls = step_bytes = 0;
    in_step = true;
    const bool more = HeatView_Step();
    in_step = false;
    assert(step_calls <= 1u);
    assert(step_bytes <= HEATVIEW_STEP_MAX_BYTES);
    if (step_bytes > max_step_bytes) max_step_bytes = step_bytes;
    ++total_steps;
    return more;
}

static unsigned settle(void)
{
    unsigned n = 0;
    while (step()) {
        ++n;
        assert(n < 300u);
    }
    /* Converged: further steps send nothing. */
    assert(!step());
    assert(step_calls == 0u);
    return n + 1u;
}

/* An incremental result must equal a from-scratch draw of the same state. */
static void check_fresh(void)
{
    memcpy(snap, fb, sizeof fb);
    assert(HeatView_Start());
    assert(memcmp(snap, fb, sizeof fb) == 0);
}

static unsigned expected_fill_mm(unsigned mm)
{
    if (mm == 0u || mm >= 400u) return 0;
    if (mm <= 50u) return 260;
    return ((400u - mm) * 260u + 175u) / 350u;
}

static void check_bar(unsigned fill)
{
    for (unsigned c = 0; c < 260u; ++c)
        for (unsigned r = 0; r < 21u; ++r)
            assert(fb[143 + r][30 + c] == (c < fill ? heat_color(c) : TRACK));
    /* Border intact. */
    assert(fb[141][28] == BORDER && fb[165][291] == BORDER);
}

/* Decode one line of the label grid back into text using the font. */
static void decode_line(uint8_t layout, unsigned line, char *out, uint16_t *color)
{
    const unsigned s = layouts[layout].scale;
    *color = PANEL;
    for (unsigned c = 0; c < layouts[layout].cells; ++c) {
        const unsigned x0 = layouts[layout].x + 6u * s * c, y0 = layouts[layout].y[line];
        uint8_t cols[6] = {0};
        for (unsigned r = 0; r < 7u * s; ++r)
            for (unsigned px = 0; px < 6u * s; ++px) {
                const uint16_t v = fb[y0 + r][x0 + px];
                if (v == PANEL) continue;
                if (*color == PANEL) *color = v;
                assert(v == *color);
                cols[px / s] |= (uint8_t)(1u << (r / s));
            }
        assert(cols[5] == 0); /* spacing column blank */
        int found = -1;
        for (int g = 0; g < 27; ++g)
            if (memcmp(glyphs[g], cols, 5) == 0) found = g;
        assert(found >= 0);
        out[c] = found == 26 ? ' ' : (char)('A' + found);
        /* Every scaled pixel block must be uniform. */
        for (unsigned r = 0; r < 7u * s; ++r)
            for (unsigned px = 0; px < 6u * s; ++px) {
                const bool on = px / s < 5u && (glyphs[found][px / s] & (1u << (r / s)));
                assert((fb[y0 + r][x0 + px] != PANEL) == on);
            }
    }
    out[layouts[layout].cells] = '\0';
}

static void trim(char *s)
{
    size_t n = strlen(s), a = 0;
    while (n && s[n - 1] == ' ') s[--n] = '\0';
    while (s[a] == ' ') ++a;
    memmove(s, s + a, n - a + 1);
}

static bool in_layout(uint8_t layout, int x, int y)
{
    for (unsigned l = 0; l < layouts[layout].lines; ++l) {
        const Rect r = line_rect(layout, l);
        if (x >= r.x && x < r.x + r.w && y >= r.y && y < r.y + r.h) return true;
    }
    return false;
}

static void check_label(uint8_t layout, const char *line0, const char *line1, uint16_t color)
{
    char text[16];
    uint16_t seen;
    decode_line(layout, 0, text, &seen);
    trim(text);
    assert(strcmp(text, line0) == 0);
    assert(seen == color);
    if (line1) {
        decode_line(layout, 1, text, &seen);
        trim(text);
        assert(strcmp(text, line1) == 0);
        assert(seen == color);
    }
    /* The whole label strip between the icons is PANEL outside the grid. */
    for (int y = 92; y < 138; ++y)
        for (int x = 64; x < 256; ++x)
            if (!in_layout(layout, x, y)) assert(fb[y][x] == PANEL);
}

/* target_cm 0 = no marks. Checks the whole mark strip exactly. */
static void check_marks(unsigned target_cm)
{
    unsigned cool = 0, hot = 0;
    if (target_cm) {
        unsigned far = target_cm * 10u + 40u, near = target_cm * 10u - 40u;
        if (far > 400u) far = 400u;
        if (near < 50u || target_cm * 10u < 40u) near = 50u;
        cool = 30u + expected_fill_mm(far);
        hot = 30u + expected_fill_mm(near);
    }
    for (unsigned y = 166; y < 189; ++y)
        for (unsigned x = 12; x < 308; ++x) {
            uint16_t want = PANEL;
            if (target_cm && y >= 170 && y < 178) {
                if (x + 1u >= cool && x <= cool + 1u) want = ICE;
                else if (x + 1u >= hot && x <= hot + 1u) want = CORAL;
                else if (y >= 173 && y < 175 && x >= cool + 2u && x + 1u < hot) want = MINT;
            }
            assert(fb[y][x] == want);
        }
}

static void check_static_layout(void)
{
    assert(fb[0][0] == BACKGROUND && fb[74][160] == AMBER && fb[89][13] == PANEL);
    assert(fb[97 + 14][31 + 15] != PANEL); /* snowflake centre */
}

/* ---- tests ------------------------------------------------------------ */

static void test_glyphs(void)
{
    for (int a = 0; a < 37; ++a) {               /* letters and digits, all distinct */
        if (a == 26) continue;                   /* space */
        int bits = 0;
        for (int i = 0; i < 5; ++i) bits |= glyphs[a][i];
        assert(bits);
        for (int b = a + 1; b < 37; ++b) if (b != 26) assert(memcmp(glyphs[a], glyphs[b], 5) != 0);
    }
    assert(glyph_for('0') == glyphs[27] && glyph_for('9') == glyphs[36] && glyph_for('-') == glyphs[26]);
    for (int i = 0; i < 5; ++i) assert(glyphs[26][i] == 0);
    for (int l = 0; l < LBL_COUNT; ++l)
        for (unsigned line = 0; line < layouts[labels[l].layout].lines; ++line)
            assert(strlen(labels[l].text[line]) == layouts[labels[l].layout].cells);
}

static uint32_t now = 0;

static void test_attract(void)
{
    HeatView_Set(HEATVIEW_ATTRACT, 0, false, 0, 0, now);
    assert(HeatView_Start());
    assert(!step() && step_calls == 0u); /* Start drained everything */
    check_static_layout();
    check_bar(0);
    check_label(LAY_ATTRACT, "WAITING FOR", "HEAT INPUTS", MUTED);
    check_marks(0);
    /* Sweep follows now_ms: 400 -> 50 -> 400 mm, 5 mm per 100 ms. */
    unsigned prev = 0;
    for (now = 0; now <= 14000u; now += 100u) {
        const unsigned k = (now / 100u) % 140u;
        const unsigned mm = k <= 70u ? 400u - 5u * k : 50u + 5u * (k - 70u);
        HeatView_Set(HEATVIEW_ATTRACT, 0, false, 0, 0, now);
        /* Typical main-loop pace: a couple of steps per 100 ms keeps up. */
        settle();
        check_bar(expected_fill_mm(mm));
        if (now == 3500u) assert(expected_fill_mm(mm) == 130u);
        if (now == 7000u) assert(expected_fill_mm(mm) == 260u);
        if (now > 0u && now <= 7000u) assert(expected_fill_mm(mm) >= prev);
        prev = expected_fill_mm(mm);
    }
    /* Same 100 ms slot: nothing to do. */
    HeatView_Set(HEATVIEW_ATTRACT, 0, false, 0, 0, now - 50u); /* last Set was now-100 */
    assert(!step() && step_calls == 0u);
    check_label(LAY_ATTRACT, "WAITING FOR", "HEAT INPUTS", MUTED);
    check_fresh();
}

static unsigned set_and_settle(HeatViewMode m, uint8_t zone, bool burnt, uint8_t target, uint16_t mm)
{
    now += 100u;
    HeatView_Set(m, zone, burnt, target, mm, now);
    return settle();
}

static void test_waiting_and_smoothing(void)
{
    unsigned n = set_and_settle(HEATVIEW_WAITING, 0, false, 0, 0);
    printf("ATTRACT -> WAITING label change: %u steps\n", n);
    check_bar(0);
    check_label(LAY_ODD, "WAITING", NULL, MUTED);
    check_marks(0);
    /* First reading jumps straight to the sample. */
    set_and_settle(HEATVIEW_WAITING, 0, false, 0, 200);
    check_bar(expected_fill_mm(200));
    /* Then the heat_lcd filter: (2*old + new) / 3 per ~100 ms sample. */
    uint32_t q8 = 200u * 256u;
    const uint16_t samples[] = {100, 100, 100, 350, 30, 450};
    for (unsigned i = 0; i < 6u; ++i) {
        set_and_settle(HEATVIEW_WAITING, 0, false, 0, samples[i]);
        const uint32_t s = (samples[i] < 50u ? 50u : samples[i] > 400u ? 400u : samples[i]) * 256u;
        q8 = (2u * q8 + s + 1u) / 3u;
        check_bar(fill_at_q8(q8));
    }
    /* Calling Set again within 100 ms does not filter again. */
    const unsigned before = shown_fill;
    HeatView_Set(HEATVIEW_WAITING, 0, false, 0, 50, now + 10u);
    HeatView_Set(HEATVIEW_WAITING, 0, false, 0, 50, now + 20u);
    assert(!step() && step_calls == 0u && shown_fill == before);
    /* No hand empties the bar at once. */
    set_and_settle(HEATVIEW_WAITING, 0, false, 0, 0);
    check_bar(0);
    check_label(LAY_ODD, "WAITING", NULL, MUTED);
    check_fresh();
}

static void test_zone(void)
{
    unsigned n = set_and_settle(HEATVIEW_ZONE, 1, false, 14, 250);
    printf("WAITING -> NOT ENOUGH + marks: %u steps\n", n);
    check_bar(expected_fill_mm(250));
    check_label(LAY_EVEN, "NOT ENOUGH", NULL, ICE);
    check_marks(14);
    check_fresh();
    set_and_settle(HEATVIEW_ZONE, 2, false, 14, 140);
    check_label(LAY_EVEN, "JUST RIGHT", NULL, MINT);
    check_marks(14);
    set_and_settle(HEATVIEW_ZONE, 3, false, 14, 80);
    check_label(LAY_EVEN, "TOO MUCH", NULL, CORAL);
    set_and_settle(HEATVIEW_ZONE, 3, true, 14, 80);
    check_label(LAY_ODD, "BURNT", NULL, AMBER);
    check_marks(14);
    check_fresh();
    /* Next ingredient: burn clears, target moves; old marks gone. */
    set_and_settle(HEATVIEW_ZONE, 1, false, 24, 380);
    check_label(LAY_EVEN, "NOT ENOUGH", NULL, ICE);
    check_marks(24);
    check_fresh();
    const uint8_t targets[] = {32, 28, 10, 14, 24};
    for (unsigned i = 0; i < 5u; ++i) {
        set_and_settle(HEATVIEW_ZONE, 2, false, targets[i], (uint16_t)(targets[i] * 10u));
        check_marks(targets[i]);
        check_label(LAY_EVEN, "JUST RIGHT", NULL, MINT);
    }
    /* Zone 0 (none) reads WAITING; ZONE -> WAITING removes the marks. */
    set_and_settle(HEATVIEW_ZONE, 0, false, 24, 300);
    check_label(LAY_ODD, "WAITING", NULL, MUTED);
    check_marks(24);
    set_and_settle(HEATVIEW_WAITING, 0, false, 0, 300);
    check_marks(0);
    set_and_settle(HEATVIEW_ZONE, 2, false, 24, 240);
    check_marks(24);
    /* Back to attract: marks erased, two-line label. */
    now += 100u;
    HeatView_Set(HEATVIEW_ATTRACT, 0, false, 0, 0, now);
    n = settle();
    printf("ZONE -> ATTRACT: %u steps\n", n);
    check_label(LAY_ATTRACT, "WAITING FOR", "HEAT INPUTS", MUTED);
    check_marks(0);
    check_fresh();
}

static void test_no_work_when_unchanged(void)
{
    set_and_settle(HEATVIEW_ZONE, 2, false, 24, 240);
    for (int i = 0; i < 5; ++i) {
        now += 100u;
        HeatView_Set(HEATVIEW_ZONE, 2, false, 24, 240, now); /* filter at steady state */
        assert(!step() && step_calls == 0u);
    }
}

static uint32_t rng = 12345u;
static unsigned rnd(unsigned n)
{
    rng = rng * 1103515245u + 12345u;
    return (rng >> 16) % n;
}

/* Every pair of labels, with the bar steady and with the bar swinging fully. */
static void test_label_pairs(void)
{
    const struct { HeatViewMode m; uint8_t zone; bool burnt; } st[LBL_COUNT] = {
        [LBL_ATTRACT] = {HEATVIEW_ATTRACT, 0, false}, [LBL_WAITING] = {HEATVIEW_WAITING, 0, false},
        [LBL_LOW] = {HEATVIEW_ZONE, 1, false}, [LBL_RIGHT] = {HEATVIEW_ZONE, 2, false},
        [LBL_HIGH] = {HEATVIEW_ZONE, 3, false}, [LBL_BURNT] = {HEATVIEW_ZONE, 3, true}
    };
    unsigned worst_label = 0, worst_total = 0, worst_bar_gap = 0, matrix[LBL_COUNT][LBL_COUNT] = {{0}};
    int wa = 0, wb = 0;
    for (int a = 0; a < LBL_COUNT; ++a)
        for (int b = 0; b < LBL_COUNT; ++b) {
            if (a == b) continue;
            /* Steady bar: count pure label (+marks) steps. ATTRACT at a fixed
             * time has a fixed fill; pick the live distance with the same fill. */
            now = 3500u; /* attract fill 130 == 225 mm live */
            HeatView_Set(st[a].m, st[a].zone, st[a].burnt, 24, 0, now); /* reset filter */
            HeatView_Set(st[a].m, st[a].zone, st[a].burnt, 24, 225, now);
            settle();
            now = 3550u;
            HeatView_Set(st[b].m, st[b].zone, st[b].burnt, 24, 225, now);
            unsigned label_steps = 0;
            while (step()) ++label_steps;
            ++label_steps;
            matrix[a][b] = label_steps;
            /* Only label work if both show marks or both don't. */
            if ((st[a].m == HEATVIEW_ZONE) == (st[b].m == HEATVIEW_ZONE) && label_steps > worst_label) {
                worst_label = label_steps;
                wa = a;
                wb = b;
            }
            /* Swinging bar at the same time: bar gets every other step. */
            now = 0u; /* attract fill 0, live 0 mm */
            HeatView_Set(st[a].m, st[a].zone, st[a].burnt, 24, 0, now);
            settle();
            HeatView_Set(st[b].m, st[b].zone, st[b].burnt, 24, 50, now + 7000u);
            unsigned total = 0, gap = 0;
            unsigned last_fill = shown_fill;
            bool more = true;
            while (more) {
                more = step();
                ++total;
                if (shown_fill != last_fill || shown_fill == want_fill) gap = 0;
                else if (++gap > worst_bar_gap) worst_bar_gap = gap;
                last_fill = shown_fill;
                assert(total < 300u);
            }
            if (total > worst_total) worst_total = total;
            check_bar(260);
            check_fresh();
        }
    printf("worst full label change (marks unchanged): %u steps (%s -> %s)\n", worst_label,
           labels[wa].text[0], labels[wb].text[0]);
    printf("label change steps, bar steady (rows from, cols to: ATTRACT WAITING LOW RIGHT HIGH BURNT; incl. mark add/erase):\n");
    for (int a = 0; a < LBL_COUNT; ++a) {
        for (int b = 0; b < LBL_COUNT; ++b) printf(" %3u", matrix[a][b]);
        printf("\n");
    }
    printf("worst label change + full bar swing: %u steps; bar idle at most %u consecutive steps\n",
           worst_total, worst_bar_gap);
    assert(worst_bar_gap <= 1u);
}

/* Random states and random partial progress; final glass must equal a fresh draw. */
static void test_fuzz(void)
{
    for (int round = 0; round < 3000; ++round) {
        const HeatViewMode m = (HeatViewMode)rnd(3);
        const uint8_t zone = (uint8_t)rnd(4), target = (uint8_t)(rnd(5) ? 10u + rnd(23) : 0u);
        const bool burnt = rnd(4) == 0;
        const uint16_t mm = (uint16_t)(rnd(6) == 0 ? 0u : rnd(500));
        now += rnd(250);
        HeatView_Set(m, zone, burnt, target, mm, now);
        const unsigned steps = rnd(8);
        for (unsigned i = 0; i < steps; ++i) step();
        if (round % 50 == 49) {
            settle();
            check_fresh();
            if (m == HEATVIEW_ZONE && target) check_marks(target);
            else check_marks(0);
        }
    }
}

/* Read the bottom counter line back off the glass: names MUTED, digits WHITE. */
static void decode_counts(char out[COUNT_GROUPS][COUNT_CELLS + 1])
{
    const unsigned s = COUNT_SCALE;
    for (unsigned g = 0; g < COUNT_GROUPS; ++g) {
        for (unsigned c = 0; c < COUNT_CELLS; ++c) {
            const unsigned x0 = count_x[g] + 6u * s * c;
            const uint16_t want_color = c < COUNT_NAME ? MUTED : WHITE;
            uint8_t cols[6] = {0};
            for (unsigned r = 0; r < 7u * s; ++r)
                for (unsigned px = 0; px < 6u * s; ++px) {
                    const uint16_t v = fb[COUNT_Y + r][x0 + px];
                    if (v == BACKGROUND) continue;
                    assert(v == want_color);
                    cols[px / s] |= (uint8_t)(1u << (r / s));
                }
            assert(cols[5] == 0);
            int found = -1;
            for (int k = 0; k < 37; ++k)
                if (memcmp(glyphs[k], cols, 5) == 0) found = k;
            assert(found >= 0);
            out[g][c] = found == 26 ? ' ' : found < 26 ? (char)('A' + found) : (char)('0' + found - 27);
        }
        out[g][COUNT_CELLS] = '\0';
    }
}

static void check_counts(const char *stirs, const char *flips)
{
    char got[COUNT_GROUPS][COUNT_CELLS + 1];
    decode_counts(got);
    assert(strcmp(got[0], stirs) == 0 && strcmp(got[1], flips) == 0);
}

static void test_counts(void)
{
    HeatView_SetCounts(3, 2);
    set_and_settle(HEATVIEW_ATTRACT, 0, false, 0, 0);
    check_counts("        ", "        ");          /* Welcome / end: blank */
    HeatView_SetCounts(0, 0);
    set_and_settle(HEATVIEW_WAITING, 0, false, 0, 0);
    check_counts("STIRS 0 ", "FLIPS 0 ");          /* empty pan: zeros */
    HeatView_SetCounts(3, 12);
    set_and_settle(HEATVIEW_ZONE, 2, false, 14, 140);
    check_counts("STIRS 3 ", "FLIPS 12");
    /* Only changed cells are redrawn: 3 -> 4 is one glyph, 12 -> 7 is two. */
    HeatView_SetCounts(4, 12);
    assert(settle() == 1u);
    check_counts("STIRS 4 ", "FLIPS 12");
    HeatView_SetCounts(4, 7);
    assert(settle() == 2u);
    check_counts("STIRS 4 ", "FLIPS 7 ");
    HeatView_SetCounts(4, 7);
    assert(settle() == 1u && step_calls == 0u);   /* nothing to draw */
    HeatView_SetCounts(150, 99);
    settle();
    check_counts("STIRS 99", "FLIPS 99");          /* shown up to 99 */
    check_fresh();                                 /* incremental == fresh draw */
    check_label(LAY_EVEN, "JUST RIGHT", NULL, MINT);
    set_and_settle(HEATVIEW_ATTRACT, 0, false, 0, 0);
    check_counts("        ", "        ");
    check_fresh();
    HeatView_SetCounts(0, 0);
    puts("HeatView counters: blank in attract, STIRS/FLIPS while cooking, only changed cells redrawn");
}

int main(void)
{
    test_glyphs();
    test_attract();
    test_waiting_and_smoothing();
    test_zone();
    test_no_work_when_unchanged();
    test_label_pairs();
    test_counts();
    test_fuzz();
    assert(failures == 0u);
    printf("per-primitive costs: bar run %u B, glyph x3 %u B, glyph x2 %u B, band <= %u B\n",
           11u + 2u * BAR_RUN * BAR_HEIGHT, 11u + 2u * 18u * 21u, 11u + 2u * 12u * 14u,
           11u + 2u * MAX_PIXELS);
    printf("HeatView passed: %u steps checked, max %u bytes per step (budget %u).\n",
           total_steps, max_step_bytes, (unsigned)HEATVIEW_STEP_MAX_BYTES);
    return 0;
}
