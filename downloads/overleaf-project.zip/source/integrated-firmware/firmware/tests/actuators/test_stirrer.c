#include "fake_actuators.h"
#include "Stirrer.h"
#include "Servo50Hz.h"
#include <math.h>

#define S fake_servo[SERVO_SPOON]
static uint32_t now;

/* One main-loop pass per ms, the way pic1_main calls Stirrer_Service. */
static void run(uint32_t ms, bool cooking)
{
    for (uint32_t end = now + ms; now != end; ++now) {
        Stirrer_Service(now, cooking);
        CHECK(S.pulse_us >= STIR_PULSE_MIN_US && S.pulse_us <= STIR_PULSE_MAX_US);
        CHECK(S.pulse_us == Stirrer_PulseUs());
    }
}

static void at(int cx, int cy, double deg, int r)
{
    fake_x = (uint16_t)(cx + (int)lround(r * cos(deg * M_PI / 180.0)));
    fake_y = (uint16_t)(cy + (int)lround(r * sin(deg * M_PI / 180.0)));
}

/* This bench stick rests near X=330: learn it, arm around it, follow X. */
static void test_learned_centre_and_follow(void)
{
    now = 100;
    fake_x = 330; fake_y = 500;
    Stirrer_Init(now);
    CHECK(S.pulsing && S.pulse_us == STIR_PULSE_CENTER_US && fake_adc_inits == 1);
    run(1000, false);                       /* learn (0.3 s still) + arm (0.5 s centred) */
    CHECK(fake_adc_samples >= 90);
    CHECK(!Stirrer_OffCentre());            /* resting at 330 is NOT stirring */
    fake_x = 1023;
    run(1000, false);                       /* not cooking: home regardless of X */
    CHECK(S.pulse_us == STIR_PULSE_CENTER_US);
    fake_x = 330;
    run(700, false);
    fake_x = 1023;
    uint16_t last = S.pulse_us;
    for (int i = 0; i < 40; ++i) {          /* slew <= 10 us per 20 ms */
        run(20, true);
        CHECK(S.pulse_us >= last && S.pulse_us - last <= 10u);
        last = S.pulse_us;
    }
    CHECK(S.pulse_us == STIR_PULSE_MAX_US);
    fake_x = 0;
    run(1200, true);                        /* 500 us at 10 us/20 ms + filter lag */
    CHECK(S.pulse_us == STIR_PULSE_MIN_US);
    run(1, false);                          /* cooking ends: home now */
    CHECK(S.pulse_us == STIR_PULSE_CENTER_US);
    fake_x = 330;
    run(1000, true);
    CHECK(S.pulse_us == STIR_PULSE_CENTER_US);
}

/* Rest 330, but one side only reaches 651 (e.g. a stick supplied below 3.3 V).
 * Each side must still reach its full spoon travel at its own end. */
static void test_asymmetric_range(void)
{
    now = 10000;
    fake_x = 330; fake_y = 500;
    Stirrer_Init(now);
    run(1000, false);
    fake_x = 651;
    run(1500, true);                        /* slew 250 us at 10 us / 20 ms */
    CHECK(S.pulse_us == STIR_PULSE_MAX_US);
    fake_x = 0;
    run(1500, true);
    CHECK(S.pulse_us == STIR_PULSE_MIN_US);
    fake_x = 510;                           /* about halfway across 370..651 */
    run(1500, true);
    CHECK(S.pulse_us > STIR_PULSE_CENTER_US + 80u && S.pulse_us < STIR_PULSE_MAX_US - 80u);
    fake_x = 330;
    run(1500, true);
    CHECK(S.pulse_us == STIR_PULSE_CENTER_US);
}

/* Activity = a push (>= 150 counts from rest for 100 ms straight, re-armed
 * back within 100) or a completed stir circle. */
static void test_motion(void)
{
    now = 20000;
    fake_x = 330; fake_y = 500;
    Stirrer_Init(now);
    run(1000, false);
    (void)Stirrer_TakeActivity();
    CHECK(!Stirrer_OffCentre() && !Stirrer_TakeActivity());
    /* Push right and hold: one event after ~100 ms, none while held. */
    fake_x = 600;
    run(60, true);
    CHECK(!Stirrer_TakeActivity());
    run(100, true);
    CHECK(Stirrer_TakeActivity() && Stirrer_OffCentre());
    run(2000, true);
    CHECK(!Stirrer_TakeActivity() && !Stirrer_OffCentre());
    /* Wiggling while still pushed does not count again. */
    fake_x = 700; run(300, true);
    fake_x = 550; run(300, true);
    CHECK(!Stirrer_TakeActivity());
    /* Returning to rest is not a push; the next push counts. */
    fake_x = 330; run(100, true);
    CHECK(!Stirrer_TakeActivity());
    fake_x = 60; run(200, true);
    CHECK(Stirrer_TakeActivity());
    /* Side to side through the centre: every push counts. */
    unsigned pushes = 0;
    for (int i = 0; i < 3; ++i) {
        fake_x = 330; run(50, true); fake_x = 600; run(300, true); pushes += Stirrer_TakeActivity();
        fake_x = 330; run(50, true); fake_x = 60; run(300, true); pushes += Stirrer_TakeActivity();
    }
    CHECK(pushes == 6);
    /* A 50 ms excursion (a glitch) is not a push. */
    fake_x = 330; run(300, true); (void)Stirrer_TakeActivity();
    fake_x = 600; run(50, true);
    fake_x = 330; run(300, true);
    CHECK(!Stirrer_TakeActivity());
    /* Small circles (radius 100, never a push): each completed circle counts. */
    unsigned events = 0;
    for (int deg = 0; deg <= 720; deg += 10) { at(330, 500, deg, 100); run(30, true); events += Stirrer_TakeActivity(); }
    CHECK(events == 2);
    /* Big circles (radius 200): one push, then one event per circle. */
    fake_x = 330; fake_y = 500; run(300, true); (void)Stirrer_TakeActivity();
    events = 0;
    for (int deg = 0; deg <= 720; deg += 10) { at(330, 500, deg, 200); run(30, true); events += Stirrer_TakeActivity(); }
    CHECK(events == 3);
    /* +/-30 counts of jitter around a resting stick is never activity. */
    fake_x = 330; fake_y = 500; run(400, true); (void)Stirrer_TakeActivity();
    for (int i = 0; i < 100; ++i) { fake_x = (uint16_t)(330 + (i & 1 ? 30 : -30)); run(20, true); }
    CHECK(!Stirrer_TakeActivity());
    /* A slow creep (60 counts over 6 s) is drift, not activity. */
    for (int i = 0; i <= 60; ++i) { fake_x = (uint16_t)(330 + i); run(100, true); }
    CHECK(!Stirrer_TakeActivity());
    /* Stale samples stop "moving". */
    fake_x = 600; run(200, true);
    fake_adc_stall = true;
    run(350, true);
    CHECK(!Stirrer_OffCentre());
    fake_adc_stall = false;
    fake_x = 330;
    run(500, true);
}

/* Field bug (Nov 18): a stick resting about 55-60 counts from its learned
 * centre, plus ADC noise, kept flipping across the centre-zone edge; every
 * flip was "activity", so games never timed out. A resting stick, anywhere,
 * with noise and slow drift, must give no activity at all. */
static void test_resting_noise(void)
{
    static const int offsets[] = {0, 40, 55, 58, 60, 62, 65, 120};
    /* Noise, plus a glitch case: every other sample jumps +200 counts, which a
     * median of 3 cannot remove (2 of every 3 samples can be bad). */
    static const int noise[] = {8, 20, 8};
    static const int glitch[] = {0, 0, 200};
    uint32_t seed = 12345u;
    for (unsigned n = 0; n < 3; ++n) {
        for (unsigned k = 0; k < sizeof offsets / sizeof offsets[0]; ++k) {
            now = 200000u + 100000u * (n * 10u + k);
            fake_x = 330; fake_y = 500;
            Stirrer_Init(now);
            run(1000, false);                   /* learn the centre at 330,500 */
            fake_x = (uint16_t)(330 + offsets[k]);
            run(1000, true);                    /* the stick comes to rest off-centre */
            (void)Stirrer_TakeActivity();
            unsigned events = 0;
            for (uint32_t ms = 0; ms < 20000u; ms += 10u) {
                seed = seed * 1103515245u + 12345u;
                int nx = (int)((seed >> 16) % (2u * noise[n] + 1u)) - noise[n];
                seed = seed * 1103515245u + 12345u;
                int ny = (int)((seed >> 16) % (2u * noise[n] + 1u)) - noise[n];
                int drift = (int)(ms * 6u / 20000u);   /* +6 counts over 20 s */
                int g = (ms / 10u) & 1u ? glitch[n] : 0;
                fake_x = (uint16_t)(330 + offsets[k] + drift + nx + g);
                fake_y = (uint16_t)(500 + ny);
                run(10, true);
                events += Stirrer_TakeActivity();
            }
            if (events) fprintf(stderr, "rest offset %d, noise +/-%d, glitch %d: %u events\n",
                                offsets[k], noise[n], glitch[n], events);
            CHECK(events == 0);
        }
    }
}

static void test_relearn(void)
{
    now = 50000;
    fake_x = 330; fake_y = 500;
    Stirrer_Init(now);
    run(1000, false);
    /* Cooking: holding still off-centre never re-centres, so the spoon stays
     * pushed (700 is still 370 counts right of the centre at 330). */
    fake_x = 700;
    run(5000, true);
    CHECK(S.pulse_us == STIR_PULSE_MAX_US);
    /* Not cooking: still 3 s at a new rest position -> re-centred there. */
    fake_x = 520; fake_y = 510;
    run(3500, false);
    (void)Stirrer_TakeActivity();
    fake_x = 530;                           /* 10 counts: not a move */
    run(100, false);
    CHECK(!Stirrer_TakeActivity() && !Stirrer_OffCentre());
    /* 520 is now home: cooking there holds the spoon at centre... */
    run(1000, true);
    CHECK(S.pulse_us == STIR_PULSE_CENTER_US);
    /* ...and 330, 190 counts left of the new centre, swings it left. */
    fake_x = 330;
    run(1500, true);
    CHECK(S.pulse_us < STIR_PULSE_CENTER_US);
}

static void test_fault_recovery(void)
{
    now = 90000;
    fake_x = 512; fake_y = 512;
    Stirrer_Init(now);
    run(1000, false);
    fake_x = 1023;
    run(600, true);
    CHECK(S.pulse_us == STIR_PULSE_MAX_US);
    /* ADC conversion fault: driver re-initialised, sampling resumes. */
    unsigned inits = fake_adc_inits, samples = fake_adc_samples;
    fake_adc_fault = true;
    run(3, true);
    CHECK(fake_adc_inits > inits);
    fake_adc_fault = false;
    run(50, true);
    CHECK(fake_adc_samples > samples && S.pulse_us == STIR_PULSE_MAX_US);
    /* Persistent fault keeps retrying instead of latching. */
    inits = fake_adc_inits;
    fake_adc_fault = true;
    run(50, true);
    CHECK(fake_adc_inits >= inits + 5);
    fake_adc_fault = false;
    /* No samples for > 100 ms: follower faults, re-arms, spoon goes home. */
    fake_adc_stall = true;
    run(150, true);
    CHECK(S.pulse_us == STIR_PULSE_CENTER_US);
    fake_adc_stall = false;
    run(300, true);                         /* X still 1023: must not re-arm */
    CHECK(S.pulse_us == STIR_PULSE_CENTER_US);
    fake_x = 512;
    run(600, true);
    fake_x = 1023;
    run(600, true);
    CHECK(S.pulse_us == STIR_PULSE_MAX_US);
}

/* Walk the stick around centre 330,500 in 'step'-degree moves, 'ms' per move. */
static void sweep(int from, int to, int step, int r, uint32_t ms)
{
    for (int deg = from; step > 0 ? deg <= to : deg >= to; deg += step) {
        at(330, 500, deg, r);
        run(ms, true);
    }
}

static void centre(void) { fake_x = 330; fake_y = 500; run(100, true); }

static void test_circles(void)
{
    now = 120000;
    fake_x = 330; fake_y = 500;
    Stirrer_Init(now);
    run(1000, false);
    CHECK(Stirrer_TakeCircles() == 0);
    /* One counter-clockwise turn = 1 circle, taken once. */
    sweep(0, 360, 10, 200, 30);
    CHECK(Stirrer_TakeCircles() == 1 && Stirrer_TakeCircles() == 0);
    /* Clockwise counts too. */
    centre(); sweep(0, -360, -10, 200, 30);
    CHECK(Stirrer_TakeCircles() == 1);
    /* 2.5 turns = 2; a fast stir (240 ms per turn) still counts every turn. */
    centre(); sweep(0, 900, 10, 200, 30);
    CHECK(Stirrer_TakeCircles() == 2);
    centre(); sweep(0, 1080, 30, 200, 20);
    CHECK(Stirrer_TakeCircles() == 3);
    /* Circles accumulate until taken. */
    centre(); sweep(0, 720, 15, 200, 30);
    sweep(720, 1080, 15, 200, 30);
    CHECK(Stirrer_TakeCircles() == 3);
    /* A partial turn is discarded when the stick returns to centre. */
    centre(); sweep(0, 300, 10, 200, 30);
    centre(); sweep(0, 300, 10, 200, 30);
    centre();
    CHECK(Stirrer_TakeCircles() == 0);
    /* Wiping back and forth over a 135 deg arc never makes a circle. */
    for (int i = 0; i < 5; ++i) { sweep(0, 135, 15, 200, 30); sweep(135, 0, -15, 200, 30); }
    CHECK(Stirrer_TakeCircles() == 0);
    /* Reversing half-way: +180 then -360 then +180 nets zero. */
    centre(); sweep(0, 180, 10, 200, 30); sweep(180, -180, -10, 200, 30);
    sweep(-180, 0, 10, 200, 30);
    CHECK(Stirrer_TakeCircles() == 0);
    /* Jitter across a sector boundary is not progress. */
    centre();
    for (int i = 0; i < 40; ++i) { at(330, 500, i & 1 ? 50 : 40, 200); run(30, true); }
    CHECK(Stirrer_TakeCircles() == 0);
    /* Side to side through the centre (the old X-only stir) is not a circle. */
    for (int i = 0; i < 10; ++i) {
        fake_x = 600; fake_y = 500; run(100, true);
        fake_x = 60; run(100, true);
    }
    CHECK(Stirrer_TakeCircles() == 0);
    /* Tiny circles inside the centre zone (r 40 < 60) never count. */
    centre(); sweep(0, 1080, 10, 40, 30);
    CHECK(Stirrer_TakeCircles() == 0);
    /* Re-init clears anything pending. */
    sweep(0, 360, 10, 200, 30);
    Stirrer_Init(now);
    CHECK(Stirrer_TakeCircles() == 0);
}

static void test_smoothing(void)
{
    static const int noise[] = {0, 8, 8, -8, -8, 4, -4, 0};
    now = 150000;
    fake_x = 330; fake_y = 500;
    Stirrer_Init(now);
    run(1000, false);
    fake_x = 800;                           /* grow the + side to 800 */
    run(1000, true);
    CHECK(S.pulse_us == STIR_PULSE_MAX_US);
    /* Held near 600 with +/-8 counts of slow wander: settles, then stays put
     * (without the 4 us hysteresis this dithers every few samples). */
    for (int i = 0; i < 100; ++i) { fake_x = (uint16_t)(600 + noise[i % 8]); run(10, true); }
    uint16_t held = S.pulse_us;
    CHECK(held > STIR_PULSE_CENTER_US + 50u && held < STIR_PULSE_MAX_US - 50u);
    unsigned changes = 0;
    for (int i = 0; i < 300; ++i) {
        fake_x = (uint16_t)(600 + noise[i % 8]);
        run(10, true);
        if (S.pulse_us != held) { ++changes; held = S.pulse_us; }
    }
    CHECK(changes <= 1);                    /* at most one catch-up step, no dither */
    /* A one-sample spike to 1023 is removed by the median: spoon unmoved... */
    fake_x = 1023; run(10, true);
    fake_x = 600;
    for (int i = 0; i < 30; ++i) { run(10, true); CHECK(S.pulse_us == held); }
    /* ...and it did not stretch the range: 800 is still full travel. */
    fake_x = 800;
    run(1000, true);
    CHECK(S.pulse_us == STIR_PULSE_MAX_US);
    /* Home and both ends stay exact despite the hysteresis. */
    fake_x = 330;
    run(1000, true);
    CHECK(S.pulse_us == STIR_PULSE_CENTER_US);
}

int main(void)
{
    fake_servo_reset();
    test_learned_centre_and_follow();
    test_asymmetric_range();
    test_motion();
    test_resting_noise();
    test_relearn();
    test_fault_recovery();
    test_circles();
    test_smoothing();
    Stirrer_Report();
    printf("test_stirrer: PASS\n");
    return 0;
}
