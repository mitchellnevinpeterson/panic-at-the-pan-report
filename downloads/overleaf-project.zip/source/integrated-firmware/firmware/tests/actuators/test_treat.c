#include "fake_actuators.h"
#include "Treat.h"
#include "Servo50Hz.h"

#define T fake_servo[SERVO_TREAT]

static void test_power_up_and_flag(void)
{
    Treat_Init(0);
    CHECK(T.pulsing && T.pulse_us == TREAT_CLOSED_US && T.writes == 1);
    CHECK(!Treat_Rotated());
    Treat_Release(20);
    CHECK(Treat_Rotated() && T.pulse_us == TREAT_RELEASE_US && T.pulsing);
    Treat_Release(30);                      /* repeat keeps the one flag */
    CHECK(Treat_Rotated() && T.pulse_us == TREAT_RELEASE_US);
    /* Game start: always commands closed, rotated or not, and clears the flag. */
    unsigned writes = T.writes;
    Treat_Close(40);
    CHECK(T.writes == writes + 1 && T.pulse_us == TREAT_CLOSED_US && T.pulsing && !Treat_Rotated());
    Treat_Close(50);                        /* already closed: still re-commanded */
    CHECK(T.writes == writes + 2 && T.pulse_us == TREAT_CLOSED_US && !Treat_Rotated());
    CHECK(fake_servo[SERVO_SPOON].writes == 0);
}

static void test_drive_window(void)
{
    Treat_Init(1000);
#if TREAT_DRIVE_MS > 0
    Treat_Service(1000 + TREAT_DRIVE_MS - 1);
    CHECK(T.pulsing);
    Treat_Service(1000 + TREAT_DRIVE_MS);
    CHECK(!T.pulsing && T.disables == 1);
    Treat_Service(5000);
    CHECK(T.disables == 1);                 /* one stop per move */
    Treat_Release(6000);
    CHECK(T.pulsing && T.pulse_us == TREAT_RELEASE_US);
    Treat_Service(6000 + TREAT_DRIVE_MS);
    Treat_Service(6000 + TREAT_OPEN_MS - 1); /* open: keeps pulsing until it auto-closes */
    CHECK(T.pulsing && T.disables == 1 && Treat_Rotated());
    Treat_Close(0xFFFFFFF0u);               /* window survives ms wraparound */
    Treat_Service(0xFFFFFFF0u + TREAT_DRIVE_MS - 1);
    CHECK(T.pulsing && T.pulse_us == TREAT_CLOSED_US);
    Treat_Service(0xFFFFFFF0u + TREAT_DRIVE_MS);
    CHECK(!T.pulsing && T.disables == 2);
#else
    for (uint32_t t = 1000; t < 200000; t += 997) Treat_Service(t);
    CHECK(T.pulsing && T.disables == 0);    /* hold: keep pulsing */
    Treat_Release(200000);
    Treat_Service(200000 + TREAT_OPEN_MS - 1);
    CHECK(T.pulsing && T.pulse_us == TREAT_RELEASE_US);
    Treat_Close(900001);
#endif
}

/* A game-opened gate closes by itself TREAT_OPEN_MS later. A new game that
 * closes it sooner cancels that; the 'o' calibration key never auto-closes. */
static void test_auto_close(void)
{
    Treat_Init(0);
    Treat_Release(1000);
    Treat_Service(1000 + TREAT_OPEN_MS - 1);
    CHECK(Treat_Rotated() && T.pulse_us == TREAT_RELEASE_US && T.pulsing);
    unsigned writes = T.writes;
    Treat_Service(1000 + TREAT_OPEN_MS);    /* exactly 20 s after opening */
    CHECK(!Treat_Rotated() && T.pulse_us == TREAT_CLOSED_US && T.writes == writes + 1);
    Treat_Service(1000 + 3 * TREAT_OPEN_MS);
    CHECK(T.pulse_us == TREAT_CLOSED_US && T.writes == writes + 1); /* closes once */
    /* Closed early by the next game's start: no later auto-close move. */
    Treat_Release(100000);
    Treat_Close(105000);
    writes = T.writes;
    Treat_Service(100000 + TREAT_OPEN_MS + 1);
    CHECK(T.writes == writes && !Treat_Rotated());
    /* The timer survives ms wraparound. */
    Treat_Release(0xFFFFF000u);
    Treat_Service(0xFFFFF000u + TREAT_OPEN_MS - 1);
    CHECK(Treat_Rotated() && T.pulse_us == TREAT_RELEASE_US);
    Treat_Service(0xFFFFF000u + TREAT_OPEN_MS);
    CHECK(!Treat_Rotated() && T.pulse_us == TREAT_CLOSED_US);
    /* Calibration: 'o' stays open however long it takes. */
    CHECK(Treat_Key('o', 300000) && T.pulse_us == TREAT_RELEASE_US);
    Treat_Service(300000 + 5 * TREAT_OPEN_MS);
    CHECK(Treat_Rotated() && T.pulse_us == TREAT_RELEASE_US);
    CHECK(Treat_Key('c', 300000 + 5 * TREAT_OPEN_MS + 1) && !Treat_Rotated());
}

static void test_keys(void)
{
    Treat_Init(0);
    CHECK(!Treat_Key('x', 0) && !Treat_Key('1', 0) && !Treat_Key('s', 0));
    CHECK(Treat_Key('o', 1) && Treat_Rotated() && T.pulse_us == TREAT_RELEASE_US);
    CHECK(Treat_Key('-', 2) && T.pulse_us == TREAT_RELEASE_US - 25u);
    CHECK(Treat_Key('c', 3) && !Treat_Rotated() && T.pulse_us == TREAT_CLOSED_US);
    CHECK(Treat_Key('+', 4) && T.pulse_us == TREAT_CLOSED_US + 25u);
    CHECK(Treat_Key('+', 5) && T.pulse_us == TREAT_CLOSED_US + 50u);
    /* The nudged values are what the game later uses. */
    Treat_Release(6);
    CHECK(T.pulse_us == TREAT_RELEASE_US - 25u);
    Treat_Close(7);
    CHECK(T.pulse_us == TREAT_CLOSED_US + 50u);
    /* Bounds: release saturates at the top, closed at the bottom. */
    Treat_Key('o', 8);
    for (int i = 0; i < 100; ++i) CHECK(Treat_Key('+', 9));
    CHECK(T.pulse_us <= SERVO50HZ_MAX_US && T.pulse_us + 25u > SERVO50HZ_MAX_US);
    Treat_Key('c', 10);
    for (int i = 0; i < 100; ++i) CHECK(Treat_Key('-', 11));
    CHECK(T.pulse_us >= SERVO50HZ_MIN_US && T.pulse_us < SERVO50HZ_MIN_US + 25u);
    Treat_Release(12);
    CHECK(T.pulse_us <= SERVO50HZ_MAX_US && T.pulse_us + 25u > SERVO50HZ_MAX_US);
}

int main(void)
{
    fake_servo_reset();
    test_power_up_and_flag();
    fake_servo_reset();
    test_drive_window();
    fake_servo_reset();
    test_auto_close();
    fake_servo_reset();
    test_keys();                            /* last: leaves nudged values in RAM */
    printf("test_treat (TREAT_DRIVE_MS=%u): PASS\n", (unsigned)TREAT_DRIVE_MS);
    return 0;
}
