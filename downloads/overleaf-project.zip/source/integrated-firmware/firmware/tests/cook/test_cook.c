/* Real CookSM; fake ES queue/timer, sensors and a ScoreSM_PostDelta recorder. */
#include "CookSM.h"
#include "ScoreSM.h"
#include "ES_Configure.h"
#include "ES_Framework.h"
#include <assert.h>
#include <stdio.h>

static ES_Event_t queue[64];
static unsigned head, count;
static bool reject_post, reject_timer, reject_delta, timer_armed;
static uint16_t timer_delay;
static uint32_t clock_ms, expected_round;
static bool hand;
static uint8_t stir_circles; /* circles the fake Stirrer has pending */
static uint16_t hand_mm;
static int32_t deltas[256], delta_sum;
static unsigned delta_count;

bool ES_PostToService(uint8_t priority, ES_Event_t event)
{
    assert(priority == 1);
    if (reject_post || count == 64) return false;
    queue[(head + count++) % 64] = event;
    return true;
}
ES_TimerReturn_t ES_Timer_InitTimer(uint8_t timer, uint16_t delay)
{
    assert(timer == COOK_TICK_TIMER);
    if (reject_timer) return ES_Timer_ERR;
    timer_armed = true; timer_delay = delay; return ES_Timer_OK;
}
ES_TimerReturn_t ES_Timer_StopTimer(uint8_t timer)
{
    assert(timer == COOK_TICK_TIMER);
    timer_armed = false; return ES_Timer_OK;
}
uint16_t ES_Timer_GetTime(void) { return (uint16_t)clock_ms; }
bool ScoreSM_PostDelta(uint32_t round, int32_t millipoints)
{
    assert(round == expected_round && millipoints != 0);
    if (reject_delta) return false;
    assert(delta_count < 256);
    deltas[delta_count++] = millipoints; delta_sum += millipoints;
    return true;
}

static uint32_t now_ms(void) { return clock_ms; }
static bool distance_mm(uint16_t *mm) { *mm = hand_mm; return hand; }
static uint8_t take_circles(void) { uint8_t n = stir_circles; stir_circles = 0; return n; }

static ES_Event_t pop(void)
{
    assert(count); ES_Event_t e = queue[head]; head = (head + 1) % 64; --count; return e;
}
static void drain(void) { while (count) assert(RunCookSM(pop()).EventType == ES_NO_EVENT); }
static void clear_deltas(void) { delta_count = 0; delta_sum = 0; }
static void tick(uint32_t ms)
{
    clock_ms += ms;
    assert(timer_armed && timer_delay == COOK_TICK_MS);
    timer_armed = false; /* one-shot, like the ES timer */
    assert(PostCookSM((ES_Event_t){ES_TIMEOUT, COOK_TICK_TIMER})); drain();
}
static void ticks(unsigned n) { while (n--) tick(COOK_TICK_MS); }
static void set_hand(uint16_t mm) { hand = true; hand_mm = mm; }
static void start(uint32_t round)
{
    expected_round = round;
    assert(CookSM_PostLifecycle(GAME_START, round)); drain();
}
static void add(uint8_t n) { assert(CookSM_PostIngredient(n, expected_round)); drain(); }
static void flip(void) { assert(CookSM_PostFlip(expected_round)); drain(); }
static void end(void) { assert(CookSM_PostLifecycle(GAME_END, expected_round + 1)); drain(); }
static void reset_all(uint32_t generation)
{
    assert(CookSM_PostLifecycle(GAME_RESET, generation)); drain();
    hand = false; stir_circles = 0; clear_deltas();
}
static unsigned burns(void)
{
    unsigned n = 0;
    for (unsigned i = 0; i < delta_count; ++i) n += deltas[i] == COOK_BURN_MILLI;
    return n;
}
/* n circles arrive before one tick; hand away so no heat is earned. */
static void circles(uint8_t n) { stir_circles = n; tick(COOK_TICK_MS); assert(stir_circles == 0); }

int main(void)
{
    CookOutput_t out;
    assert(!InitCookSM(1));
    CookSMPort_t port = {now_ms, distance_mm, 0};
    assert(!CookSM_BindPort(&port)); port.take_stir_circles = take_circles;
    assert(CookSM_BindPort(&port));
    assert(InitCookSM(1)); drain();
    assert(!CookSM_BindPort(&port)); /* bound once registered */
    out = CookSM_Output();
    assert(out.lcd_mode == COOK_LCD_ATTRACT && out.zone == COOK_ZONE_NONE && !out.sizzle &&
           out.target_cm == 0 && !out.burnt && out.burn_seq == 0);
    assert(!CookSM_PostIngredient(5, 1) && !CookSM_PostLifecycle(USER_ACTIVITY, 1));

    /* Empty pan: WAITING, no heat, no sizzle, flips score nothing. */
    clock_ms = 1000; start(10); set_hand(140);
    out = CookSM_Output();
    assert(timer_armed && out.lcd_mode == COOK_LCD_WAITING && out.zone == COOK_ZONE_NONE &&
           !out.sizzle && out.target_cm == 0);
    ticks(20); flip(); flip(); flip();
    assert(delta_count == 0);

    /* On target: exactly +1 point/s, batched ~1 post per point. */
    add(0); out = CookSM_Output();
    assert(out.lcd_mode == COOK_LCD_ZONE && out.zone == COOK_ZONE_RIGHT && out.sizzle &&
           out.target_cm == 14 && !out.burnt);
    ticks(100);
    assert(delta_sum == 10000 && delta_count == 10);
    /* 40 mm off (band edge, JUST RIGHT): half rate. */
    clear_deltas(); set_hand(180); ticks(100); assert(delta_sum == 5000);
    /* 80 mm or more off, or no hand: nothing. */
    clear_deltas(); set_hand(220); ticks(50); set_hand(400); ticks(50);
    hand = false; ticks(50); assert(delta_count == 0);
    hand_mm = 140; ticks(20); assert(delta_count == 0); /* stale mm with no hand */
    /* Out-of-range readings count as no hand. */
    set_hand(20); ticks(30); set_hand(401); ticks(30); assert(delta_count == 0);
    assert(CookSM_Output().zone == COOK_ZONE_LOW);

    /* Zone confirmation: two identical ticks; a one-tick glitch never shows. */
    set_hand(140); tick(100); assert(CookSM_Output().zone == COOK_ZONE_LOW);
    tick(100); assert(CookSM_Output().zone == COOK_ZONE_RIGHT);
    set_hand(250); tick(100); assert(CookSM_Output().zone == COOK_ZONE_RIGHT);
    set_hand(140); tick(100); tick(100); assert(CookSM_Output().zone == COOK_ZONE_RIGHT);
    set_hand(99); tick(100); assert(CookSM_Output().zone == COOK_ZONE_RIGHT);
    tick(100); assert(CookSM_Output().zone == COOK_ZONE_HIGH);
    set_hand(100); ticks(2); assert(CookSM_Output().zone == COOK_ZONE_RIGHT); /* T-40 is RIGHT */
    set_hand(181); ticks(2); assert(CookSM_Output().zone == COOK_ZONE_LOW);

    /* Interrupted TOO MUCH never burns. */
    clear_deltas();
    for (int i = 0; i < 5; ++i) { set_hand(90); ticks(29); set_hand(140); ticks(1); }
    assert(burns() == 0 && !CookSM_Output().burnt);
    /* 3 s straight burns once: -10, burn_seq +1, then no more heat. */
    set_hand(90); ticks(29); assert(!CookSM_Output().burnt);
    clear_deltas(); tick(100);
    out = CookSM_Output();
    assert(out.burnt && out.burn_seq == 1 && out.zone == COOK_ZONE_HIGH && out.sizzle);
    assert(burns() == 1 && deltas[delta_count - 1] == COOK_BURN_MILLI);
    clear_deltas(); ticks(50); set_hand(140); ticks(100);
    assert(delta_count == 0 && CookSM_Output().burnt && CookSM_Output().burn_seq == 1);
    /* Next ingredient clears the burn and sets the new target. */
    add(4); out = CookSM_Output();
    assert(!out.burnt && out.burn_seq == 1 && out.target_cm == 10 && out.zone == COOK_ZONE_RIGHT);
    clear_deltas(); set_hand(100); ticks(10); assert(delta_sum == 1000);
    set_hand(50); ticks(30); assert(burns() == 1 && CookSM_Output().burn_seq == 2);
    end();
    out = CookSM_Output();
    assert(out.lcd_mode == COOK_LCD_ATTRACT && out.zone == COOK_ZONE_NONE && !out.sizzle &&
           !out.burnt && out.target_cm == 0 && out.burn_seq == 2 && !timer_armed);

    /* Stir, live: +1 per full circle up to the ideal count, -1 per circle beyond. */
    reset_all(12); start(13);
    assert(CookSM_Output().stirs == 0 && CookSM_Output().flips == 0); /* empty pan */
    circles(4); assert(delta_count == 0);                 /* empty pan: consumed, ignored */
    stir_circles = 2; add(0); assert(delta_count == 0);   /* pre-ingredient circles too */
    circles(2); assert(delta_count == 2 && delta_sum == 2000);   /* protein: ideal 3 */
    assert(CookSM_Output().stirs == 2 && CookSM_Output().flips == 0); /* LCD counters */
    circles(1); assert(delta_count == 3 && delta_sum == 3000);
    circles(2); assert(delta_count == 5 && deltas[3] == -1000 && deltas[4] == -1000);
    circles(0); assert(delta_count == 5);
    /* The count restarts with each ingredient. */
    add(1); assert(CookSM_Output().stirs == 0);            /* counters restart per ingredient */
    clear_deltas(); circles(6); assert(delta_count == 6 && delta_sum == 4000); /* carb 5 */
    assert(CookSM_Output().stirs == 6);
    add(3); clear_deltas(); circles(6); circles(1); assert(delta_sum == 5000);         /* spice 6 */
    add(4); clear_deltas(); circles(2); assert(delta_sum == -2000);                    /* oil 0 */
    add(2); clear_deltas(); circles(1); assert(delta_sum == -1000);                    /* veg 0 */
    /* Circles are not time-scaled: a stalled loop still scores each one. */
    end(); start(15); add(1); clear_deltas();
    stir_circles = 3; tick(3000); assert(delta_count == 3 && delta_sum == 3000);
    /* A burnt ingredient still scores its circles (but no more heat). */
    end(); start(17); add(0); set_hand(90); ticks(30);    /* 14 cm target: 90 is TOO MUCH */
    assert(CookSM_Output().burnt);
    clear_deltas(); circles(2); assert(delta_count == 2 && delta_sum == 2000);
    hand = false;

    /* Flips: +2 each up to the ingredient's own count, then -2 each; the count
     * restarts with the next ingredient. Protein 2 (burnt still flips). */
    clear_deltas(); flip(); flip(); flip(); flip();
    assert(delta_count == 4 && deltas[0] == 2000 && deltas[1] == 2000 &&
           deltas[2] == -2000 && deltas[3] == -2000);
    add(1); clear_deltas(); flip(); assert(delta_count == 1 && deltas[0] == 2000);
    add(1); flip(); assert(delta_count == 2 && deltas[1] == 2000); /* repeat ignored */
    assert(CookSM_Output().flips == 2);
    flip(); flip(); flip();                                         /* carb 4 */
    assert(CookSM_Output().flips == 5);
    assert(delta_count == 5 && deltas[2] == 2000 && deltas[3] == 2000 && deltas[4] == -2000);
    add(2); clear_deltas(); flip(); flip();                         /* vegetables 1 */
    assert(delta_count == 2 && deltas[0] == 2000 && deltas[1] == -2000);
    add(3); clear_deltas(); flip(); flip(); flip(); flip();         /* spice 3 */
    assert(delta_count == 4 && delta_sum == 4000 && deltas[3] == -2000);
    add(4); clear_deltas(); flip(); flip();                         /* oil 0 */
    assert(delta_count == 2 && deltas[0] == -2000 && deltas[1] == -2000);

    /* End scores circles not yet taken, then flushes pending heat; no stir bonus. */
    reset_all(114); start(115); add(1); set_hand(240);
    ticks(15); assert(delta_sum == 1000); /* 1.5 s: one batch posted */
    clear_deltas(); end(); assert(delta_count == 1 && deltas[0] == 500);
    reset_all(116); start(117); add(1); set_hand(240); ticks(15);
    clear_deltas(); stir_circles = 1; end();
    assert(delta_count == 2 && deltas[0] == 1000 && deltas[1] == 500);
    assert(!timer_armed && CookSM_Output().lcd_mode == COOK_LCD_ATTRACT);
    /* Stale tick after End: ignored, not re-armed. */
    assert(PostCookSM((ES_Event_t){ES_TIMEOUT, COOK_TICK_TIMER})); drain();
    assert(!timer_armed);

    /* Stale rounds and lifecycles. */
    reset_all(120); start(121); add(0);
    assert(CookSM_PostIngredient(1, 120) && CookSM_PostFlip(120) && CookSM_PostFlip(122)); drain();
    assert(CookSM_Output().target_cm == 14 && delta_count == 0);
    assert(CookSM_PostLifecycle(GAME_END, 120)); drain();      /* older than Start */
    assert(CookSM_PostLifecycle(GAME_RESET, 119)); drain();
    assert(CookSM_PostLifecycle(GAME_START, 121)); drain();    /* repeated Start */
    assert(CookSM_Output().lcd_mode == COOK_LCD_ZONE && CookSM_Output().target_cm == 14);
    assert(PostCookSM((ES_Event_t){ES_TIMEOUT, COOK_TICK_TIMER + 1})); drain(); /* not ours */
    /* A repeated owned ticket is consumed once. */
    assert(CookSM_PostFlip(121)); ES_Event_t dup = queue[head]; drain();
    assert(PostCookSM(dup)); drain(); assert(delta_count == 1);
    assert(PostCookSM((ES_Event_t){FLIP_PRESSED, 999})); drain(); assert(delta_count == 1);
    end();
    assert(CookSM_PostIngredient(2, 121) && CookSM_PostFlip(121)); drain(); /* after End */
    assert(CookSM_Output().lcd_mode == COOK_LCD_ATTRACT);
    assert(CookSM_PostLifecycle(GAME_RESET, 123)); drain();
    assert(CookSM_PostLifecycle(GAME_START, 121)); drain();    /* delayed old Start */
    assert(CookSM_Output().lcd_mode == COOK_LCD_ATTRACT && !timer_armed);
    /* Reset mid-round discards pending heat and untaken circles, stops the tick. */
    clear_deltas(); start(124); add(0); set_hand(140); ticks(5); stir_circles = 2;
    assert(CookSM_PostLifecycle(GAME_RESET, 125)); drain();
    assert(delta_count == 0 && !timer_armed && CookSM_Output().lcd_mode == COOK_LCD_ATTRACT);
    start(126); add(0); assert(stir_circles == 0 && delta_count == 0); /* stale circles dropped */
    reset_all(127);

    /* dt robustness: irregular ticks give exact totals; long stalls are capped. */
    /* 10 mm off: 875 milli/s; remainders carried so 20 s is exactly 17.5. */
    start(130); set_hand(150); add(0); clear_deltas();
    static const uint16_t steps[] = {37, 163, 90, 210, 1, 99, 250, 150};
    uint32_t total = 0;
    while (total < 20000) for (unsigned i = 0; i < 8; ++i) { tick(steps[i]); total += steps[i]; }
    end(); assert(total == 20000 && delta_sum == 17500);
    reset_all(132); start(133); set_hand(140); add(0);
    clear_deltas(); tick(3000); tick(100); /* 3 s stall credits 0.5 s */
    assert(delta_count == 0);
    tick(400); assert(delta_sum == 1000);
    /* Stall in TOO MUCH: burn still needs >= 3 s of measured (capped) time. */
    set_hand(90); clear_deltas(); tick(2000); tick(2000); tick(1000);
    assert(burns() == 0);
    ticks(15); assert(burns() == 1);
    reset_all(135);

    /* Faults: ScoreSM refusal, timer failure, queue failure. */
    start(140); add(0); flip(); reject_delta = true;
    assert(CookSM_PostFlip(140));
    assert(RunCookSM(pop()).EventType == ES_ERROR && CookSM_HasFault());
    assert(!CookSM_PostFlip(140));
    reject_delta = false;
    assert(InitCookSM(1)); drain(); assert(!CookSM_HasFault());
    reject_timer = true; assert(CookSM_PostLifecycle(GAME_START, 41));
    assert(RunCookSM(pop()).EventType == ES_ERROR && CookSM_HasFault());
    reject_timer = false;
    assert(InitCookSM(1)); drain();
    reject_post = true; assert(!CookSM_PostFlip(1) && CookSM_HasFault()); reject_post = false;
    assert(InitCookSM(1)); drain();
    for (unsigned i = 0; i < 16; ++i) assert(CookSM_PostFlip(1));
    assert(!CookSM_PostFlip(1) && CookSM_HasFault());

    /* Wrap-around generations after a fresh init. */
    head = count = 0; assert(InitCookSM(1)); drain();
    start(UINT32_MAX); add(3); set_hand(280); ticks(10);
    assert(CookSM_PostLifecycle(GAME_END, 0)); drain();
    assert(CookSM_Output().lcd_mode == COOK_LCD_ATTRACT);
    assert(CookSM_PostLifecycle(GAME_RESET, 1)); drain();
    expected_round = 2; assert(CookSM_PostLifecycle(GAME_START, 2)); drain();
    assert(CookSM_Output().lcd_mode == COOK_LCD_WAITING);

    puts("CookSM passed: heat rate/falloff, zones, burn, stir circles, flips, End, stale rounds, dt, faults.");
    return 0;
}
