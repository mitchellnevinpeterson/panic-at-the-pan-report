/* Real ScoreSM (final-game port: recipe mask, floor at zero) + real CookSM,
 * dispatched highest priority first like the ES framework (Cook 1, Score 0). */
#include "CookSM.h"
#include "ScoreSM.h"
#include "ES_Configure.h"
#include "ES_Framework.h"
#include <assert.h>
#include <stdio.h>

static struct { ES_Event_t events[32]; unsigned head, count; } queues[2];
static uint32_t clock_ms, generation, round_gen;
static bool allow_round, timer_armed;
static int32_t displayed;
static unsigned renders;

bool ES_PostToService(uint8_t priority, ES_Event_t event)
{
    assert(priority < 2);
    if (queues[priority].count == 32) return false;
    queues[priority].events[(queues[priority].head + queues[priority].count++) % 32] = event;
    return true;
}
ES_TimerReturn_t ES_Timer_InitTimer(uint8_t timer, uint16_t delay)
{
    assert(timer == COOK_TICK_TIMER && delay == COOK_TICK_MS);
    timer_armed = true; return ES_Timer_OK;
}
ES_TimerReturn_t ES_Timer_StopTimer(uint8_t timer) { (void)timer; timer_armed = false; return ES_Timer_OK; }
uint16_t ES_Timer_GetTime(void) { return (uint16_t)clock_ms; }

static uint32_t current_generation(void) { return generation; }
static bool accepts_round(uint32_t g) { return allow_round && g == round_gen; }
static bool display(int32_t value)
{
    assert(allow_round && value >= 0); /* floor_zero: never shows a negative */
    displayed = value; ++renders; return true;
}
static bool hand; static uint16_t hand_mm; static uint8_t stir_circles;
static uint32_t now_ms(void) { return clock_ms; }
static bool distance_mm(uint16_t *mm) { *mm = hand_mm; return hand; }
static uint8_t take_circles(void) { uint8_t n = stir_circles; stir_circles = 0; return n; }

static void run(void)
{
    for (;;) {
        int p = queues[1].count ? 1 : queues[0].count ? 0 : -1;
        if (p < 0) return;
        ES_Event_t e = queues[p].events[queues[p].head];
        queues[p].head = (queues[p].head + 1) % 32; --queues[p].count;
        ES_Event_t r = p ? RunCookSM(e) : RunScoreSM(e);
        assert(r.EventType == ES_NO_EVENT);
    }
}
static void ticks(unsigned n)
{
    while (n--) {
        clock_ms += COOK_TICK_MS; assert(timer_armed); timer_armed = false;
        assert(PostCookSM((ES_Event_t){ES_TIMEOUT, COOK_TICK_TIMER})); run();
    }
}
static void begin(void)
{
    round_gen = ++generation; allow_round = true;
    assert(ScoreSM_PostLifecycle(GAME_START, round_gen) &&
           CookSM_PostLifecycle(GAME_START, round_gen)); run();
    assert(ScoreSM_Value() == 0);
}
static void ingredient(uint8_t n)
{
    assert(ScoreSM_PostIngredient(n, round_gen) && CookSM_PostIngredient(n, round_gen)); run();
}
static void reset(void)
{
    ++generation; allow_round = false;
    assert(ScoreSM_PostLifecycle(GAME_RESET, generation) &&
           CookSM_PostLifecycle(GAME_RESET, generation)); run();
}

int main(void)
{
    const ScoreSMPort_t score_port = {current_generation, accepts_round, display, 10, 0x1Bu, true};
    const CookSMPort_t cook_port = {now_ms, distance_mm, take_circles};
    assert(ScoreSM_BindPort(&score_port) && CookSM_BindPort(&cook_port));
    assert(InitScoreSM(0) && InitCookSM(1)); run();

    /* Recipe: Vegetables (bit 2) is wrong; floor applies after every change. */
    generation = 1; begin();
    ingredient(2); assert(ScoreSM_Value() == 0);           /* -10 floored to 0 */
    ingredient(0); assert(ScoreSM_Value() == 10);          /* gains start from 0 */
    ingredient(1); ingredient(3); assert(ScoreSM_Value() == 30);
    ingredient(4); assert(ScoreSM_Value() == 40);
    /* Score dedupes; Cook only ever sees IngredientSM-accepted ingredients. */
    assert(ScoreSM_PostIngredient(4, round_gen)); run(); assert(ScoreSM_Value() == 40);
    assert(ScoreSM_PostDelta(round_gen, -45500)); run(); assert(ScoreSM_Value() == 0);
    assert(ScoreSM_PostDelta(round_gen, 1500)); run(); assert(ScoreSM_Value() == 1);
    assert(ScoreSM_PostDelta(round_gen, -999)); run(); assert(ScoreSM_Value() == 0);
    unsigned before = renders;
    assert(ScoreSM_PostDelta(round_gen, 498)); run();      /* 0.999 -> still 0 */
    assert(ScoreSM_Value() == 0 && renders == before);
    reset();

    /* Full path: Cook deltas reach Score for the earned round. */
    begin();
    hand = true; hand_mm = 140; ingredient(0);             /* +10 recipe */
    ticks(50);                                             /* +5 heat */
    assert(ScoreSM_Value() == 15 && displayed == 15);
    hand_mm = 90; ticks(30);                               /* burn: -10, heat 1.125 */
    assert(CookSM_Output().burnt && ScoreSM_Value() == 6);
    hand = false; stir_circles = 3; ticks(1);              /* burnt still stirs: +3 */
    assert(ScoreSM_Value() == 9);
    ingredient(3); assert(ScoreSM_Value() == 19);          /* right +10 */
    stir_circles = 2; ticks(1); assert(ScoreSM_Value() == 21); /* live, spice ideal 6 */
    assert(CookSM_PostFlip(round_gen)); run(); assert(ScoreSM_Value() == 23);
    /* End: Game moves to results (new generation); circles not yet taken
     * still count, the earned round is kept. */
    stir_circles = 1;
    ++generation; assert(CookSM_PostLifecycle(GAME_END, generation)); run();
    assert(ScoreSM_Value() == 24 && displayed == 24);
    reset(); assert(ScoreSM_Value() == 0 && CookSM_Output().lcd_mode == COOK_LCD_ATTRACT);
    assert(!ScoreSM_HasFault() && !CookSM_HasFault());

    /* Several dishes: a recipe set for the next round is latched at GAME_START,
     * so changing it mid-round never rescores the current round. */
    assert(!ScoreSM_SetRecipeMask(0x20u));                 /* beyond the five ingredients */
    assert(ScoreSM_SetRecipeMask(0x1Du));                  /* stir-fry: Carb wrong */
    begin(); hand = false;
    ingredient(2); assert(ScoreSM_Value() == 10);          /* Vegetables right now */
    assert(ScoreSM_SetRecipeMask(0x1Au));                  /* next round only */
    ingredient(1); assert(ScoreSM_Value() == 0);           /* Carb still wrong this round */
    reset();
    begin(); ingredient(1); assert(ScoreSM_Value() == 10); /* aglio e olio: Carb right */
    ingredient(0); assert(ScoreSM_Value() == 0);           /* Protein wrong */
    reset();
    assert(!ScoreSM_HasFault() && !CookSM_HasFault());

    puts("ScoreSM final port passed: recipe mask, per-round recipe, floor at zero, Cook deltas end to end.");
    return 0;
}
