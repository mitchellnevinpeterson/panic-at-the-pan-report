# Firmware

**The final game is GameButtonsPIC1 + GameButtonsPIC2**, in [bench/game_buttons](bench/game_buttons/README.md):

- **PIC1** runs GameSM, IngredientSM, CookSM and ScoreSM, plus the LED strips, E-ink pan, joystick/spoon and treat.
- **PIC2** runs the MCP inputs and lamps, the ultrasonic sensor, the LCD heat screen and the speaker.

Rules: [final_game_spec.md](../final_game_spec.md). State machines: [panic_at_the_pan_fsm.md](../panic_at_the_pan_fsm.md). Flash with the MPLAB projects GameButtonsPIC2 and GameButtonsPIC1 (see the [root README](../README.md)).

```sh
make -C firmware/bench/game_buttons all     # both hex files
make -C firmware/bench/game_buttons test
make -C firmware/tests/cook test; make -C firmware/tests/actuators test
```

## Other targets

The six-service **full-game image** (`pic1/`, `pic2/`; `make -C firmware check` / `make -C firmware test`) is the November 15 integration, with separate Heat/Stir/Pan services and unconfigured scoring. It is not used for the show. [Architecture](docs/architecture.md), [build choices](docs/build.md) and [pending decisions](docs/pending_decisions.md) describe it.

The standalone hardware checkpoints from the earlier milestones:

| Checkpoint | Guide | Build |
|---|---|---|
| Game/Ingredient/explicit +10 Score | [GameSMBench](bench/game_sm/README.md) | `make -C firmware game-sm` |
| Two stacked score/timer strips | [ScoreTimerBench](bench/score_timer/README.md) | `make -C firmware score-timer` |
| Working X-only joystick/S51 | [JoystickServoBench_2](bench/joystick_servo_2/README.md) | `make -C firmware joystick-servo-2` |
| CW/CCW experiment | [JoystickServoBench](bench/joystick_servo/README.md) | `make -C firmware joystick-servo` |
| Tested ingredient e-ink icons | [EInkBench](bench/eink/README.md) | `make -C firmware eink` |

Standalone checkpoint sources and teammate source remain unchanged. [Validation history](docs/validation.md) · [reuse provenance](docs/reuse.md).
