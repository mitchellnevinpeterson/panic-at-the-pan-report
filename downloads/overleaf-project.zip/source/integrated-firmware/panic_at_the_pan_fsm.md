# Panic at the Pan — State Machines (Draft 3, as built)

ME 218a Team 12 · Karl's Kitchen CHEF

**November 18, 2026.** This draft describes the firmware we actually flash: the **GameButtonsPIC1** and **GameButtonsPIC2** images. The game rules and numbers live in [final_game_spec.md](final_game_spec.md). This file shows the structure: which state machines exist, what their states are, and which events pass between them.

**The final game uses four state machines, all on PIC1: GameSM, IngredientSM, CookSM and ScoreSM** (§2–§5). PIC2 has none.

`firmware/services/src` also contains HeatSM, StirSM and PanDisplaySM. Those belong to an older six-service build and are not compiled into the final game: CookSM replaced HeatSM and StirSM, and the E-ink pan needs no state machine.

Values that are just numbers (heat target, elapsed time, zone, circle and flip counts, score) are **variables**, not states. States only capture changes in *behaviour*.

**How to read the state diagrams:**

- **Arrows** are labelled `EVENT [guard] / action`.
- **Lines inside a state box** are events the state handles without leaving it, in the same `EVENT / action` form. `entry /` is what the state does when it is entered.
- **`ES_TIMEOUT(X)`** is the timeout of framework timer X: `SCROLL` (25 ms), `GAME_TICK` (1 s), `IDLE` (20 s), `RESULT` (3 s), `COOK_TICK` (100 ms).
- **Each state machine's table** lists the same events as "state, event [guard], service (action), next state".

---

## 1. System overview

### 1a. Two controllers

PIC1 runs the game: the four state machines plus a few polled modules (§6). PIC2 runs a plain loop: it reads the inputs and drives the LCD, speaker and lamps from PIC1's heartbeat. The two talk over UART2 (PeerLink).

```mermaid
%%{init: {'themeVariables': {'fontSize': '18px'}}}%%
flowchart TB
    subgraph P2 ["PIC2"]
        direction LR
        IN2["Switches, buttons,<br/>flip switch"]
        US["Ultrasonic<br/>sensor"]
        OUT2["LCD, speaker,<br/>lamps"]
    end
    subgraph P1 ["PIC1"]
        direction LR
        ST["Stirrer:<br/>joystick → spoon"]
        SM["4 state<br/>machines"]
        OUT1["LED strips, E-ink,<br/>treat servo"]
    end
    IN2 -->|"input edges"| SM
    US -->|"distance"| SM
    ST -->|"circles"| SM
    SM --> OUT1
    SM -->|"heartbeat"| OUT2
```

- **PIC2 → PIC1:** input edges (ingredient ON, ingredient OFF, Start, Finish, flip) and ultrasonic readings.
- **PIC1 → PIC2 heartbeat:** Start lamp, Finish lamp, LCD mode, zone, heat target, sizzle on/off, burnt flag, a burn counter, and the current ingredient's stir and flip counts (for the LCD's bottom line).

### 1b. Events between the state machines

Gameplay events:

```mermaid
%%{init: {'themeVariables': {'fontSize': '18px'}}}%%
flowchart TB
    IN["Inputs: PIC2 buttons and switches,<br/>joystick, hand distance"]
    IN -->|"START_PRESSED<br/>FINISH_PRESSED<br/>USER_ACTIVITY"| GAME[GameSM]
    IN -->|"SWITCH_FLIPPED"| ING[IngredientSM]
    IN -->|"FLIP_PRESSED"| COOK[CookSM]
    ING -->|"INGREDIENT_ADDED"| COOK
    ING -->|"INGREDIENT_ADDED"| SCORE[ScoreSM]
    COOK -->|"SCORE_DELTA"| SCORE
```

Lifecycle events, which GameSM broadcasts at each game boundary:

```mermaid
%%{init: {'themeVariables': {'fontSize': '18px'}}}%%
flowchart LR
    GAME[GameSM] ==>|"GAME_START<br/>GAME_END<br/>GAME_RESET"| ING[IngredientSM]
    GAME ==>|"GAME_START<br/>GAME_END<br/>GAME_RESET"| COOK[CookSM]
    GAME ==>|"GAME_START<br/>GAME_RESET"| SCORE[ScoreSM]
```

| State machine | ES priority | Owns |
|---|---|---|
| ScoreSM | 0 | The score: the only service allowed to change it |
| CookSM | 1 | Heat, burn, stir and flip points; the LCD and sound state sent to PIC2 |
| IngredientSM | 2 | Which ingredients are in the pan |
| GameSM | 3 | Game lifecycle, game timers, banners, lamps, when the treat may open |

### 1c. Output owners

Each output has **one owner**, so no two machines fight over the same display, speaker or servo.

| Output | Driven by |
|---|---|
| LED strips: banners, dashboard, end message, big score | GameSM (score digits come from ScoreSM) |
| E-ink pan icons | IngredientSM adds icons; GameSM clears them at the big score and on Reset |
| LCD heat bar, sizzle, burnt sound (PIC2) | CookSM, via the heartbeat |
| Start and Finish lamps (PIC2) | GameSM, via the heartbeat |
| Spoon servo | Stirrer module: follows the joystick while cooking, home otherwise |
| Treat servo | Treat module: GameSM's big score opens it if ScoreSM ≥ 50; the Dish intro closes it |

---

## 2. GameSM (top level)

GameSM owns the game clock, the 20 s idle timer, the banners, and when Start and Finish are allowed. Its states are the code's `GameSMState_t` values.

```mermaid
%%{init: {'themeVariables': {'fontSize': '16px'}}}%%
stateDiagram-v2
    Welcome : Welcome
    Welcome : entry / post GAME_RESET, Start lamp on
    Welcome : ES_TIMEOUT(SCROLL) / scroll banner
    DishIntro : DishIntro
    DishIntro : entry / post GAME_RESET, close treat
    DishIntro : ES_TIMEOUT(SCROLL) / scroll dish text
    Early : CookingEarly
    Early : entry / post GAME_START, show 0 / 60
    Early : ES_TIMEOUT(GAME_TICK) / countdown
    Early : USER_ACTIVITY / restart IDLE
    Finishable : CookingFinishable
    Finishable : entry / Finish lamp on
    Finishable : ES_TIMEOUT(GAME_TICK) / countdown
    Finishable : USER_ACTIVITY / restart IDLE
    GameOver : GameOver
    GameOver : entry / post GAME_END, end message
    GameOver : ES_TIMEOUT(SCROLL) / scroll message
    GameOver : message gone / big score, treat check
    TimedOut : TimedOut
    TimedOut : entry / post GAME_END(idle)

    [*] --> Welcome : ES_INIT
    Welcome --> DishIntro : START_PRESSED [link ready]
    DishIntro --> Early : ES_TIMEOUT(SCROLL)<br/>[text gone]
    Early --> Finishable : ES_TIMEOUT(GAME_TICK)<br/>[30 s]
    Finishable --> GameOver : FINISH_PRESSED<br/>or ES_TIMEOUT(GAME_TICK)<br/>[60 s]
    Early --> TimedOut : ES_TIMEOUT(IDLE)
    Finishable --> TimedOut : ES_TIMEOUT(IDLE)
    TimedOut --> Welcome : at once
    GameOver --> Welcome : ES_TIMEOUT(RESULT)
```

| State | Event [guard] | Service (action) | Next state |
|---|---|---|---|
| (power-up) | `ES_INIT` | Post `GAME_RESET`. Start lamp on once the link is ready. Start the welcome banner. | Welcome |
| Welcome | `ES_TIMEOUT(SCROLL)` | Scroll "Welcome to Panic at the Pan" one column across both strips; restart `SCROLL` | Welcome |
| Welcome | `START_PRESSED` [fresh press, link ready] | Post `GAME_RESET`. **Close the treat.** Start lamp off. **Pick a random dish** (never the same as last game): its intro text, and its recipe to ScoreSM (used from the next `GAME_START`). Start "YOUR DISH TODAY: …". | DishIntro |
| DishIntro | `ES_TIMEOUT(SCROLL)` [text still on screen] | Scroll one column | DishIntro |
| DishIntro | `ES_TIMEOUT(SCROLL)` [text gone, ≈ 7.8–10 s] | Record the start time. Post `GAME_START`. Dashboard 0 / 60. Start `GAME_TICK` and `IDLE`. | CookingEarly |
| CookingEarly, CookingFinishable | `ES_TIMEOUT(GAME_TICK)` | Recompute the time from the clock, update the countdown, restart `GAME_TICK` | same |
| CookingEarly, CookingFinishable | `USER_ACTIVITY` | Restart `IDLE` | same |
| CookingEarly | `ES_TIMEOUT(GAME_TICK)` [30 s] | Finish lamp on | CookingFinishable |
| CookingEarly | `FINISH_PRESSED` [press < 30 s] | Ignore | CookingEarly |
| CookingFinishable | `FINISH_PRESSED`, or `ES_TIMEOUT(GAME_TICK)` [60 s] | Stop timers. Finish lamp off. Post `GAME_END(completed)`. The top strip scrolls "GAME OVER" (Finish) or "TIME'S UP. GAME OVER" (60 s); the bottom strip shows the score. | GameOver |
| CookingEarly, CookingFinishable | `ES_TIMEOUT(IDLE)` [20 s with no activity] | Stop timers. Post `GAME_END(idle)`. | TimedOut |
| TimedOut | — (same step) | Post `GAME_RESET`. **No treat.** | Welcome |
| GameOver | `ES_TIMEOUT(SCROLL)` [message on screen] | Scroll one column | GameOver |
| GameOver | `ES_TIMEOUT(SCROLL)` [message gone] | Big score across both strips. E-ink starts clearing. **Open the treat if the score is ≥ 50** (it closes itself 20 s later). Start `RESULT` (3 s). | GameOver |
| GameOver | `ES_TIMEOUT(RESULT)` | Post `GAME_RESET`. Start the welcome banner. | Welcome |
| Any state except Welcome | `GAME_ABORT` [link lost for 1.2 s] | Post `GAME_RESET`. No treat. | Welcome |
| Any | `ES_ERROR` | Stop timers, lamps off | Fault: PIC1 resets (§7) |

**Rules:**

- **Time** always comes from the clock and the start timestamp, never from counting ticks. If 60 s and the idle deadline arrive together, 60 s wins and the game counts as completed.
- **Finish** is judged by the press's own timestamp: a press ≥ 30 s into cooking is valid even if the 30 s tick has not run yet.
- **Activity** is:
  - an ingredient switch turned ON or OFF;
  - the flip switch;
  - a joystick push (held ≥ 150 ADC counts from rest for 100 ms) or a completed stir circle;
  - a hand 3–40 cm away for 3 readings in a row (at most one activity per 0.5 s).

  Start and early Finish presses are **not** activity.
- **Generations:** every lifecycle change bumps a generation number. Inputs and messages carry it, so anything queued before a Start, End or Reset is dropped.
- **Start** only works in Welcome, with the link ready, from a fresh press. A button held across a boundary must be released first. Start presses in every other state are ignored.

---

## 3. IngredientSM

IngredientSM accepts each ingredient once per game, and only after `GAME_START`.

```mermaid
%%{init: {'themeVariables': {'fontSize': '16px'}}}%%
stateDiagram-v2
    Locked : Locked
    Locked : SWITCH_FLIPPED / ignore
    Locked : GAME_RESET / clear mask
    Ready : Ready
    Ready : SWITCH_FLIPPED [new] / post INGREDIENT_ADDED
    Ready : SWITCH_FLIPPED [repeat] / ignore
    [*] --> Locked : ES_INIT
    Locked --> Ready : GAME_START / clear mask
    Ready --> Locked : GAME_END
    Ready --> Locked : GAME_RESET / clear mask
```

| State | Event [guard] | Service (action) | Next state |
|---|---|---|---|
| (power-up) | `ES_INIT` | — | Locked |
| Locked | `GAME_START` | Clear the ingredient mask | Ready |
| Locked | `SWITCH_FLIPPED` | Ignore | Locked |
| Locked | `GAME_RESET` | Clear the mask | Locked |
| Ready | `SWITCH_FLIPPED n` [first time, game still running] | Mark n as added. Post `INGREDIENT_ADDED n` to ScoreSM and CookSM. Add n's icon to the E-ink. | Ready |
| Ready | `SWITCH_FLIPPED n` [repeat, old generation, or past the 60 s or idle deadline] | Ignore | Ready |
| Ready | `GAME_END` | — | Locked |
| Ready | `GAME_RESET` | Clear the mask | Locked |

- **Only ON edges count.** Inputs 0–4 become `SWITCH_FLIPPED`; OFF edges are only activity. A switch already ON when cooking starts must go OFF and then ON to count.
- **IngredientSM only reports which ingredient** was added; ScoreSM decides whether it is right or wrong.

---

## 4. CookSM: heat, burn, stir and flip scoring

- **Tick:** while cooking, CookSM runs a 100 ms `COOK_TICK`.
- **Real elapsed time:** each tick uses the time actually elapsed since the last tick, capped at 0.5 s, so a late tick never changes the points.
- **Score output:** every point change goes to ScoreSM as `SCORE_DELTA`, in thousandths of a point.
- **Playing** groups the three active states, so one arrow carries `GAME_END` and `GAME_RESET` for all of them.

```mermaid
%%{init: {'themeVariables': {'fontSize': '16px'}}}%%
stateDiagram-v2
    Off : Off
    Off : FLIP_PRESSED / ignore
    PanEmpty : PanEmpty
    PanEmpty : ES_TIMEOUT(COOK_TICK) / drop circles
    PanEmpty : FLIP_PRESSED / no points
    Cooking : Cooking
    Cooking : ES_TIMEOUT(COOK_TICK) / circles, zone, heat
    Cooking : FLIP_PRESSED / flip points
    Cooking : INGREDIENT_ADDED / post heat, new target
    Burnt : Burnt
    Burnt : ES_TIMEOUT(COOK_TICK) / circles, zone
    Burnt : FLIP_PRESSED / flip points
    [*] --> Off : ES_INIT
    Off --> Playing : GAME_START / start COOK_TICK
    state Playing {
        [*] --> PanEmpty
        PanEmpty --> Cooking : INGREDIENT_ADDED<br/>/ set target
        Cooking --> Burnt : ES_TIMEOUT(COOK_TICK)<br/>[TOO MUCH 3 s]<br/>/ post SCORE_DELTA −10
        Burnt --> Cooking : INGREDIENT_ADDED<br/>/ clear burn, new target
    }
    Playing --> Off : GAME_END / post last points<br/>GAME_RESET / drop heat
```

| State | Event [guard] | Service (action) | Next state |
|---|---|---|---|
| (power-up) | `ES_INIT` | — | Off |
| Off | `GAME_START` | Start `COOK_TICK` | PanEmpty |
| Off | `FLIP_PRESSED` | Ignore | Off |
| PanEmpty | `ES_TIMEOUT(COOK_TICK)` | Take the Stirrer's circles and drop them; restart `COOK_TICK` | PanEmpty |
| PanEmpty | `FLIP_PRESSED` | No points | PanEmpty |
| PanEmpty | `INGREDIENT_ADDED n` | Target from n; show its zone at once | Cooking |
| Cooking | `ES_TIMEOUT(COOK_TICK)` | Score circles, update the zone, post heat points, add up TOO MUCH time, restart `COOK_TICK` (steps below) | Cooking |
| Cooking | `ES_TIMEOUT(COOK_TICK)` [3 s straight in TOO MUCH] | Post `SCORE_DELTA` −10. Burn counter +1, so PIC2 plays the burnt sound. | Burnt |
| Cooking | `FLIP_PRESSED` | **+2** per flip up to the ingredient's ideal count, **−2** beyond | Cooking |
| Cooking | `INGREDIENT_ADDED m` | Post the leftover heat. Target from m. Reset the flip, circle and burn counts. | Cooking |
| Burnt | `ES_TIMEOUT(COOK_TICK)` | Score circles and update the zone; no heat points | Burnt |
| Burnt | `FLIP_PRESSED` | Flip points, as in Cooking | Burnt |
| Burnt | `INGREDIENT_ADDED m` | Clear the burn. Target from m. Reset the counts. | Cooking |
| PanEmpty, Cooking, Burnt | `GAME_END` | Score circles not yet taken, post pending heat, stop `COOK_TICK` | Off |
| PanEmpty, Cooking, Burnt | `GAME_RESET` | Stop `COOK_TICK`; pending heat is dropped | Off |

A repeat `INGREDIENT_ADDED` for an ingredient already added is ignored in every state.

**The steps of a `COOK_TICK`:**

| Step | What happens |
|---|---|
| Circles | Take the full circles the Stirrer counted since the last tick. With an ingredient in the pan (burnt or not), score **+1 per circle** up to that ingredient's ideal count and **−1 for each circle beyond** it. |
| Zone | Compare the hand distance with the target. **JUST RIGHT** is within ±4 cm, **TOO MUCH** is closer, **NOT ENOUGH** is farther. No hand, or a reading outside 3–40 cm, counts as NOT ENOUGH. The displayed zone only changes after 2 ticks agree. |
| Heat points | When not burnt: up to **+1 point per second** exactly on target, falling linearly to 0 at 8 cm off. Posted about once per whole point. |
| Burn | Time in TOO MUCH adds up; any other zone resets it. After **3 s** the ingredient burns (see the table above). |

**Per-ingredient values** (from `CookSM.h`):

| | Protein | Carb | Vegetables | Spice | Oil |
|---|---|---|---|---|---|
| Heat target | 14 cm | 24 cm | 32 cm | 28 cm | 10 cm |
| Ideal circles | 3 | 5 | 0 | 6 | 0 |
| Ideal flips | 2 | 4 | 1 | 3 | 0 |

**What PIC2 shows for each CookSM state:**

| CookSM state | LCD mode | LCD shows | Sound |
|---|---|---|---|
| Off | ATTRACT | Bar sweeps by itself; "WAITING FOR HEAT INPUTS"; bottom line blank | Music |
| PanEmpty | WAITING | Bar follows the hand; "WAITING"; "STIRS 0  FLIPS 0" | Music |
| Cooking | ZONE | Heat bar, band marks, zone label; "STIRS n  FLIPS n" for this ingredient | Music + sizzle for the zone |
| Burnt | ZONE | "BURNT"; counts keep updating | Burnt sound once, then music + sizzle |

---

## 5. ScoreSM

ScoreSM is the only service allowed to change the score. The dashboard shows the score live during cooking.

```mermaid
%%{init: {'themeVariables': {'fontSize': '16px'}}}%%
stateDiagram-v2
    Idle : Idle
    Idle : INGREDIENT_ADDED, SCORE_DELTA / ignore
    Active : Active
    Active : INGREDIENT_ADDED / ±10, show score
    Active : SCORE_DELTA / add, floor at 0, show score
    [*] --> Idle : ES_INIT
    Idle --> Active : GAME_START / score = 0, show 0
    Active --> Idle : GAME_RESET / score = 0
```

| State | Event [guard] | Service (action) | Next state |
|---|---|---|---|
| (power-up) | `ES_INIT` | Score = 0 | Idle |
| Idle | `GAME_START` | Score = 0; the dashboard shows 0 | Active |
| Idle | `INGREDIENT_ADDED`, `SCORE_DELTA` | Ignore | Idle |
| Active | `INGREDIENT_ADDED n` [first time] | **+10** if n is in this round's recipe, **−10** if not (see the dish table below). Floor at 0. Show the score. | Active |
| Active | `SCORE_DELTA` | Add CookSM's heat, burn, circle or flip change. Floor at 0. Show the score when the whole number changes. | Active |
| Active | `GAME_RESET` | Score = 0, without drawing over the Welcome banner | Idle |
| Any | A message from any other round | Ignore | same |

- **Recipe per round:** the recipe in use is latched at `GAME_START`. GameButtons picks a random dish at each Start (never the same twice in a row) and sets its recipe as the dish intro starts:

  | Dish | Right | Wrong | Recipe mask |
  |---|---|---|---|
  | Chicken fried rice | Protein, Carb, Spice, Oil | Vegetables | `0x1B` |
  | Chicken and broccoli stir-fry | Protein, Vegetables, Spice, Oil | Carb | `0x1D` |
  | Pasta aglio e olio | Carb, Spice, Oil | Protein, Vegetables | `0x1A` |

- **Floor at 0:** points lost below 0 are not remembered. For example, Vegetables first gives 0, then Protein gives 10.
- **`GAME_END` is deliberately ignored.** Changes earned in the round still count during the end sequence, such as the last circles and heat posted at End.

---

## 6. Other modules (not state machines)

The main loop polls these modules on every pass. None of them is an ES service.

- **Stirrer** (joystick → spoon and circles):
  - Samples the joystick ADC every 10 ms.
  - Learns the joystick's rest position at power-up (stick still for 0.3 s). When not cooking, it re-learns after the stick sits still for 3 s at a new spot.
  - **Circles:** outside the centre zone (60 counts), the stick's position falls in one of 8 sectors of 45°.
    - Moving one sector counter-clockwise adds a step; moving one sector clockwise removes one.
    - **±8 steps = one full circle**, in either direction.
    - Returning to the centre drops a partial circle, going back and forth cancels out, and a jump of 2 or more sectors is ignored.
    - CookSM takes the count on every tick.
  - **Activity:** a push, meaning the stick is held at least 150 counts from rest for 100 ms straight (one per push; it re-arms once the stick is back within 100 counts), or a completed circle. Noise and short glitches can't do either.
  - **Spoon:** follows X only while cooking; otherwise it sits at home. The filter chain is:
    1. median of the last 3 readings;
    2. a low-pass filter on X;
    3. the follower (deadband, per-side range, 10 µs per 20 ms slew);
    4. 4 µs output hysteresis.
- **Treat** (MG995 dispenser):
  - Closed at power-up.
  - Opens at the big score if the score is ≥ 50, then closes by itself **20 s after opening** (`TREAT_OPEN_MS`).
  - Every Dish intro commands closed.
  - While open it keeps receiving pulses; after a close, the pulses stop 2.5 s later and the gearbox holds the gate.
- **LED strips** (two MAX7219 strips): GameSM picks the screen. The screens are the Welcome banner, the dish banner, the dashboard (score, plus time counting 60 → 0), the end message with the score, and the big score.
- **E-ink pan:**
  - Shows the icons of added ingredients. Ingredients added within 0.5 s of each other share one refresh.
  - Starts clearing at the big score.
  - Also clears on Reset (idle timeout or link loss) and on faults.
- **PIC2:**
  - The LCD and sound follow CookSM (table in §4). Music always plays, and there is no zone-change chime.
  - The Start lamp is on in Welcome once the link is ready; the Finish lamp is on in Finishable.

---

## 7. Link loss and faults

- **Heartbeat:** PIC1 sends a heartbeat and PIC2 sends back inputs and readings.
  - If no frames arrive for 0.6 s, the link is not ready. The Start lamp stays off and Start is ignored until the link is back.
  - Every lifecycle boundary restarts the link session, and PIC2 resyncs within about 0.1–0.2 s.
- **Link drops during a round** (Dish intro, cooking or end sequence):
  - The link gets **1.2 s to resync**, so a momentary glitch keeps the round.
  - If it is still down after 1.2 s, GameButtons posts `GAME_ABORT` → Welcome, with no treat.
- **Any other fault** — a full queue, a timer that will not start, a display error — makes that service return `ES_ERROR`. GameSM goes to Fault and `ES_Run` ends. PIC1 then prints `FATAL: <reason>` and resets itself after 300 ms, back to power-up.

---

## 8. Event dictionary

Most events carry a **ticket** in `EventParam`. The real payload (ingredient, generation, timestamp, millipoints) sits in a slot owned by the receiving service. A repeated or stale ticket is used at most once and is otherwise ignored.

| Event | Payload | Posted by | Posted to |
|---|---|---|---|
| `START_PRESSED`, `FINISH_PRESSED` | press time, generation | GameButtons (PIC2 input edge) | GameSM |
| `USER_ACTIVITY` | detection time, generation | GameButtons (switch ON/OFF, flip, hand); Stirrer (joystick move) | GameSM |
| `SWITCH_FLIPPED` | ingredient n, time, generation | GameButtons (ON edge, inputs 0–4) | IngredientSM |
| `INGREDIENT_ADDED` | ingredient n, round | IngredientSM | ScoreSM, CookSM |
| `FLIP_PRESSED` | round | GameButtons (flip edge, only while GameSM accepts gameplay input) | CookSM |
| `SCORE_DELTA` | millipoints, round | CookSM | ScoreSM |
| `GAME_START` | generation | GameSM | IngredientSM, ScoreSM, CookSM |
| `GAME_END` | generation; completed or idle | GameSM | IngredientSM, CookSM |
| `GAME_RESET` | generation | GameSM | IngredientSM, ScoreSM, CookSM |
| `GAME_ABORT` | generation | GameButtons (link lost for 1.2 s) | GameSM |
| `ES_TIMEOUT`: `GAME_TICK_TIMER` (0) | 1 s countdown step | ES timer | GameSM |
| `ES_TIMEOUT`: `IDLE_TIMER` (1) | 20 s with no activity | ES timer | GameSM |
| `ES_TIMEOUT`: `RESULT_TIMER` (2) | 3 s big score | ES timer | GameSM |
| `ES_TIMEOUT`: `WELCOME_SCROLL_TIMER` (9) | 25 ms scroll step: Welcome, dish intro, end message | ES timer | GameSM |
| `ES_TIMEOUT`: `COOK_TICK_TIMER` (4) | 100 ms cook tick | ES timer | CookSM |

---

## 9. Deferred and open items

- **Deferred** (also listed in the spec):
  - a required ingredient order;
  - a pictorial recipe hint.
- **Course-spec notes:** the course asks for a displayed timeout condition after 20 s idle, and a "creative" display of elapsed time. Both were chosen as-is for now: straight to Welcome, and a 60 → 0 number.
- **Calibration on the built hardware:** the spoon pulse endpoints (`STIR_PULSE_MIN_US` / `STIR_PULSE_MAX_US`) and the final treat positions.
