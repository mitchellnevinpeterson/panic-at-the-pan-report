# Panic at the Pan

ME218a · Team 12. A PIC32 cooking arcade: add ingredients, control heat with a hovering hand, stir with a joystick and flip the pan.

**Status:** the final game (GameButtonsPIC1 + GameButtonsPIC2) runs on the built machine. Commit b877530 is the verified version (git tag `checked-off`). The November 18 rule changes after it (stir circles, spoon smoothing, per-ingredient flips, treat gate stays open) pass the host tests and still need a hardware run.

## Program the machine (final game)

Both PICs need their own image. Use VS Code with the MPLAB extension, opened at this project folder.

1. Turn the 3.3 V logic supply on and the 5 V / 12 V load power off. Connect SNAP to **PIC2**'s ICSP pins: MCLR pin 1, PGED1 pin 4, PGEC1 pin 5, VDD and GND.
2. Select project **GameButtonsPIC2**, configuration **default**. Clean, then **Make and Program Device**.
3. Move SNAP to **PIC1**. Select **GameButtonsPIC1**, configuration **default**. Clean, then **Make and Program Device**.
4. Unplug SNAP. Set all ingredient switches **OFF** and centre the joystick. Turn on load power, then reset or power-cycle both PICs.
5. Check that the boot is right:
   - the Start lamp lights;
   - the LCD sweeps with "WAITING FOR HEAT INPUTS";
   - music plays;
   - the treat moves to closed.

Full checklists, calibration and troubleshooting: [firmware/bench/game_buttons/README.md](firmware/bench/game_buttons/README.md). Other MPLAB projects (HeatPIC2Bench, LCDPIC2Bench, JoystickServoBench_2, …) are standalone tests; don't leave them on the PICs for the show.

## Start here

- [Hardware](hardware/README.md) — schematic plan and next steps.
- [Purchase list](purchase_list.md) — parts, availability and budget.
- [Firmware](firmware/README.md) — structure and build command.
- [Final game spec](final_game_spec.md) — decisions for the final version (Nov 17); wins over the brief where they differ.
- [Game brief](panic_at_the_pan_story.md) / [state machines](panic_at_the_pan_fsm.md) — how the game plays and how the firmware is structured (updated Nov 18 to the final game).
- [Course specification](ME218a_F26_Project_Spec_V2.pdf) — authoritative requirements.
- [Original slides](ME218A%20Design%20Review.pptx) — earlier concept.

Mechanisms: a joystick-driven spoon that swings side to side, and a servo-gated treat dispenser that opens for a score of 50 or more.

**Next:** run the November 18 changes on the machine; if one misbehaves, `git checkout checked-off` restores the verified firmware.
