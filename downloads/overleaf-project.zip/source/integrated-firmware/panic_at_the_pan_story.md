# Panic at the Pan — Game Story and Build Brief

ME 218a Fall 2026 · Karl's Kitchen · Team 12

**Updated November 18, 2026 to match the final game** (the GameButtonsPIC1 and GameButtonsPIC2 firmware). Earlier drafts described a spatula rotating like a clock hand, an LED-array pan, a rising flame, and scoring by stir time. None of those were built; the old text is in git history.

## 0. How to use this document

This brief describes **what the game is and how it plays**. Read it together with:

1. **ME218a_F26_Project_Spec_V2.pdf**: the course requirements. It wins on anything that is a *requirement*.
2. **[final_game_spec.md](final_game_spec.md)**: the exact rules and numbers. It wins over this brief wherever the two differ.
3. **[panic_at_the_pan_fsm.md](panic_at_the_pan_fsm.md)**: the state machines and the events between them.
4. **[firmware/bench/game_buttons/README.md](firmware/bench/game_buttons/README.md)**: how to flash, wire, calibrate and troubleshoot the machine.

---

## 1. The premise

A fire has knocked out the lab's appliances, and the SPDL has become Karl's Kitchen, an emergency mess hall running on low-voltage power. Our CHEF (Culinary Hardware Entertainment Fixture) is **Panic at the Pan**: a countertop cooking station where a player cooks a dish in about 60 seconds by juggling four things at once. They add the right ingredients, keep the heat right with their hand, stir with a joystick, and flip the pan.

The fun comes from **doing everything in parallel**, like real cooking. While one hand controls the heat, the other flips ingredient switches, stirs and flips. Nothing waits for anything else.

---

## 2. A game, start to finish

The machine sits in **Welcome mode**:

- The two LED strips scroll "Welcome to Panic at the Pan".
- Background music plays.
- The LCD heat bar sweeps by itself under "WAITING FOR HEAT INPUTS".
- The **Start button glows**.
- The E-ink pan is blank white.

A guest presses **Start**. The strips scroll **"YOUR DISH TODAY: chicken fried rice"** once, about 8 seconds. (Each game's dish is picked at random, never the same twice in a row; the others are chicken and broccoli stir-fry and pasta aglio e olio.) Then they switch to SCORE / TIME, showing 0 / 60, and the countdown begins. The pan is empty: the LCD reads "WAITING" and its bar simply follows the guest's hand.

The guest flips the **Protein** switch. A chicken icon appears on the E-ink pan, and the score jumps **+10**. The LCD now shows two marks: the "just right" band for protein, 14 cm above the sensor.

The guest holds a hand over the **ultrasonic sensor**: the closer the hand, the hotter the pan. The label follows the hand: NOT ENOUGH, JUST RIGHT or TOO MUCH. The **sizzle** changes with it. On target, the score climbs about **one point per second**.

With the other hand, they **stir**:

- The joystick swings a small spoon side to side over the pan.
- Every **full circle** of the joystick is one stir, scored on the spot.
- Chicken likes 3 stirs. A fourth costs a point.

They also **flip the pan**: the first two flips for chicken earn +2 each. A third would cost 2.

Next they add **Carb** (the rice):

- The new target is 24 cm, so the hand has to move to a new height.
- The stir and flip counts restart.
- Rice likes 5 stirs and 4 flips.

They get distracted and hold their hand too close. After **3 seconds in TOO MUCH**:

- The LCD reads **BURNT**, a buzz plays, and the score drops **10**.
- The rice earns no more heat points, but its stirs and flips still count.
- Adding the next ingredient clears the burn and gives a fresh target.

The guest also tries **Vegetables**. They don't belong in this dish: **−10**. The score never drops below zero.

At 30 seconds, the **Finish button lights up**: the player may stop whenever they like. They keep cooking until 50 seconds, then press it. (Otherwise the game would end on its own at 60 seconds, with "TIME'S UP".)

The ending:

1. The top strip scrolls **"GAME OVER"**, and the bottom strip shows the final score.
2. The score fills both strips in a big font for 3 seconds, and the E-ink pan clears.
3. With **50 points or more**, the **treat gate opens**. It closes by itself 20 seconds later, or as soon as the next guest presses Start.
4. The machine returns to Welcome.

If a guest wanders off and nothing is touched for **20 seconds**, the machine goes straight back to Welcome, with **no** treat.

---

## 3. Game rules (summary)

Exact values are in [final_game_spec.md](final_game_spec.md).

### 3.1 Timing

- **Start:** only a fresh Start press in Welcome starts the dish intro. Cooking and the 60 s clock begin when the intro text has scrolled off.
- **Game length:** the game ends by itself at **60 s**.
- **Finish:** ignored for the first **30 s**. After that the button is lit, and pressing it ends the game.
- **Countdown:** the strips show the remaining seconds, **60 → 0**.

### 3.2 Ingredients and recipe

- **Switches:** five toggle switches, one per ingredient.
- **Adding:** a switch turned **ON** adds its ingredient, **once per game**, in **any order**. Turning a switch OFF only counts as activity.
- **Dishes:** each game gets one of three dishes, picked at random and never the same twice in a row. Each right ingredient is **+10**, each wrong one **−10**:

  | Dish | Right | Wrong |
  |---|---|---|
  | Chicken fried rice | Protein, Carb, Spice, Oil | Vegetables |
  | Chicken and broccoli stir-fry | Protein, Vegetables, Spice, Oil | Carb |
  | Pasta aglio e olio | Carb, Spice, Oil | Protein, Vegetables |

  Aglio e olio has only three right ingredients, so reaching the 50-point treat takes more heat, stirring and flipping.
- **No hint:** there is no recipe hint. The player discovers the recipe.

| | Protein | Carb | Vegetables | Spice | Oil |
|---|---|---|---|---|---|
| Heat target (hand distance) | 14 cm | 24 cm | 32 cm | 28 cm | 10 cm |
| Ideal stirs (full circles) | 3 | 5 | 0 | 6 | 0 |
| Ideal flips | 2 | 4 | 1 | 3 | 0 |

### 3.3 Heat and burning

- **Target:** set by the most recently added ingredient.
- **Zones:** JUST RIGHT is the target **±4 cm**. TOO MUCH is closer than that; NOT ENOUGH is farther, or no hand at all.
- **Heat points:** up to **+1 point per second** exactly on target, falling linearly to 0 at 8 cm off. This is continuous scoring from an analog input, not a simple threshold.
- **Burning:** **3 s straight in TOO MUCH** burns the current ingredient: **−10** once, and the burnt sound plays. A burnt ingredient earns no more heat points. Adding the next ingredient clears the burn.

### 3.4 Stirring

- **Spoon:** the joystick's left-right position moves the spoon about **±22.5°**, during cooking only. Releasing the stick returns the spoon home.
- **One stir = one full joystick circle**, in either direction:
  - going back and forth does not count;
  - letting the stick return to the centre before the circle is complete cancels it.
- **Scoring:** each stir is scored at once. **+1 per circle** up to the ingredient's ideal count, then **−1 for each extra circle**. The count restarts with each new ingredient.

### 3.5 Pan flip

- **Sensor:** flipping the pan presses a limit switch.
- **Scoring:** **+2 per flip** up to the ingredient's ideal flip count, then **−2 for each extra flip**. The count restarts with each new ingredient.
- **Empty pan:** flips score nothing.

### 3.6 Scoring summary

| Source | Points |
|---|---|
| Right / wrong ingredient | +10 / −10 |
| Heat | up to +1 per second on target |
| Burn | −10 once per burnt ingredient |
| Stir | +1 per circle up to the ideal count, then −1 each |
| Flip | +2 per flip up to the ideal count, then −2 each |

The score is shown **live** on the strips and **never goes below 0**.

### 3.7 End of game and treat

- **End sequence** (60 s or Finish): an end message, then the big score for 3 s, then Welcome. The whole sequence takes well under 30 s.
- **Treat:** only if the final score is **≥ 50**. The gate opens at the big score and closes 20 s later, or sooner if the next game starts.

### 3.8 Idle timeout and activity

- **Timeout:** **20 s** with no activity during cooking ends the game and goes straight back to Welcome, with no treat.
- **Activity is:**
  - an ingredient switch turned ON or OFF;
  - the flip switch;
  - a joystick push or a completed stir circle (a resting stick's jitter doesn't count);
  - a hand within 40 cm of the sensor.

  Start and early Finish presses are not activity.

---

## 4. The physical machine

| Element | Type | Role | Hardware |
|---|---|---|---|
| 5 ingredient switches | Digital inputs | Add ingredients | Toggle switches on the PIC2 MCP23S17 expander |
| Start button with lamp | Digital input + lamp | Begin a game from Welcome | MCP GPA7; lamp lit in Welcome |
| Finish button with lamp | Digital input + lamp | End the game after 30 s | MCP; lamp lit from 30 s |
| Pan-flip limit switch | Digital input | Flip points | MCP GPA6 |
| Ultrasonic sensor (hover zone) | Non-contact, analog distance | Heat control | HC-SR04-style 5 V sensor on PIC2 (trigger buffer, echo divider) |
| Joystick | Two analog inputs (ADC X/Y) | Spoon position, stir circles | PIC1 pins 6 and 7 |
| Spoon servo (S51) | Actuator | Swings the spoon side to side | PIC1 pin 12 (OC4); powered from its own 5 V supply |
| Treat dispenser (MG995 servo gate) | Actuator | Opens for a score ≥ 50 | PIC1 pin 14 (OC2) |
| Score / timer strips | Display | Banners, live score and countdown, end message, big score | Two stacked 8×32 MAX7219 strips on PIC1 |
| E-ink pan | Display | Icons of the added ingredients | 2.9-inch IL0373 on PIC1 |
| Heat screen | Display | Heat bar, target band marks, zone or BURNT label, and the current ingredient's stir and flip counts | ST7789 LCD on PIC2 |
| Speaker | Audio | Music, sizzle that follows the zone, burnt buzz | PIC2 PWM → RC filter → PAM8302 amplifier |
| Two PIC32MX170F256B | Controllers | PIC1 runs the game; PIC2 handles inputs, LCD and sound | Linked over UART2 |

Wiring and pins: [game_buttons README](firmware/bench/game_buttons/README.md) and [hardware/docs](hardware/docs/pin_map.md).

---

## 5. How the design meets the spec

| Spec requirement | How Panic at the Pan meets it |
|---|---|
| Welcoming mode that invites play | Scrolling welcome banner, music, self-sweeping heat bar, glowing Start button |
| ~60 s game, never < 30 s | Auto-end at 60 s; Finish ignored before 30 s, and its lamp lights at 30 s |
| Creative display of elapsed time | 60 → 0 countdown number on the strips. Chosen as-is; still to review against the spec's wording |
| 20 s idle → timeout, then reset | GameSM idle timer goes straight back to Welcome. There is no separate timeout screen; this is noted in the spec |
| ≥ 3 distinct inputs | Ingredient switches, ultrasonic hover, joystick, flip switch, Start and Finish buttons |
| ≥ 3 feedback modes | LED strips, E-ink pan, LCD heat bar, sound, moving spoon, treat |
| Analog input used non-trivially | Ultrasonic distance → continuous heat points with a linear falloff, plus the LCD bar and sizzle zone. Joystick ADC → proportional spoon position and circle counting |
| Non-contact sensing | Ultrasonic hover zone |
| Electromechanical actuation beyond TREAT | PIC32-driven spoon servo |
| Visibly moving parts under PIC32 control | Spoon and treat gate |
| Completion indication ≤ 30 s, shows degree of completion | End message + big final score (about 6–8 s), treat for ≥ 50 points, then reset |
| Usable without words | Lit buttons, ingredient icons, heat bar with band marks, sizzle and burnt sound. The text banners help but are not needed to play |
| Only PIC32MX170F256B controls the CHEF | Two PIC32MX170F256B controllers |

---

## 6. Software architecture

### 6.1 Platform

- **MCU:** two **PIC32MX170F256B**, programmed in **C**.
- **PIC1** runs the ME 218 **Events and Services framework** with four state machines.
- **PIC2** runs a plain non-blocking loop: inputs, ultrasonic, LCD, audio and lamps.
- **Link:** the two exchange input edges, distance readings and a control heartbeat over UART2.

### 6.2 Rules the code follows

1. **No blocking code.** All timing uses framework timers or non-blocking polling.
2. **Each output device has exactly one owner.**
3. **The score has one owner** (ScoreSM). Nobody else changes it.
4. **Numbers are variables, not states.** Target, zone, elapsed time, circle and flip counts and score are variables; states only represent changes in behaviour.

### 6.3 State machines and modules (PIC1)

| Service | States | Owns |
|---|---|---|
| **GameSM** | Welcome, DishIntro, CookingEarly, CookingFinishable, GameOver, TimedOut, Fault | Banners and dashboard, game clock, idle timer, Start/Finish rules, lamps, when the treat may open |
| **IngredientSM** | Locked, Ready | Which ingredients were added |
| **CookSM** | Off, PanEmpty, Cooking, Burnt | Heat, burn, stir-circle and flip points; LCD and sound state for PIC2 |
| **ScoreSM** | Idle, Active | The score |

Polled modules (not state machines):

- **Stirrer:** joystick → spoon, and circle counting.
- **Treat:** the dispenser servo.
- **Score/timer display:** the LED strips.
- **ButtonEInk:** the E-ink pan.
- **GameButtons / PeerLink:** the UART2 link and input mapping.

The details are in [panic_at_the_pan_fsm.md](panic_at_the_pan_fsm.md).

### 6.4 Where the code lives

| Path | Contents |
|---|---|
| `firmware/bench/game_buttons/` | Both PIC mains, GameButtons adapter, Stirrer, Treat, E-ink pan, PIC2 sensor side |
| `firmware/bench/game_sm/BenchIO.c` | Fans GameSM actions out to the other services and to the displays and servos |
| `firmware/services/` | GameSM, IngredientSM, CookSM, ScoreSM |
| `firmware/link/` | UART2 PeerLink protocol |
| `firmware/pic2/` | MCP inputs, LCD heat view, audio |
| `firmware/drivers/` | LED strips, servos, joystick ADC |
| `firmware/config/` | `GameConfig.h` (timing), `ES_Configure.h` (services, events, timers) |

---

## 7. Tunable parameters

| What | Where |
|---|---|
| Game length, Finish gate, idle timeout, scroll speed, big-score time | `firmware/config/GameConfig.h` |
| Heat targets, band, falloff, burn time and penalty, ideal circles and flips, points per circle and flip | `firmware/services/include/CookSM.h` |
| Dishes: intro texts and recipes (`DISH_TEXTS`, `DISH_RECIPES`) | `firmware/config/GameConfig.h` |
| ±10 ingredient points, score floor at 0 | `firmware/bench/game_sm/BenchIO.c` |
| Treat threshold (50) and servo positions | `firmware/bench/game_buttons/Treat.h` |
| Spoon endpoints | `firmware/bench/game_buttons/Stirrer.h` |

---

## 8. Debug keys

Both PICs print to a debug UART at 115200 baud.

| Board | Key | Effect |
|---|---|---|
| PIC1 | `s` | Status: link, lamps, CookSM output, spoon/treat, distance, UART counters |
| PIC1 | `j` | Joystick/spoon report, including `circles=` |
| PIC1 | `o` / `c` / `+` / `-` / `d` | Treat: release, close, nudge 25 µs, servo registers |
| PIC1 | `a`, `1`–`5` | Simulated activity / ingredient switch (Start and Finish are physical only) |
| PIC2 | `s` | Status: MCP, link, raw inputs, lamps |

---

## 9. Build order and deadlines

| Date | Milestone | Firmware focus |
|---|---|---|
| 11/8 | Checkpoint 1: schematic, state diagram, BOM | Project skeleton, services registered, events defined |
| 11/13 | Checkpoint 2: 3 inputs sensed, ≥ 3-state SM on keyboard, actuation working | Keyboard test mode; Game, Ingredient and Score SMs; spoon servo moving |
| 11/17 | Checkpoint 3: everything integrated | GameButtons images on both PICs: all inputs, displays, sound, spoon and treat |
| 11/18 | Grading session and public show | Checked-off firmware (git tag `checked-off`) plus the Nov 18 rule changes |

---

## 10. Open items

1. **Deferred:**
   - a required ingredient order;
   - a pictorial recipe hint.
2. **Course-spec wording to review:** the displayed timeout condition after 20 s idle, and the "creative" display of elapsed time.
3. **Calibration on the built machine:** the spoon pulse endpoints.
4. **Hardware run still needed** for the November 18 changes (stir circles, spoon smoothing, per-ingredient flips, treat gate staying open). If any of them misbehaves, the `checked-off` tag is the last version verified on the machine.
