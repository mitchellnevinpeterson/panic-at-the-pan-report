# Panic at the Pan: final game spec

Team decisions recorded November 17, 2026. Where this conflicts with the [game brief](panic_at_the_pan_story.md) or the [FSM draft](panic_at_the_pan_fsm.md), this file wins. Deferred items are listed at the end.

## Game flow

| Stage | LED strips | E-ink pan | LCD (PIC2) | Sound | Lamps | Spoon / treat |
|---|---|---|---|---|---|---|
| **Power-up** | → Welcome | white | → Welcome | → Welcome | → Welcome | Treat servo moves to **closed** once |
| **Welcome** | "Welcome to Panic at the Pan" scrolls | white (no other content) | Bar sweeps by itself; label "WAITING FOR HEAT INPUTS" | Background music | Start **ON** (solid), Finish off | Spoon still at home |
| **Dish intro** (fresh Start press) | "YOUR DISH TODAY: …" scrolls once, naming this game's dish (see Dishes) | unchanged | Same as Welcome | Music | Both off | Still |
| **Cooking**: 60 s clock starts after the intro | Score and time dashboard; time counts **60 → 0** as a number | Icon of each added ingredient | Live heat bar and zone label, plus STIRS / FLIPS counts (see Heat) | Music + sizzle + burnt sound | Finish **ON** (solid) from 30 s | Spoon follows joystick |
| **End message** | Top strip scrolls **"TIME'S UP. GAME OVER"** (at 60 s) or **"GAME OVER"** (Finish pressed); bottom strip holds the final score | Icons stay visible | Same as Welcome | Music | Both off | Spoon returns home |
| **Big score**: after the message scrolls off | Final score in a big font across both strips, **3 s** | Starts clearing to white | Same as Welcome | Music | Both off | **Treat dispensed** if score ≥ 50 |
| → **Welcome** | | white | | | Start ON | An open treat gate closes **20 s after it opened**, or sooner if the next game starts |

- **Scroll speed:** all scrolling text runs at **2×** the old speed (25 ms per column). Dish intro ≈ 7.8 s (≈ 10 s for the stir-fry); end messages ≈ 4.8 s ("TIME'S UP. GAME OVER") or ≈ 2.6 s ("GAME OVER").
- **Finish button:** ignored before 30 s of cooking. After that it ends the game.
- **Idle timeout:** 20 s with no activity during the intro or cooking goes **straight back to Welcome**, with no treat; the E-ink clears.
- **Faults** (link lost, sensor failure): **automatically return to Welcome** instead of stopping.
- **Start presses** during the intro, cooking or end sequence are ignored. Start needs a fresh press, and a button held through a reset doesn't count.
- The whole end sequence (message + big score ≈ 5.6–7.8 s) stays under the spec's 30 s limit.

## Activity (resets the 20 s idle timer)

| Input | Counts as activity when |
|---|---|
| Ingredient switch | flipped **ON or OFF** |
| Joystick | a **push**: the stick is held at least **150 ADC counts** from its rest position for **100 ms** straight (the next push counts after it comes back within 100), or a **completed stir circle**. Holding a push, ADC noise and glitches never count. (Nov 18: two looser rules let a resting stick's noise keep games from timing out.) |
| Pan-flip limit switch | pressed |
| Ultrasonic | a hand reads **3–40 cm** for **3 readings in a row**; a hand **held** in range keeps counting. Over 40 cm means no hand; under 3 cm is noise. |

Start presses and early Finish presses are **not** activity.

## Ingredients and recipe

**Dishes:** each game's dish is picked **at random** when Start is pressed, never the same dish twice in a row. Right ingredients give **+10**, wrong ones **−10**:

| Switch (left → right) | 1 Protein | 2 Carb | 3 Vegetables | 4 Spice | 5 Oil |
|---|---|---|---|---|---|
| Chicken fried rice | right | right | **wrong** | right | right |
| Chicken and broccoli stir-fry | right | **wrong** | right | right | right |
| Pasta aglio e olio | **wrong** | right | **wrong** | right | right |

The heat target, ideal stir circles and ideal flips belong to each ingredient, whatever the dish:

| Switch (left → right) | 1 Protein | 2 Carb | 3 Vegetables | 4 Spice | 5 Oil |
|---|---|---|---|---|---|
| Heat target (hand distance) | 14 cm | 24 cm | 32 cm | 28 cm | 10 cm |
| Ideal stir circles | 3 | 5 | 0 | 6 | 0 |
| Ideal flips | 2 | 4 | 1 | 3 | 0 |

- Each ingredient counts **once per game**, added in **any order**. Switch **ON** adds it; **OFF** only counts as activity.
- A switch already ON when cooking starts must go OFF then ON to count.
- No recipe hint: the player discovers the recipe.
- A wrong ingredient only lowers the score; its icon still appears.

## Heat (ultrasonic → LCD + sound + score)

- The **most recently added** ingredient sets the target. The "just right" band is target **±4 cm**.
- **Zones:** NOT ENOUGH = farther than the band (or no hand), JUST RIGHT = inside the band, TOO MUCH = closer than the band.
- **LCD:**
  - The bar is full at **5 cm** and empty at **40 cm**.
  - Two zone marks show the current band and move when an ingredient is added.
  - Before the first ingredient, the bar follows the hand and the label reads **"WAITING"**.
  - After that, the label shows the zone, or **"BURNT"** once the current ingredient burns.
  - A bottom line below the panel shows **"STIRS n  FLIPS n"**: the current ingredient's full circles and flips so far (shown up to 99). Both restart at 0 with each new ingredient. The line shows 0 / 0 with an empty pan, and is blank on the Welcome, intro and end screens.
- **Heat points:** while an ingredient is in the pan and not burnt, at most **+1 point per second** with the hand exactly on target. This falls linearly to 0 at 8 cm from the target, computed every 100 ms.
- **Burning:** **3 s straight in TOO MUCH** burns the current ingredient, with **−10** once. A burnt ingredient earns **no more heat points**. Adding the next ingredient clears the burn and sets the new target. The burnt sound plays once.
- **Empty pan:** no sizzle and no heat points. Music keeps playing.

## Stirring (joystick → spoon + score)

- **Side to side:** the joystick's X position moves the spoon about **±22.5°** around the middle. Release returns it home (the middle). The exact pulse endpoints are calibrated on the mounted spoon.
- **Rest position:** learned at power-up (stick still for 0.3 s) and re-learned after 3 s still outside cooking. Not assumed to be 512; the bench stick rests near X = 330.
- **One stir = one full circle** of the joystick: pushed out of its centre zone, the stick goes all the way around once, in either direction. Going back and forth does not count, and returning to the centre before the turn is complete cancels that partial circle.
- **Stir points are live**, counted for the newest ingredient in the pan:
  - **+1 per circle** up to that ingredient's ideal count, then **−1 for every circle beyond** it.
  - **Vegetables** and **Oil** have an ideal of 0, so every circle costs −1.
  - The count restarts when the next ingredient is added.
  - A burnt ingredient still scores its circles.
  - Circles with an empty pan score nothing.
- Joystick moves count as activity for the idle timer (see Activity).
- The spoon is smoothed: single-sample spikes are dropped and tiny wobbles are ignored, so a still stick holds the spoon still.
- Outside cooking, the spoon stays still at home.

## Pan flip (limit switch, MCP GPA6)

- **For each ingredient:** **+2 per flip** up to that ingredient's ideal flip count, then **−2 for every flip beyond** it. The count resets when the next ingredient is added.
- **Oil** has an ideal of 0, so every flip costs −2.
- A burnt ingredient still scores its flips.
- **Empty pan:** flips score nothing, but still count as activity.

## Scoring summary

| Source | Points |
|---|---|
| Right / wrong ingredient | +10 / −10 |
| Heat | up to +1/s on target (see Heat) |
| Burn | −10 once per burnt ingredient |
| Stir | +1 per full circle up to the ideal count, then −1 each |
| Flip | +2 per flip up to the ideal count, then −2 each |

- The score **never goes below 0** and is shown live on the dashboard.
- **Treat** only if the final score is **≥ 50** and the game ended by Finish or 60 s.

## Treat dispenser (MG995, PIC1 pin 14)

- At power-up: move to **closed**.
- When the big score appears and the score is ≥ 50: rotate to **release**.
- **20 s after opening** it rotates back to **closed** by itself.
- When the next game starts (Start pressed): always rotate to **closed**, even if the 20 s are not up.
- Closed and release positions are calibrated on the built dispenser.

## Sound (PIC2 speaker)

- Background **music in every stage**, Welcome included.
- **Sizzle** follows the zone relative to the current target; nothing when the pan is empty.
- **No zone-change chime** (removed Nov 18): crossing a zone boundary changes only the sizzle.
- **Burnt sound** when an ingredient burns. No other effects.
- Volume fixed at **maximum**.

## E-ink pan display

- Black and white only (red artwork drawn black), fast custom waveform (~3.5 s per update), no cooldown.
- A refresh waits for a 0.5 s pause in switch flips, so a burst shares one refresh.
- Shows only the icons of added ingredients. Starts clearing to white when the end message finishes. Also clears on idle timeout and faults.

## Deferred / possible improvements

- Required ingredient order.
- A pictorial recipe hint.

**Spec notes:** the course spec asks for a displayed timeout condition after 20 s idle, and a "creative" display of elapsed time. Both were chosen as-is for now: straight to Welcome, and a 60 → 0 number.
