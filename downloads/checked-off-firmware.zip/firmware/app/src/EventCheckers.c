#include "EventCheckers.h"
#include "GameIO.h"

bool CheckGameInputs(void)
{
    return GameIO_Service();
}
