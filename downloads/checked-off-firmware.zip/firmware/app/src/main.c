#include "BoardConfig.h"
#include "ES_Framework.h"
#include "ES_Port.h"
#include "GameIO.h"

/* Inspect this symbol in the debugger if initialization or service run fails. */
volatile ES_Return_t FirmwareStatus = Success;

int main(void)
{
    /* Retain the course UART1/debug setup; UART2 belongs to the peer link. */
    _HW_PIC32Init();
    if (!GameIO_Init()) {
        FirmwareStatus = FailedInit;
        GameIO_Stop();
        for (;;) { }
    }
    FirmwareStatus = ES_Initialize(ES_Timer_RATE_1mS);
    if (FirmwareStatus == Success) {
        FirmwareStatus = ES_Run();
    }
    GameIO_Stop();
    /* Terminal fault halt: PIC2 independently mutes on heartbeat timeout. */
    for (;;) {
        /* Reset is required after a latched hardware/service/queue failure. */
    }
}
