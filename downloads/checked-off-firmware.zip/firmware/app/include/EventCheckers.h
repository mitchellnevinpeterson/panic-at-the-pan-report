#ifndef PANIC_EVENT_CHECKERS_H
#define PANIC_EVENT_CHECKERS_H
#include <stdbool.h>
bool CheckGameInputs(void);
#ifdef GAME_SM_BENCH
bool CheckGameBenchIO(void);
#endif
#endif
