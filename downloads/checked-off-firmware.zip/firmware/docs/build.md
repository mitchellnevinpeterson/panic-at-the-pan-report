# Build reference

Use GNU Make, Python 3, MPLAB XC32 and a PIC32MX Device Family Pack for `32MX170F256B`.

```sh
make -C firmware check
make -C firmware test
make -C firmware/pic1 DEBUG=1
make -C firmware/pic2 DEBUG=1
```

The top-level build creates both controllers and verifies 40 preserved lab/framework file hashes. Tests run host ASan/UBSan suites for the services, full PIC1 integration, e-ink scheduling, link and PIC2 inputs/range. No command flashes hardware.

Default images:
- `firmware/build/pic1_j1_s0_e1/panic_pic1.elf` and `.hex`
- `firmware/build/pic2/panic_pic2.elf` and `.hex`

PIC1 build choices: `JOYSTICK_MODE=1` uses the X-only checkpoint; `JOYSTICK_MODE=2` uses the angular experiment. `SPOON=0` disables pulses by default. `EINK=1` enables the asynchronous IL0373 adapter with its 180 s boot/refresh cooldown. These flags do not bypass gameplay calibration. Variants use separate build directories.

Compiler tools default to `PATH`; the DFP defaults to the last lexically sorted directory under `~/.mchp_packs/Microchip/PIC32MX_DFP/`. Override explicitly if needed:

```sh
make -C firmware check XC32_CC=/path/to/xc32-gcc \
  XC32_BIN2HEX=/path/to/xc32-bin2hex DFP_ROOT=/path/to/PIC32MX_DFP/version
```

Changing the compiler/pack requires a clean rebuild. PIC1 reserves 4 KiB stack and 1 KiB runtime heap; PIC2 reserves 2 KiB stack. Application code uses static storage. Linker maps establish allocation only; stack high-water and combined hardware timing still need measurement.

Each preserved bench has its own build and test targets: `game-sm`, `score-timer`, `joystick-servo`, `joystick-servo-2`, `eink`; append `-test` for host checks. New integrated images currently use Make; no new MPLAB project is claimed.
