# Firmware architecture

PIC1 runs six course Events and Services machines. PIC2 polls the input expander and ultrasonic sensor, drives audio and the Finish lamp, and exchanges packets with PIC1. Existing standalone benches remain separate images.

```mermaid
flowchart LR
    MCP[MCP switches] --> P2[PIC2 input debounce and range]
    US[Ultrasonic] --> P2
    P2 <-->|UART2: epochs, timestamps, CRC, ACK| IO[PIC1 GameIO]
    J[Joystick ADC and selected follower] --> IO
    IO --> G[GameSM]
    G -->|Reset / Start / End| S[Ingredient / Heat / Stir / Score / Pan]
    S --> IO
    IO --> D[Status display and asynchronous e-ink]
    IO --> M[Configured spoon output]
    P2 --> A[Audio and Finish lamp]
```

| Path | Responsibility |
|---|---|
| `app/` | PIC1 startup and the framework input checker |
| `services/` | Six device-independent state machines with owned event tickets |
| `config/` | Event priorities/timers, timing rules, explicit gameplay calibration |
| `pic1/GameIO.c` | Lifecycle fan-out, input authority, output ownership, terminal failure handling |
| `pic1/Pic1Board.c` | Existing pins, ADC/follower, spoon enable, asynchronous SPI1 byte transfers |
| `pic1/EInkAsync.c`, `PanCanvas.c` | IL0373 refresh sequencer and incremental icon/text composition |
| `link/` | Shared UART2 packet protocol and nonblocking UART queues |
| `pic2/` | MCP23S17, debounce, nonblocking range, adapted teammate audio, separate startup |
| `bench/` | Preserved independent checkpoints, each with its own Makefile/main |
| `tests/` | Host boundary, state-transition, transport, renderer and integration tests |
| `vendor/`, `drivers/reused/` | Preserved course sources and provenance |

## Lifecycle and event ownership

Welcome continuously scrolls. A fresh synchronized Start enters the dish banner. Only completion of that banner starts the full 60-second clock and 20-second idle deadline. Finish becomes eligible at 30 seconds of cooking. A valid Finish or 60-second completion holds the result 10 seconds and requests one treat; idle timeout holds 5 seconds and requests none.

GameSM owns banner/dashboard mode, clocks, Finish eligibility and treat requests. IngredientSM accepts each category once after Start. Heat owns heat/burn state and audio requests. Stir counts observed angular-motion intervals and publishes the final ingredient result at End. Score is the sole score accumulator. Pan owns semantic icon/playing/result states.

Services use bounded owned messages: 16-bit ES payloads are tickets, never pointers. Input generation changes at each reset/start/end. Earned scoring retains the round ID through results. Lifecycle capture/deadline timestamps survive queue delay. Stale input, duplicate ingredients, expired timers and previous-round messages cannot restart a completed game. Every fan-out is checked; failure stops local motion and eventually mutes PIC2 through its link watchdog.

Priority, low to high: Pan, Score, Stir, Heat, Ingredient, Game. Ten ES timer slots retain the existing allocation. The framework, timer source and debug UART1 are unchanged. The extended clock is sampled continuously, using the free-running Core counter.

## Controller link

UART2 remains separate from debug serial. CRC-protected escaped frames carry epoch and sequence information. PIC2 debounces active-low inputs, rearms only after a stable release, queues reliable press edges and retries until acknowledged. Epoch changes and link loss clear old input queues and release gates. Controller commands repeat in heartbeats; loss disables audio/lamp. PIC1 inhibits Start until synchronization and faults if an established link is lost during intro/cooking.

PIC2 maps detection time into a conservative PIC1 clock estimate before enqueueing. Delivery delay cannot make a premature Finish eligible. The current 20 ms allowance means a physical press exactly at 30 seconds can be rejected briefly; exact cross-clock edge timing needs measured oscillator/transport bounds. See [protocol details](../link/README.md).

Captured Finish time determines eligibility and the frozen countdown. Score preserves awards already processed before PIC1 receives End, including the final observed stir result; it does not retroactively remove awards after the remote press timestamp. That acceptance-order boundary matters when an input is delayed or retried.

## Configured and pending behavior

Default `GameTuning.configured=false` allows lifecycle, ingredients, zero score and logical Pan states. It disables formal scoring, heat output and Stir motor authorization. A true configuration must validate recipe, distance mapping, targets, scoring and motion policy; there are no guessed gameplay defaults. The explicit +10 rule remains confined to GameSMBench. [Pending decisions](pending_decisions.md).

PIC1 defaults to the tested X-only follower implementation. Angular CW/CCW is selectable; its original bench remains intact. X mode supplies no angular stirring credit. Spoon PWM is separately disabled until its combined-board use and mounted travel are approved. The 1250/1500/1750 us pulse checkpoint does not establish degrees.

The e-ink adapter uses only the tested IL0373 sequence and coalesces semantic requests. Both frame composition and transfer are incremental, so UART/ADC/game timers keep running during a refresh. The 180-second interval applies from completion and from boot; frequent reset cannot bypass it. The reported 3–5 second refresh duration is separate from this cooldown. Rapid icons/swirl are logical states, not a promised physical animation.

The ninth MAX7219 heat bar and treat mechanics are unconfigured. Heat/treat requests remain inspectable in debugger variables; no additional pins or drivers are enabled. Deprecated scaffold driver contracts are not linked into either production image.
