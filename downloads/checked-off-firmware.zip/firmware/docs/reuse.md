# Lab code provenance

All copied sources are from the local course materials supplied by the team.
Original comments and attribution are retained; no new license is asserted over
the course files. Do not publish them under a blanket project license without
checking the course authors' terms.

| Destination | Local source | Treatment |
|---|---|---|
| `vendor/es_framework/FrameworkHeaders/` | `../Lab3/Lab3_Part4/FrameworkHeaders/` | Every `.h` except app-specific `ES_Configure.h` copied unchanged |
| `vendor/es_framework/FrameworkSource/` | `../Lab3/Lab3_Part4/FrameworkSource/` | All `.c` copied unchanged |
| `drivers/reused/PIC32_SPI_HAL.c/.h` | Lab 3 Part 4 ProjectSource/ProjectHeaders | Latest local revision of the Lab 2 SPI work, unchanged |
| `drivers/reused/DM_Display.c/.h` | Lab 3 Part 4 ProjectSource/ProjectHeaders | Existing display HAL, unchanged |
| `drivers/reused/FontStuff.c/.h` | Lab 3 Part 4 ProjectSource/ProjectHeaders | Existing font helpers, unchanged |
| `vendor/pic32_adc/` | Team-supplied `PIC32_AD_Lib/` | `.c`, `.h` and PDF guide moved unchanged; not linked |
| `vendor/pic32_pwm/` | Team-supplied `PIC32_PWM_Lib/` | `.c`, `.h` and PDF guide moved unchanged; not linked |

Lab 1 contains schematic/report material, not a standalone C module needed here.
The latest Lab 3 versions avoid copying competing implementations of the same
Lab 2 functions. Lab main programs, test services, IDE caches, compiled objects,
and archives are intentionally excluded.

`reuse_manifest.json` records project-root-relative source/destination paths and
SHA-256 for each copied file. `python3 firmware/tools/check_reuse.py` verifies the
copies without requiring access to the sibling lab folders.

The ADC/PWM manifest source paths record their original upload locations before
the move. See [library integration notes](../vendor/README.md) for ADC/timer ownership.

The only project-authored file under the framework tree is
`FrameworkHeaders/ES_Configure.h`, a forwarding include to
`firmware/config/ES_Configure.h`. Some upstream source files use relative includes;
the shim preserves them while putting editable registration in one place.

## Platform assumptions inherited unchanged

- 40 MHz SYSCLK, 20 MHz peripheral clock, ES tick on the MIPS core timer.
- Configuration words select internal FRCPLL and PGEC1/PGED1 debugging.
- UART1 currently maps RX to RB6 and TX to RB7, 115200 baud. The alternative
  RB2/RB3 branch in `terminal.c` is disabled (`USE_RB2_3` is not defined).
- `LED_DEBUG` is commented out in `ES_Port.c`; enabling it reserves RB15.
- Lab SPI setup used SCK1 RB14, SDO1 RA1, and SS1 RA0. That setup is **not called**
  by the scaffold. [Pin map V3](../../hardware/docs/pin_map.md) retains these display
  pins with manual SS. Main SPI2 serves status displays; a second PIC SPI1 serves MCP23S17. Initialization is pending.
- Lab SPI1 SS-edge detection uses external interrupt flag INT4. Any active reuse
  must reserve that resource or replace the completion mechanism.

Compilation is evidence of toolchain compatibility, not proof that every copied
API was exercised in the labs. See `../README.md` for the blocking display call,
unimplemented SPI entry points, and font warning discovered during inspection.

## Integrated targets — November 15, 2026

PIC1 links the existing course ES framework, nonblocking status display, ADC/S51 drivers and one selected standalone follower implementation; bench mains/configuration files remain separate. PanCanvas reads the approved generated ingredient masks. EInkAsync ports the tested IL0373 sequence into incremental operations and retains the Adafruit MIT notice and 180-second interval.

PIC2 links the unchanged teammate `DeviceConfig.c` and `sizzle.h`; `pic2/Audio.c` adapts `heat_audio.c` PWM/sample behavior to PIC1-controlled mute/zones. It does not link teammate `display.c` or reuse its conflicting pin17 output. New link, input, range, MCP, service and integration code lives in the project directories. Preserved-source and checkpoint hashes were checked after implementation.
