# Timer and score state machines

**Current milestone — November 12, 2026:** GameSM, IngredientSM and ingredient-only ScoreSM run together in [GameSMBench](../bench/game_sm/README.md).

## GameSM

| State | Status display | Exit |
|---|---|---|
| Welcome | Repeat `Welcome to Panic at the Pan` | Fresh Start press |
| DishIntro | Scroll `YOUR DISH TODAY: chicken fried rice` once | Text leaves the display |
| Cooking.Early | SCORE / TIME, starting at 0 / 60 | 30 seconds elapsed |
| Cooking.Finishable | Live score, countdown 30 → 0 | Valid Finish or 60 seconds elapsed |
| GameOver | Hold score and remaining time | 10-second result hold |
| TimedOut | Hold score and remaining time | 5-second timeout hold |

**The 60-second game begins after DishIntro.** Timer 9 handles both scrolling banners at one pixel per 50 ms. The 35-character dish message takes about 15.6 seconds to cross the 32-pixel display. Game/idle timers stay off during the intro; Start, Finish and ingredient presses do not interrupt it.

At intro completion, GameSM advances generation, records the cooking start time, selects 0/60, publishes `GAME_START` and arms game/idle timers. Inputs captured during either banner cannot carry into play. Physical Start debounce and release-to-rearm remain TODO.

- Finish becomes eligible at 30 cooking seconds. Eligibility uses the press timestamp, not queue-processing time.
- Every accepted activity renews the 20-second idle deadline. An ingredient key still counts as activity when its ingredient is a duplicate.
- At 60 cooking seconds, complete normally even if idle expires simultaneously. A press at an earlier idle deadline cannot revive play.
- Completion requests one treat; idle timeout requests none. Result expiry resets services and returns to Welcome.
- Remaining time comes from clock minus cooking-start time. Timer events request updates; they do not add an assumed second.

Queue deadlines and wrap-safe timestamps reject stale timer/input events. The bench extends the course 16-bit clock in frequent foreground polls. UART timestamps represent foreground reads; second-PIC timestamp translation remains TODO.

## ScoreSM

The current **bench rule is +10 per new ingredient**, maximum 50 for five ingredients. `GameBenchConfig.h` supplies that explicit tuning. The dish name does not yet assign recipe membership to ingredient keys.

| Event | Implemented behavior |
|---|---|
| `GAME_START` after DishIntro | Enter Active at zero; enable score-field updates |
| Accepted `INGREDIENT_ADDED(n)` | Add 10 once per ingredient and update the display |
| Duplicate ingredient publication | Ignore; do not score twice |
| Game ends (no ScoreSM event in this bench) | Remain Active so already-earned queued credit can drain; retain score |
| `GAME_RESET` | Clear score/mask, enter Idle, and leave the banner intact |

Only trusted IngredientSM acceptance calls `ScoreSM_PostIngredient`. Its owned ticket carries the earned playing-round ID. That ID remains valid through results even though GameSM advances its input generation at End. Old-round messages cannot change the next game or draw over Welcome/DishIntro.

Formal recipe rewards/penalties, heat points, burn penalties, final-stir points, weights and negative-score policy remain TODO. The target design allows a final stir result after End; its payload and exactly-once contract are not implemented by this ingredient-only milestone.

## Shared display

GameSM owns Welcome/DishIntro/Dashboard mode and remaining seconds; ScoreSM owns score changes. When the dish finishes, the foreground adapter batches `ShowLabels()`, `SetScore(0)` and `SetTimerSeconds(60)` before servicing the pending dashboard frame. Later score and time setters preserve each other's fields.

One foreground owner calls `ScoreTimerDisplay_Service()`. The driver sends immutable snapshots over SPI2 for eight MAX7219s. Adding the ninth heat driver still requires extending the transport/frame. The separate score/timer demo's automatic +10 per second is not game scoring.

[Full target FSM](../../panic_at_the_pan_fsm.md) · [Display API](../drivers/include/ScoreTimerDisplay.h)
