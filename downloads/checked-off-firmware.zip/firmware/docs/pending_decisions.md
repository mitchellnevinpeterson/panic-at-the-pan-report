# Remaining decisions and hardware checks

The integrated PIC1/PIC2 targets build; they have not been flashed or jointly tested. Keep using the standalone checkpoints while wiring. No source change confirms a physical connection.

| Item | Current boundary | Required decision/check |
|---|---|---|
| Formal scoring | Full-game score stays 0; bench keeps explicit +10 | Recipe mask; right/wrong/burn points; heat points/second; stir maximum points and approved scoring curve; negative-score policy |
| Heat | Disabled until valid tuning | Calibrated distance range, five normalized targets, fresh-sample age; choose whether a new ingredient preserves or resets a live burn timer |
| Stir | Angular scoring disabled without calibration | Motion threshold/timeout, home convention, stir optima; choose X checkpoint or CW/CCW behavior |
| S51 spoon | Pulses disabled by default in integrated image | Approve combined-board use and measured mounted travel within desired ~90 degrees; confirm signs/endpoints |
| E-ink | IL0373; asynchronous full refresh, 180 s cooldown including boot | Decide gameplay presentation compatible with this interval, or obtain evidence for a shorter approved interval |
| Heat bar | Logical heat request only; eight status drivers unchanged | Wire/validate ninth MAX7219, 24 LED mapping and burn-warning appearance |
| Treat | One pending request per completed game; pin14 held LOW | Servo/mechanics, safe closed/release positions and shared Timer2 ownership |
| Audio | Game-controlled zones implemented on PIC2 | Validate filter/amplifier/speaker and combined load; choose distinct burnt sound if desired |
| Hand activity | Calibrated range entry counts; held-hand repeats disabled | Decide whether a held hand counts as repeated activity |
| Switches | Debounced active-low press edges; stable-release rearm | Confirm actual switch polarity/contact behavior; flip remains disabled |
| UART2 | Epoch,CRC,ACK/retry, watchdog and conservative timestamps | Cross TX21 → RX17 both ways, common ground; measure clock/transport delay and input boundary behavior |
| Combined timing | All foreground work is bounded/incremental | Measure UART margin, ultrasonic timing under audio load, ADC behavior and supply stability |

Use [Pic1Config.h](../pic1/Pic1Config.h) for hardware enable choices and [GameConfig.c](../config/GameConfig.c) for approved gameplay tuning. Values in tests are synthetic fixtures only.

Finish and countdown use PIC1 time. A mapped PIC2 edge is deliberately biased early by20 ms, so an exactly 30-second physical Finish may need slightly later retry; no queued premature press ages into eligibility. This accuracy limit requires hardware measurement, not a guessed smaller allowance.

Optional flip input/animation/scoring remain outside the baseline. No flame servo exists. PIC2 e-ink code from the teammate Combined image is never linked: it conflicts with MCP SPI1 and UART2 pin17.
