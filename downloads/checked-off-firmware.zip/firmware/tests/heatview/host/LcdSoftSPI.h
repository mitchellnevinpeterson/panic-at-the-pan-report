#ifndef PANIC_LCD_SOFT_SPI_H
#define PANIC_LCD_SOFT_SPI_H
/* Host stand-in: HeatView only needs the transport entry points. */
#include <stdbool.h>
#include <stdint.h>
void display_spi_start(void);
bool display_spi_write(uint8_t value);
#endif
