// Checks that every SCK half period of the real LcdSoftSPI transport lasts
// at least LCD_HALF_BIT_TICKS core-timer ticks (and not much more).
#include "LcdSoftSPI.h"
#include <cassert>
#include <cstdio>
#include <cstdlib>
#include <vector>
uint32_t host_lat, host_tris, host_ans, host_odc, host_cn, host_pu, host_pd;
RegisterWrite LATBSET{&host_lat,true,true}, LATBCLR{&host_lat,false,true};
RegisterWrite TRISBCLR{&host_tris,false,false}, ANSELBCLR{&host_ans,false,false};
RegisterWrite ODCBCLR{&host_odc,false,false}, CNENBCLR{&host_cn,false,false};
RegisterWrite CNPUBCLR{&host_pu,false,false}, CNPDBCLR{&host_pd,false,false};
uint32_t SYSKEY, RPB5R, RPB7R, RPB9R, RPB13R;
HostJtag DDPCONbits;
HostConfig CFGCONbits;
static bool irq = true;
static uint32_t ticks;
static std::vector<uint32_t> edges;
unsigned host_disable(void) { unsigned old=irq; irq=false; return old; }
void host_enable(void) { irq=true; }
uint32_t host_count(void) { return ++ticks; }
void RegisterWrite::operator=(uint32_t mask) const {
    uint32_t before=*value;
    *value=set ? before|mask : before&~mask;
    if (output && ((before ^ *value) & LCD_SCK)) edges.push_back(ticks);
}
int main(int argc, char **argv) {
    const uint32_t half = argc > 1 ? (uint32_t)std::atoi(argv[1]) : 40u;
    display_spi_start();
    for (uint32_t start : {1000u, 0xffffff00u}) { // also across timer wrap
        ticks = start;
        edges.clear();
        const uint32_t t0 = ticks;
        assert(display_spi_write(0xA5));
        assert(edges.size() == 16); // 8 rising + 8 falling
        uint32_t prev = t0, max_gap = 0;
        for (size_t i = 0; i < edges.size(); ++i) {
            const uint32_t gap = edges[i] - prev; // first: setup before first rising edge
            assert(gap >= half);
            assert(gap <= half + 3u);
            if (gap > max_gap) max_gap = gap;
            prev = edges[i];
        }
        std::printf("half-bit %u ticks: SCK half periods %u..%u ticks, byte = %u ticks\n",
                    (unsigned)half, (unsigned)half, (unsigned)max_gap, (unsigned)(ticks - t0));
    }
    return 0;
}
