#ifndef PANIC_HOST_TERMINAL_H
#define PANIC_HOST_TERMINAL_H
#include <stdint.h>
uint8_t Terminal_ReadByte(void);
void Terminal_MoveBuffer2UART(void);
#endif
