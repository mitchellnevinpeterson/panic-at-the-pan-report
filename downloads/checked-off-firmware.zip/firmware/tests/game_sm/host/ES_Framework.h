/* Host boundary for the actual GameSM; no alternative state machine. */
#ifndef PANIC_HOST_ES_FRAMEWORK_H
#define PANIC_HOST_ES_FRAMEWORK_H
#include <stdbool.h>
#include <stdint.h>
#include "ES_Events.h"
typedef enum { ES_Timer_ERR = -1, ES_Timer_OK = 0 } ES_TimerReturn_t;
bool ES_PostToService(uint8_t service, ES_Event_t event);
ES_TimerReturn_t ES_Timer_InitTimer(uint8_t timer, uint16_t delay);
ES_TimerReturn_t ES_Timer_StopTimer(uint8_t timer);
uint16_t ES_Timer_GetTime(void);
#endif
