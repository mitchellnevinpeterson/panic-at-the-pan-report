#ifndef PANIC_HOST_XC_H
#define PANIC_HOST_XC_H
#include <stdint.h>
typedef struct { unsigned URXDA, OERR, FERR, PERR; } HostUARTStatus;
extern HostUARTStatus U1STAbits;
extern uint32_t U1STACLR, U1RXREG;
#define _U1STA_OERR_MASK 2u
#endif
