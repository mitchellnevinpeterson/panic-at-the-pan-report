/* Real GameSM + IngredientSM + ScoreSM + UART adapter; fake hardware and ES queue/timers.
 * Dispatch the same higher-priority-first ordering as the course framework.
 */
#include "BenchIO.h"
#include "GameSM.h"
#include "IngredientSM.h"
#include "ScoreSM.h"
#include <string.h>
#include "GameConfig.h"
#include "ScoreTimerDisplay.h"
#include "ES_Framework.h"
#include "xc.h"
#include <assert.h>
#include <stdio.h>

#if NUM_SERVICES != 3
#error "This integration fixture requires the three-service bench configuration."
#endif
HostUARTStatus U1STAbits;
uint32_t U1STACLR, U1RXREG;
static uint32_t clock_ms;
static struct { ES_Event_t events[32]; unsigned head, count; } queues[3];
static struct { bool active; uint32_t due; } timers[16];
static int reject_priority = -1;
static unsigned remaining, score;
static bool banner_mode;
uint16_t ES_Timer_GetTime(void) { return (uint16_t)clock_ms; }
uint8_t Terminal_ReadByte(void)
{
    assert(U1STAbits.URXDA); U1STAbits.URXDA = 0; return (uint8_t)U1RXREG;
}
void Terminal_MoveBuffer2UART(void) {}
bool ScoreTimerDisplay_Init(const ScoreTimerDisplay_Config *c) { return c != 0; }
ScoreTimerDisplay_State ScoreTimerDisplay_Service(void) { return SCORE_TIMER_IDLE; }
bool ScoreTimerDisplay_ShowLabels(void) { banner_mode = false; return true; }
bool ScoreTimerDisplay_SetScore(int32_t n) { assert(!banner_mode && n >= 0 && n <= 50); score = (unsigned)n; return true; }
bool ScoreTimerDisplay_SetTimerSeconds(uint32_t n) { assert(n <= 60); remaining = n; return true; }
bool ScoreTimerDisplay_SetBanner(const char *s, int16_t x)
{
    assert(s && x >= -(int)strlen(s) * 8 && x <= 32); banner_mode = true; return true;
}
bool ES_PostToService(uint8_t priority, ES_Event_t event)
{
    assert(priority < 3);
    if (priority == reject_priority || queues[priority].count == 32) return false;
    queues[priority].events[(queues[priority].head + queues[priority].count++) % 32] = event;
    return true;
}
ES_TimerReturn_t ES_Timer_InitTimer(uint8_t timer, uint16_t delay)
{
    assert(timer < 16 && delay > 0);
    timers[timer].active = true; timers[timer].due = clock_ms + delay;
    return ES_Timer_OK;
}
ES_TimerReturn_t ES_Timer_StopTimer(uint8_t timer)
{
    assert(timer < 16); timers[timer].active = false; return ES_Timer_OK;
}
static bool dispatch(unsigned p)
{
    assert(queues[p].count);
    ES_Event_t event = queues[p].events[queues[p].head];
    queues[p].head = (queues[p].head + 1) % 32; --queues[p].count;
    ES_Event_t result = p == 2 ? SERV_2_RUN(event) : p == 1 ? SERV_1_RUN(event) : SERV_0_RUN(event);
    if (result.EventType == ES_ERROR) return false;
    assert(result.EventType == ES_NO_EVENT);
    return true;
}
static bool drain(void)
{
    unsigned guard = 200;
    while (queues[0].count || queues[1].count || queues[2].count) {
        assert(guard--);
        unsigned p = queues[2].count ? 2 : queues[1].count ? 1 : 0;
        if (!dispatch(p)) return false;
    }
    return true;
}
static void tick(void)
{
    ++clock_ms;
    /* Deliberately queue idle before game tick at simultaneous expiration. */
    for (int t = 15; t >= 0; --t) {
        if (timers[t].active && clock_ms == timers[t].due) {
            timers[t].active = false;
            assert(PostGameSM((ES_Event_t){ES_TIMEOUT, (uint16_t)t}));
        }
    }
}
static void step(uint32_t duration)
{
    while (duration--) {
        tick(); assert(drain());
        assert(!CheckGameBenchIO()); /* No UART byte available; display still polls. */
        assert(drain());
    }
}
static void send_key(char c)
{
    U1STAbits.URXDA = 1; U1RXREG = (uint8_t)c;
    assert(CheckGameBenchIO());
}
static void key(char c) { send_key(c); assert(drain()); }
static void welcome(void)
{
    assert(QueryGameSM() == GAME_WELCOME && banner_mode);
    assert(QueryScoreSM() == SCORE_IDLE && ScoreSM_Value() == 0);
    assert(QueryIngredientSM() == INGREDIENT_LOCKED && IngredientSM_AddedMask() == 0);
}
static void begin(void)
{
    key('b');
    assert(QueryGameSM() == GAME_DISH_INTRO && QueryIngredientSM() == INGREDIENT_LOCKED);
    assert(QueryScoreSM() == SCORE_IDLE && banner_mode);
    key('1'); key('f'); key('b'); /* Intro input cannot earn or restart. */
    step(DISH_INTRO_MS);
    assert(QueryGameSM() == GAME_COOKING_EARLY && QueryIngredientSM() == INGREDIENT_READY);
    assert(IngredientSM_AddedMask() == 0 && remaining == 60 && score == 0);
}
int main(void)
{
    assert(GameBenchIO_Init());
    assert(SERV_0_INIT(0)); assert(SERV_1_INIT(1)); assert(SERV_2_INIT(2)); assert(drain()); welcome();
    key('1'); welcome(); /* Ingredient cannot start a game. */
    begin();
    key('1'); key('1');
    assert(IngredientSM_AddedMask() == 1 && score == 10);
    key('5'); key('3'); key('2'); key('4'); assert(IngredientSM_AddedMask() == 0x1f);
    step(10000); key('1'); /* Duplicate still renews idle timing. */
    step(10000); assert(QueryGameSM() == GAME_COOKING_EARLY); key('1');
    step(10000); assert(QueryGameSM() == GAME_COOKING_FINISHABLE); key('f');
    assert(QueryGameSM() == GAME_OVER && QueryIngredientSM() == INGREDIENT_LOCKED);
    assert(IngredientSM_AddedMask() == 0x1f && remaining == 30 && score == 50);
    key('1'); assert(IngredientSM_AddedMask() == 0x1f);
    step(10000); welcome();

    /* Welcome input queued across Start must not appear in the next round. */
    uint32_t welcome_generation = GameSM_InputGeneration();
    assert(IngredientSM_PostSwitch(1, clock_ms, welcome_generation));
    begin(); assert(IngredientSM_AddedMask() == 0);
    key('1'); assert(IngredientSM_AddedMask() == 1); /* Fresh round accepts again. */
    step(10000); key('a'); step(10000); key('a'); step(10000);
    assert(clock_ms > UINT16_MAX); /* Actual BenchIO extended its course clock. */
    /* Earned ingredient is waiting in Score's lower-priority queue. */
    send_key('2'); assert(dispatch(2)); assert(dispatch(1));
    assert(score == 10 && queues[0].count == 1 && IngredientSM_AddedMask() == 3);
    /* Another switch is still unaccepted when high-priority Finish arrives. */
    assert(IngredientSM_PostSwitch(2, clock_ms, GameSM_InputGeneration()));
    key('f');
    assert(QueryGameSM() == GAME_OVER && IngredientSM_AddedMask() == 3 && score == 20);
    assert(QueryIngredientSM() == INGREDIENT_LOCKED);
    step(10000); welcome();

    begin(); key('1');
    for (int n = 0; n < 4; ++n) { step(10000); key('1'); }
    step(19999); tick(); /* Both 60-second end and idle expiration are queued. */
    key('2');
    assert(QueryGameSM() == GAME_OVER && remaining == 0 && IngredientSM_AddedMask() == 1);
    assert(QueryIngredientSM() == INGREDIENT_LOCKED);
    step(10000); welcome();

    begin(); step(19999); tick(); key('1'); /* Exact idle deadline cannot revive play. */
    assert(QueryGameSM() == GAME_TIMED_OUT && remaining == 40);
    assert(QueryIngredientSM() == INGREDIENT_LOCKED && IngredientSM_AddedMask() == 0);
    step(5000); welcome();

    begin(); step(19998); key('1'); step(2);
    assert(QueryGameSM() == GAME_COOKING_EARLY && IngredientSM_AddedMask() == 1);
    /* Partial input fan-out must halt, not silently omit the ingredient. */
    reject_priority = 1; send_key('2');
    assert(!drain() && GameSM_HasFault() && IngredientSM_HasFault());
    assert(IngredientSM_AddedMask() == 1);
    puts("Game/Ingredient/Score integration passed: UART routing, priority, activity, stale input, deadlines, reset and failure.");
    return 0;
}
