#include "IngredientSM.h"
#include "ES_Framework.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static ES_Event_t queue[32];
static unsigned head, count, accepted, duplicates, locked, stale;
static uint32_t generation;
static bool gate_open, reject_post;
static int reject_action;
static uint8_t published_mask;
static uint32_t current_generation(void) { return generation; }
static bool gate(uint32_t detected, uint32_t epoch)
{
    return gate_open && epoch == generation && detected == 100;
}
static bool output(IngredientSMAction_t action, uint8_t value)
{
    if ((int)action == reject_action) return false;
    switch (action) {
    case INGREDIENT_ACTION_ADDED:
        assert(value < 5 && !(published_mask & (1u << value)));
        published_mask |= (uint8_t)(1u << value); ++accepted; break;
    case INGREDIENT_ACTION_DUPLICATE: ++duplicates; break;
    case INGREDIENT_ACTION_LOCKED: ++locked; break;
    case INGREDIENT_ACTION_STALE: ++stale; break;
    case INGREDIENT_ACTION_STATE: assert(value <= INGREDIENT_FAULT); break;
    default: assert(0);
    }
    return true;
}
bool ES_PostToService(uint8_t priority, ES_Event_t event)
{
    assert(priority == 0);
    if (reject_post || count == 32) return false;
    queue[(head + count++) % 32] = event;
    return true;
}
static ES_Event_t pop(void)
{
    assert(count); ES_Event_t e = queue[head];
    head = (head + 1) % 32; --count; return e;
}
static void drain(void)
{
    while (count) assert(RunIngredientSM(pop()).EventType == ES_NO_EVENT);
}
static void reset(void)
{
    head = count = accepted = duplicates = locked = stale = 0;
    generation = 1; gate_open = reject_post = false; reject_action = -1;
    published_mask = 0;
    assert(InitIngredientSM(0));
    /* Game ES_INIT posts RESET before lower-priority Ingredient ES_INIT runs. */
    assert(IngredientSM_PostLifecycle(GAME_RESET, generation));
    drain();
    assert(QueryIngredientSM() == INGREDIENT_LOCKED && !IngredientSM_AddedMask());
}
static void begin(void)
{
    ++generation; gate_open = true; published_mask = 0;
    assert(IngredientSM_PostLifecycle(GAME_START, generation)); drain();
    assert(QueryIngredientSM() == INGREDIENT_READY && !IngredientSM_AddedMask());
}
static void ingredient(uint8_t n)
{
    assert(IngredientSM_PostSwitch(n, 100, generation)); drain();
}
static void expect_fault(void)
{
    assert(count && RunIngredientSM(pop()).EventType == ES_ERROR);
    assert(QueryIngredientSM() == INGREDIENT_FAULT && IngredientSM_HasFault());
    assert(!IngredientSM_PostSwitch(0, 100, generation));
}
int main(void)
{
    assert(!InitIngredientSM(0));
    const IngredientSMPort_t port = {current_generation, gate, output};
    assert(IngredientSM_BindPort(&port));
    reset(); ingredient(0);
    assert(locked == 1 && accepted == 0);
    begin();
    const uint8_t order[] = {4, 1, 3, 0, 2};
    for (unsigned i = 0; i < 5; ++i) ingredient(order[i]);
    assert(accepted == 5 && IngredientSM_AddedMask() == 0x1f);
    for (unsigned i = 0; i < 5; ++i) ingredient(order[i]);
    assert(accepted == 5 && duplicates == 5);
    assert(IngredientSM_PostLifecycle(GAME_START, generation)); drain();
    assert(PostIngredientSM((ES_Event_t){ES_INIT, 0})); drain();
    assert(IngredientSM_AddedMask() == 0x1f); /* Duplicate Start/init must not erase it. */
    assert(!IngredientSM_PostSwitch(5, 100, generation));
    assert(!IngredientSM_PostSwitch(255, 100, generation));
    assert(!IngredientSM_PostLifecycle(USER_ACTIVITY, generation));
    assert(!IngredientSM_HasFault());
    ++generation; gate_open = false;
    assert(IngredientSM_PostLifecycle(GAME_END, generation)); drain();
    ingredient(0); assert(locked == 2 && IngredientSM_AddedMask() == 0x1f);
    ++generation;
    assert(IngredientSM_PostLifecycle(GAME_RESET, generation)); drain();
    assert(!IngredientSM_AddedMask());
    begin(); ingredient(0); assert(accepted == 6 && IngredientSM_AddedMask() == 1);

    reset();
    assert(IngredientSM_PostSwitch(0, 100, generation));
    begin(); /* Old Welcome key is still ahead of START in the Ingredient queue. */
    assert(stale == 1 && accepted == 0);
    ingredient(0); assert(accepted == 1);
    assert(IngredientSM_PostSwitch(1, 100, generation));
    ++generation; gate_open = false;
    assert(IngredientSM_PostLifecycle(GAME_END, generation)); drain();
    assert(stale == 2 && accepted == 1 && QueryIngredientSM() == INGREDIENT_LOCKED);
    uint32_t old_generation = generation;
    begin(); ingredient(1);
    assert(IngredientSM_PostLifecycle(GAME_RESET, old_generation));
    assert(IngredientSM_PostLifecycle(GAME_END, old_generation));
    assert(IngredientSM_PostLifecycle(GAME_START, old_generation)); drain();
    assert(QueryIngredientSM() == INGREDIENT_READY && IngredientSM_AddedMask() == 2);
    gate_open = false; ingredient(2); /* Live deadline closes before GAME_END is delivered. */
    assert(stale == 3 && IngredientSM_AddedMask() == 2);

    reset(); begin();
    assert(IngredientSM_PostSwitch(0, 100, generation));
    ES_Event_t duplicate = queue[head]; drain();
    assert(PostIngredientSM(duplicate)); drain();
    assert(accepted == 1 && duplicates == 0);
    assert(IngredientSM_PostSwitch(1, 99, generation)); drain();
    assert(stale == 1); /* The authority rejected its timestamp. */

    reset(); begin(); reject_action = INGREDIENT_ACTION_ADDED;
    assert(IngredientSM_PostSwitch(0, 100, generation)); expect_fault();
    assert(accepted == 0); /* No retry of a failed fan-out. */
    reset(); reject_post = true;
    assert(!IngredientSM_PostSwitch(0, 100, generation));
    reject_post = false; assert(PostIngredientSM((ES_Event_t){ES_ERROR, 0})); expect_fault();
    reset();
    for (unsigned i = 0; i < 16; ++i) assert(IngredientSM_PostSwitch(0, 100, generation));
    assert(!IngredientSM_PostSwitch(0, 100, generation)); expect_fault();
    puts("IngredientSM passed: gating, once-per-round mask, stale queues, lifecycle and faults.");
    return 0;
}
