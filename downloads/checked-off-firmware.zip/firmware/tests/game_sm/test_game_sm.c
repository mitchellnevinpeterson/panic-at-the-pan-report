#include "GameSM.h"
#include "GameConfig.h"
#include "ES_Framework.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static uint32_t clock_ms, playing_started;
static ES_Event_t queue[32];
static unsigned head, count;
static struct { bool active; uint32_t due; } timers[16];
static bool reject_post, reject_timer, reverse_expiry;
static int reject_action = -1;
static unsigned treats, resets, starts, ends, banners, dish_frames, lit;
static int seconds, score, last_x, min_x, max_x;
static bool lamp;
static GameSMEndReason_t reason;
static uint32_t now(void) { return clock_ms; }

bool ES_PostToService(uint8_t service, ES_Event_t event)
{
    assert(service == 0);
    if (reject_post || count == 32) return false;
    queue[(head + count++) % 32] = event;
    return true;
}
ES_TimerReturn_t ES_Timer_InitTimer(uint8_t timer, uint16_t delay)
{
    assert(timer < 16 && delay > 0);
    if (reject_timer) return ES_Timer_ERR;
    timers[timer].active = true;
    timers[timer].due = clock_ms + delay;
    return ES_Timer_OK;
}
ES_TimerReturn_t ES_Timer_StopTimer(uint8_t timer)
{
    assert(timer < 16);
    timers[timer].active = false;
    return ES_Timer_OK;
}
static bool output(GameSMAction_t action, int32_t value)
{
    if ((int)action == reject_action) return false;
    switch (action) {
    case GAME_ACTION_TREAT: assert(value == 1); ++treats; break;
    case GAME_ACTION_RESET: ++resets; break;
    case GAME_ACTION_START: ++starts; break;
    case GAME_ACTION_END: ++ends; reason = (GameSMEndReason_t)value; break;
    case GAME_ACTION_FINISH_LED: lamp = value != 0; lit += lamp; break;
    case GAME_ACTION_DASHBOARD: score = 0; seconds = value; break;
    case GAME_ACTION_COUNTDOWN: seconds = value; break;
    case GAME_ACTION_WELCOME:
        ++banners; last_x = value;
        if (value < min_x) min_x = value;
        if (value > max_x) max_x = value;
        break;
    case GAME_ACTION_DISH: ++dish_frames; break;
    case GAME_ACTION_STATE: break;
    default: assert(0);
    }
    return true;
}
static ES_Event_t pop(void)
{
    assert(count > 0);
    ES_Event_t event = queue[head];
    head = (head + 1) % 32;
    --count;
    return event;
}
static void drain(void)
{
    unsigned limit = 100;
    while (count) {
        assert(limit-- > 0);
        assert(RunGameSM(pop()).EventType == ES_NO_EVENT);
    }
}
static void step(uint32_t ms)
{
    while (ms--) {
        ++clock_ms;
        for (int n = 0; n < 16; ++n) {
            int id = reverse_expiry ? 15 - n : n;
            if (timers[id].active && (uint32_t)(clock_ms - timers[id].due) < UINT32_C(0x80000000)) {
                timers[id].active = false;
                assert(PostGameSM((ES_Event_t){ES_TIMEOUT, (uint16_t)id}));
            }
        }
        drain();
    }
}
static void reset_at(uint32_t t)
{
    clock_ms = t;
    head = count = 0;
    memset(timers, 0, sizeof timers);
    reject_post = reject_timer = reverse_expiry = false;
    reject_action = -1;
    treats = resets = starts = ends = banners = dish_frames = lit = 0;
    seconds = score = -1;
    min_x = 999; max_x = -999; lamp = false;
    assert(InitGameSM(0));
    drain();
    assert(QueryGameSM() == GAME_WELCOME && resets == 1);
}
static void key(ES_EventType_t type)
{
    assert(GameSM_PostInput(type, clock_ms, GameSM_InputGeneration()));
    drain();
}
static void begin(void)
{
    unsigned previous_starts = starts;
    key(START_PRESSED);
    assert(QueryGameSM() == GAME_DISH_INTRO && starts == previous_starts);
    assert(!timers[GAME_TICK_TIMER].active && !timers[IDLE_TIMER].active);
    step(DISH_INTRO_MS);
    playing_started = clock_ms;
    assert(QueryGameSM() == GAME_COOKING_EARLY);
    assert(starts == previous_starts + 1 && seconds == 60 && score == 0 && !lamp);
}
static void active_10s(void) { step(10000); key(USER_ACTIVITY); }
static void expect_fault(void)
{
    assert(count > 0);
    assert(RunGameSM(pop()).EventType == ES_ERROR);
    assert(GameSM_HasFault() && QueryGameSM() == GAME_FAULT && !lamp);
    assert(!GameSM_PostInput(START_PRESSED, clock_ms, GameSM_InputGeneration()));
    for (unsigned i = 0; i < 16; ++i) assert(!timers[i].active);
}

static void test_welcome_and_start(void)
{
    reset_at(0);
    key(FINISH_PRESSED); key(USER_ACTIVITY);
    assert(PostGameSM((ES_Event_t){INGREDIENT_ADDED, 1})); drain();
    step(70000); /* More than one underlying uint16 tick wrap. */
    assert(QueryGameSM() == GAME_WELCOME && starts == 0);
    assert(banners == 70000 / WELCOME_SCROLL_MS + 1 && min_x == -216 && max_x == 32);
    assert(!timers[GAME_TICK_TIMER].active && !timers[IDLE_TIMER].active);
    begin();
    step(999); assert(seconds == 60);
    step(1); assert(seconds == 59);
    key(START_PRESSED); assert(starts == 1 && seconds == 59);
}

static void test_finish_gate_and_hold(void)
{
    reset_at(0); begin(); active_10s(); active_10s(); step(9999);
    assert(GameSM_PostInput(FINISH_PRESSED, playing_started + 29999, GameSM_InputGeneration()));
    clock_ms = playing_started + 30001; drain(); /* A delayed early press must not end the game. */
    assert(QueryGameSM() == GAME_COOKING_FINISHABLE && lamp && treats == 0);
    key(FINISH_PRESSED);
    assert(QueryGameSM() == GAME_OVER && !lamp && treats == 1 && seconds == 30);
    assert(reason == GAME_COMPLETED && ends == 1);
    key(FINISH_PRESSED); key(START_PRESSED); key(USER_ACTIVITY);
    step(9999); assert(QueryGameSM() == GAME_OVER && treats == 1);
    step(1); assert(QueryGameSM() == GAME_WELCOME && resets == 3);
    step(100); assert(starts == 1);
    begin(); assert(starts == 2 && seconds == 60);

    reset_at(0); begin(); active_10s(); active_10s();
    clock_ms = playing_started + 30000; key(FINISH_PRESSED); /* No threshold tick dispatched yet. */
    assert(QueryGameSM() == GAME_OVER && treats == 1 && seconds == 30);
}

static void test_deadlines(void)
{
    for (unsigned reversed = 0; reversed < 2; ++reversed) {
        reset_at(0); reverse_expiry = reversed; begin();
        active_10s(); active_10s(); active_10s(); active_10s();
        step(19999); assert(seconds == 1 && treats == 0);
        step(1); /* Game end and idle are simultaneous; game end wins. */
        assert(QueryGameSM() == GAME_OVER && seconds == 0 && treats == 1);
        assert(reason == GAME_COMPLETED);
        assert(PostGameSM((ES_Event_t){ES_TIMEOUT, IDLE_TIMER})); drain();
        assert(treats == 1);
    }
    reset_at(0); begin(); step(19999);
    assert(QueryGameSM() == GAME_COOKING_EARLY);
    step(1); assert(QueryGameSM() == GAME_TIMED_OUT && seconds == 40 && treats == 0);
    assert(reason == GAME_IDLE_TIMEOUT);
    key(FINISH_PRESSED); key(START_PRESSED);
    step(4999); assert(QueryGameSM() == GAME_TIMED_OUT);
    step(1); assert(QueryGameSM() == GAME_WELCOME && resets == 3);
    /* Exact idle deadline is already expired, even for a now-eligible Finish. */
    reset_at(0); begin(); active_10s();
    clock_ms = playing_started + 30000; key(FINISH_PRESSED);
    assert(QueryGameSM() == GAME_TIMED_OUT && treats == 0);
}

static void test_queue_races(void)
{
    reset_at(0); begin();
    clock_ms = playing_started + 20000;
    assert(PostGameSM((ES_Event_t){ES_TIMEOUT, IDLE_TIMER}));
    assert(GameSM_PostInput(USER_ACTIVITY, playing_started + 19999, GameSM_InputGeneration()));
    drain();
    assert(QueryGameSM() == GAME_COOKING_EARLY && timers[IDLE_TIMER].due == playing_started + 39999);
    clock_ms = playing_started + 20001;
    assert(PostGameSM((ES_Event_t){ES_TIMEOUT, IDLE_TIMER})); drain();
    assert(QueryGameSM() == GAME_COOKING_EARLY);

    reset_at(0); begin(); clock_ms = playing_started + 20000; key(USER_ACTIVITY);
    assert(QueryGameSM() == GAME_TIMED_OUT && treats == 0);
    uint32_t old_generation = GameSM_InputGeneration();
    clock_ms = playing_started + 25000;
    assert(PostGameSM((ES_Event_t){ES_TIMEOUT, TIMEOUT_DISPLAY_TIMER}));
    assert(GameSM_PostInput(START_PRESSED, clock_ms, old_generation));
    drain();
    assert(QueryGameSM() == GAME_WELCOME && starts == 1);
    begin(); assert(starts == 2);
    assert(PostGameSM((ES_Event_t){ES_TIMEOUT, RESULT_TIMER}));
    assert(PostGameSM((ES_Event_t){ES_TIMEOUT, WELCOME_SCROLL_TIMER}));
    assert(PostGameSM((ES_Event_t){ES_TIMEOUT, IDLE_TIMER})); drain();
    assert(QueryGameSM() == GAME_COOKING_EARLY && treats == 0);

    reset_at(0);
    assert(GameSM_PostInput(START_PRESSED, clock_ms, GameSM_InputGeneration()));
    ES_Event_t duplicate = queue[head]; drain(); step(DISH_INTRO_MS);
    assert(PostGameSM(duplicate)); drain(); assert(starts == 1);
}

static void test_clock_and_age(void)
{
    reset_at(UINT32_MAX - 35000u); begin();
    active_10s(); active_10s(); active_10s(); active_10s();
    step(20000);
    assert(QueryGameSM() == GAME_OVER && treats == 1 && seconds == 0);
    step(10000); assert(QueryGameSM() == GAME_WELCOME);

    reset_at(0); begin(); clock_ms = playing_started + 3456;
    assert(PostGameSM((ES_Event_t){ES_TIMEOUT, GAME_TICK_TIMER})); drain();
    assert(seconds == 57 && timers[GAME_TICK_TIMER].due == playing_started + 4000);

    reset_at(1000); clock_ms = 2501;
    assert(GameSM_PostInput(START_PRESSED, 1500, GameSM_InputGeneration())); drain();
    assert(QueryGameSM() == GAME_WELCOME); /* Too old. */
    assert(GameSM_PostInput(START_PRESSED, 2600, GameSM_InputGeneration())); drain();
    assert(QueryGameSM() == GAME_WELCOME); /* Future timestamp. */
    assert(GameSM_PostInput(START_PRESSED, 2501, GameSM_InputGeneration() - 1)); drain();
    assert(QueryGameSM() == GAME_WELCOME); /* Old round. */
    clock_ms = 1200;
    assert(GameSM_PostInput(START_PRESSED, 999, GameSM_InputGeneration())); drain();
    assert(QueryGameSM() == GAME_WELCOME); /* Before Welcome entry. */
}

static void test_failures(void)
{
    reset_at(0); reject_timer = true;
    assert(GameSM_PostInput(START_PRESSED, now(), GameSM_InputGeneration())); expect_fault();
    reset_at(0); reject_action = GAME_ACTION_DISH;
    assert(GameSM_PostInput(START_PRESSED, now(), GameSM_InputGeneration())); expect_fault();
    reset_at(0); reject_post = true;
    assert(!GameSM_PostInput(START_PRESSED, now(), GameSM_InputGeneration()));
    reject_post = false; assert(PostGameSM((ES_Event_t){ES_ERROR, 0})); expect_fault();
    reset_at(0);
    for (int i = 0; i < 16; ++i)
        assert(GameSM_PostInput(USER_ACTIVITY, now(), GameSM_InputGeneration()));
    assert(!GameSM_PostInput(USER_ACTIVITY, now(), GameSM_InputGeneration())); expect_fault();
    reset_at(0); assert(PostGameSM((ES_Event_t){ES_ERROR, 0})); expect_fault();
}

static void test_gameplay_gate(void)
{
    reset_at(1000);
    assert(!GameSM_AcceptsGameplayInput(clock_ms, GameSM_InputGeneration()));
    begin();
    uint32_t epoch = GameSM_InputGeneration();
    assert(GameSM_AcceptsScoreRound(epoch));
    assert(GameSM_AcceptsGameplayInput(playing_started, epoch));
    assert(!GameSM_AcceptsGameplayInput(playing_started - 1, epoch));
    assert(!GameSM_AcceptsGameplayInput(playing_started + 1, epoch));
    assert(!GameSM_AcceptsGameplayInput(playing_started, epoch - 1));
    clock_ms = playing_started + 1000; assert(GameSM_AcceptsGameplayInput(playing_started, epoch));
    ++clock_ms; assert(!GameSM_AcceptsGameplayInput(playing_started, epoch));
    clock_ms = playing_started + 20000;
    assert(QueryGameSM() == GAME_COOKING_EARLY);
    assert(!GameSM_AcceptsGameplayInput(clock_ms, epoch));
    reset_at(UINT32_MAX - 25000u); begin();
    active_10s(); active_10s(); active_10s(); active_10s();
    epoch = GameSM_InputGeneration();
    assert(GameSM_AcceptsGameplayInput(clock_ms, epoch));
    step(19999); assert(GameSM_AcceptsGameplayInput(clock_ms, epoch));
    ++clock_ms;
    assert(!GameSM_AcceptsGameplayInput(clock_ms, epoch));
    assert(PostGameSM((ES_Event_t){ES_TIMEOUT, GAME_TICK_TIMER})); drain();
    assert(GameSM_AcceptsScoreRound(epoch)); /* Earned points can drain in results. */
    assert(!GameSM_AcceptsScoreRound(GameSM_InputGeneration())); /* End generation is not a round. */
    step(10000); assert(!GameSM_AcceptsScoreRound(epoch));
}

static void test_dish_intro(void)
{
    reset_at(0); key(START_PRESSED);
    assert(QueryGameSM() == GAME_DISH_INTRO && dish_frames == 1 && starts == 0);
    uint32_t intro_generation = GameSM_InputGeneration();
    assert(!GameSM_AcceptsScoreRound(intro_generation));
    step(DISH_INTRO_MS - 1);
    key(START_PRESSED); key(FINISH_PRESSED); key(USER_ACTIVITY);
    assert(QueryGameSM() == GAME_DISH_INTRO && starts == 0 && !lamp);
    assert(!timers[IDLE_TIMER].active && !timers[GAME_TICK_TIMER].active);
    /* An input already queued during the intro must not end or renew play. */
    assert(PostGameSM((ES_Event_t){ES_TIMEOUT, WELCOME_SCROLL_TIMER}));
    assert(GameSM_PostInput(FINISH_PRESSED, clock_ms, intro_generation));
    ++clock_ms; drain();
    assert(QueryGameSM() == GAME_COOKING_EARLY && starts == 1 && seconds == 60);
    assert(dish_frames == DISH_INTRO_MS / WELCOME_SCROLL_MS);
    assert(GameSM_InputGeneration() != intro_generation);
    assert(PostGameSM((ES_Event_t){ES_TIMEOUT, WELCOME_SCROLL_TIMER})); drain();
    assert(dish_frames == DISH_INTRO_MS / WELCOME_SCROLL_MS && starts == 1);
    step(999); assert(seconds == 60); step(1); assert(seconds == 59);

    reset_at(0); key(START_PRESSED); clock_ms = DISH_INTRO_MS + 5000;
    assert(PostGameSM((ES_Event_t){ES_TIMEOUT, WELCOME_SCROLL_TIMER})); drain();
    assert(seconds == 60 && timers[IDLE_TIMER].due == clock_ms + IDLE_TIMEOUT_MS);

    reset_at(0); key(START_PRESSED); step(DISH_INTRO_MS - 1);
    reject_action = GAME_ACTION_DASHBOARD; ++clock_ms;
    assert(PostGameSM((ES_Event_t){ES_TIMEOUT, WELCOME_SCROLL_TIMER})); expect_fault();
}

static void test_abort_and_activity(void)
{
    /* Early Finish is neither an end nor activity: idle still expires at 20 s. */
    reset_at(0); begin(); step(10000); key(FINISH_PRESSED);
    step(9999); assert(QueryGameSM() == GAME_COOKING_EARLY);
    step(1); assert(QueryGameSM() == GAME_TIMED_OUT && treats == 0);
    assert(GameSM_EndText() == 0);

    reset_at(0); begin(); active_10s(); active_10s(); step(15000); key(FINISH_PRESSED);
    assert(QueryGameSM() == GAME_OVER && !strcmp(GameSM_EndText(), END_FINISH_TEXT));
    reset_at(0); begin();
    for (unsigned i = 0; i < 5; ++i) active_10s();
    step(10000); assert(QueryGameSM() == GAME_OVER && !strcmp(GameSM_EndText(), END_TIMEUP_TEXT));

    /* Abort returns to Welcome from cooking, without a treat. */
    reset_at(0); begin(); step(5000);
    uint32_t old = GameSM_InputGeneration();
    assert(GameSM_PostAbort()); drain();
    assert(QueryGameSM() == GAME_WELCOME && resets == 3 && treats == 0 && !lamp);
    assert(!timers[GAME_TICK_TIMER].active && !timers[IDLE_TIMER].active);
    /* A late abort from an older round never cancels the next one. */
    key(START_PRESSED); assert(QueryGameSM() == GAME_DISH_INTRO);
    assert(PostGameSM((ES_Event_t){GAME_ABORT, (uint16_t)old})); drain();
    assert(QueryGameSM() == GAME_DISH_INTRO);
    assert(GameSM_PostAbort()); drain(); assert(QueryGameSM() == GAME_WELCOME && resets == 5);
    assert(GameSM_PostAbort()); drain(); assert(QueryGameSM() == GAME_WELCOME && resets == 5);
}

int main(void)
{
    assert(!InitGameSM(0)); /* Never silently bind unfinished hardware. */
    const GameSMPort_t port = {now, output};
    assert(GameSM_BindPort(&port));
    test_welcome_and_start();
    test_finish_gate_and_hold();
    test_deadlines();
    test_queue_races();
    test_clock_and_age();
    test_gameplay_gate();
    test_dish_intro();
    test_abort_and_activity();
    test_failures();
    puts("GameSM scenarios passed (lifecycle, timing, queue races, faults).");
    return 0;
}
