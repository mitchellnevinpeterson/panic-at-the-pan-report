#include "ScoreSM.h"
#include "ES_Framework.h"
#include <assert.h>
#include <stdio.h>

static ES_Event_t queue[32];
static unsigned head, count, renders;
static uint32_t generation, playing_round;
static bool allow_round, reject_post, reject_display;
static int32_t displayed;
static uint32_t current_generation(void) { return generation; }
static bool accepts_round(uint32_t epoch) { return allow_round && epoch == playing_round; }
static bool display(int32_t value)
{
    assert(allow_round); /* Any render over a Welcome/Dish banner fails the test. */
    if (reject_display) return false;
    assert(value >= -999 && value <= 9999); ++renders; displayed = value; return true;
}
bool ES_PostToService(uint8_t priority, ES_Event_t event)
{
    assert(priority == 0);
    if (reject_post || count == 32) return false;
    queue[(head + count++) % 32] = event;
    return true;
}
static ES_Event_t pop(void)
{
    assert(count); ES_Event_t e = queue[head]; head = (head + 1) % 32; --count; return e;
}
static void drain(void) { while (count) assert(RunScoreSM(pop()).EventType == ES_NO_EVENT); }
static void reset(void)
{
    head = count = renders = 0;
    generation = 1; playing_round = 0; allow_round = reject_post = reject_display = false;
    displayed = -1;
    assert(InitScoreSM(0)); assert(ScoreSM_PostLifecycle(GAME_RESET, generation)); drain();
    assert(QueryScoreSM() == SCORE_IDLE && ScoreSM_Value() == 0 && renders == 0);
}
static void begin(void)
{
    playing_round = ++generation; allow_round = true;
    assert(ScoreSM_PostLifecycle(GAME_START, playing_round)); drain();
    assert(QueryScoreSM() == SCORE_ACTIVE && ScoreSM_Value() == 0 && displayed == 0);
}
static void ingredient(uint8_t n)
{
    assert(ScoreSM_PostIngredient(n, playing_round)); drain();
}
static void expect_fault(void)
{
    assert(count && RunScoreSM(pop()).EventType == ES_ERROR);
    assert(QueryScoreSM() == SCORE_FAULT && ScoreSM_HasFault());
    assert(!ScoreSM_PostIngredient(0, playing_round));
}
int main(void)
{
    assert(!InitScoreSM(0));
    ScoreSMPort_t port = {current_generation, accepts_round, display, -1, 0, false};
    assert(!ScoreSM_BindPort(&port)); port.ingredient_points = 2000;
    assert(!ScoreSM_BindPort(&port)); port.ingredient_points = 10;
    assert(ScoreSM_BindPort(&port));
    reset(); ingredient(0); assert(ScoreSM_Value() == 0 && renders == 0);
    begin();
    for (uint8_t n = 0; n < 5; ++n) { ingredient(n); assert(ScoreSM_Value() == (n + 1) * 10); }
    unsigned previous_renders = renders;
    for (uint8_t n = 0; n < 5; ++n) ingredient(n);
    assert(ScoreSM_Value() == 50 && renders == previous_renders);
    assert(ScoreSM_PostLifecycle(GAME_START, playing_round));
    assert(PostScoreSM((ES_Event_t){ES_INIT, 0})); drain();
    assert(ScoreSM_Value() == 50 && renders == previous_renders);
    assert(!ScoreSM_PostIngredient(5, playing_round));
    assert(!ScoreSM_PostLifecycle(USER_ACTIVITY, generation));
    assert(!ScoreSM_HasFault());

    reset(); begin();
    assert(ScoreSM_PostIngredient(0, playing_round));
    ++generation; /* Game ended, before lower-priority Score can process the credit. */
    assert(PostScoreSM((ES_Event_t){GAME_END, 0})); drain();
    assert(ScoreSM_Value() == 10 && displayed == 10 && QueryScoreSM() == SCORE_ACTIVE);
    assert(ScoreSM_PostIngredient(1, generation)); drain(); /* Not the earned round. */
    assert(ScoreSM_Value() == 10);

    /* Even Start can be pending when high-priority Game reaches results. */
    reset(); playing_round = ++generation; allow_round = true;
    assert(ScoreSM_PostLifecycle(GAME_START, playing_round));
    assert(ScoreSM_PostIngredient(2, playing_round));
    ++generation; drain(); assert(ScoreSM_Value() == 10);

    /* Reject backlog and clear internally without touching either banner. */
    assert(ScoreSM_PostIngredient(3, playing_round));
    allow_round = false; ++generation;
    previous_renders = renders;
    assert(ScoreSM_PostLifecycle(GAME_RESET, generation)); drain();
    assert(ScoreSM_Value() == 0 && QueryScoreSM() == SCORE_IDLE && renders == previous_renders);
    assert(ScoreSM_PostIngredient(4, playing_round)); drain();
    assert(renders == previous_renders);
    uint32_t previous_generation = generation;
    begin(); ingredient(0); assert(ScoreSM_Value() == 10);
    assert(ScoreSM_PostLifecycle(GAME_RESET, previous_generation));
    assert(ScoreSM_PostLifecycle(GAME_START, previous_generation));
    assert(ScoreSM_PostIngredient(1, previous_generation)); drain();
    assert(ScoreSM_Value() == 10);

    /* Exactly-once handling also rejects a repeated owned ES queue ticket. */
    assert(ScoreSM_PostIngredient(1, playing_round)); ES_Event_t duplicate = queue[head]; drain();
    assert(PostScoreSM(duplicate)); drain(); assert(ScoreSM_Value() == 20);
    reset(); generation = UINT32_MAX - 1; begin();
    assert(playing_round == UINT32_MAX); ++generation; ingredient(4);
    assert(generation == 0 && ScoreSM_Value() == 10);

    reset(); begin(); reject_display = true;
    assert(ScoreSM_PostIngredient(0, playing_round)); expect_fault();
    reset(); reject_post = true;
    assert(!ScoreSM_PostIngredient(0, playing_round)); reject_post = false;
    assert(PostScoreSM((ES_Event_t){ES_ERROR, 0})); expect_fault();
    reset();
    for (unsigned i = 0; i < 16; ++i) assert(ScoreSM_PostIngredient(0, playing_round));
    assert(!ScoreSM_PostIngredient(0, playing_round)); expect_fault();

    /* PostDelta: millipoint accumulation, whole-point display toward zero,
     * repaint only on whole-point change (bench port: no floor). */
    reset(); begin(); previous_renders = renders;
    assert(ScoreSM_PostDelta(playing_round, 999)); drain();
    assert(ScoreSM_Value() == 0 && renders == previous_renders);
    assert(ScoreSM_PostDelta(playing_round, 1)); drain();
    assert(ScoreSM_Value() == 1 && displayed == 1 && renders == previous_renders + 1);
    for (int i = 0; i < 9; ++i) assert(ScoreSM_PostDelta(playing_round, 100));
    drain(); assert(ScoreSM_Value() == 1 && renders == previous_renders + 1);
    assert(ScoreSM_PostDelta(playing_round, 100)); drain(); /* 2.000 */
    assert(ScoreSM_Value() == 2 && renders == previous_renders + 2);
    assert(ScoreSM_PostDelta(playing_round, -2500)); drain(); /* -0.5 -> 0 */
    assert(ScoreSM_Value() == 0 && displayed == 0);
    assert(ScoreSM_PostDelta(playing_round, -600)); drain(); /* -1.1 -> -1 */
    assert(ScoreSM_Value() == -1 && displayed == -1);
    ingredient(0); assert(ScoreSM_Value() == 8); /* -1.1 + 10 */
    assert(!ScoreSM_PostDelta(playing_round, 1000001));
    assert(!ScoreSM_PostDelta(playing_round, -1000001));
    assert(ScoreSM_PostDelta(playing_round, 1000000)); drain();
    assert(ScoreSM_PostDelta(playing_round, -1000000)); drain();
    assert(ScoreSM_Value() == 8 && !ScoreSM_HasFault());
    previous_renders = renders;
    assert(ScoreSM_PostDelta(playing_round + 1, 5000)); drain(); /* other round */
    assert(ScoreSM_PostDelta(playing_round - 1, 5000)); drain();
    assert(ScoreSM_Value() == 8 && renders == previous_renders);
    ++generation; /* results: still the earned round */
    assert(ScoreSM_PostDelta(playing_round, 2000)); drain();
    assert(ScoreSM_Value() == 10);
    allow_round = false; /* back at Welcome: no repaint over the banner */
    assert(ScoreSM_PostDelta(playing_round, 2000)); drain();
    assert(ScoreSM_Value() == 10 && renders == previous_renders + 1);
    /* A repeated owned ticket is applied once. */
    allow_round = true;
    assert(ScoreSM_PostDelta(playing_round, 3000)); duplicate = queue[head]; drain();
    assert(PostScoreSM(duplicate)); drain(); assert(ScoreSM_Value() == 13);
    reset(); begin(); reject_post = true;
    assert(!ScoreSM_PostDelta(playing_round, 1000) && ScoreSM_HasFault());
    reset(); begin(); reject_display = true;
    assert(ScoreSM_PostDelta(playing_round, 1000)); expect_fault();

    puts("ScoreSM passed: tuning, points, duplicate protection, earned-at-End ordering, banners, reset, faults and millipoint deltas.");
    return 0;
}
