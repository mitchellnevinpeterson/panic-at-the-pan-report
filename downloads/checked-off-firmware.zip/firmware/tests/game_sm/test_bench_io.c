/* Exercise the real target adapter against simulated registers/peripherals. */
#include "BenchIO.h"
#include "GameSM.h"
#include "IngredientSM.h"
#include "ScoreSM.h"
#include "GameConfig.h"
#include "ScoreTimerDisplay.h"
#include "xc.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

HostUARTStatus U1STAbits;
uint32_t U1STACLR, U1RXREG;
static GameSMPort_t port;
static uint16_t tick;
static unsigned reads, drains, services, faults, inputs;
static uint32_t input_time, input_generation;
static ES_EventType_t input_type;
static bool bus_fault, input_fail, game_fault;
static unsigned fields;
static bool batch;
static IngredientSMPort_t ingredient_port;
static unsigned switches, lifecycle;
static uint8_t ingredient_index;
static bool ingredient_fail, lifecycle_fail, ingredient_fault;
static ScoreSMPort_t score_port;
static bool score_fail, score_fault;
static unsigned score_ingredients, score_lifecycle;
bool ScoreSM_BindPort(const ScoreSMPort_t *p)
{
    score_port = *p; assert(p->ingredient_points == 10); return true;
}
bool ScoreSM_HasFault(void) { return score_fault; }
bool GameSM_AcceptsScoreRound(uint32_t epoch) { return epoch == 7; }
bool ScoreSM_PostIngredient(uint8_t n, uint32_t epoch)
{
    assert(n < 5 && epoch == 7); ++score_ingredients; return !score_fail;
}
bool ScoreSM_PostLifecycle(ES_EventType_t type, uint32_t epoch)
{
    assert(epoch == 7 && (type == GAME_START || type == GAME_RESET));
    ++score_lifecycle; return !score_fail;
}
bool IngredientSM_BindPort(const IngredientSMPort_t *p) { ingredient_port = *p; return true; }
bool IngredientSM_HasFault(void) { return ingredient_fault; }
bool GameSM_AcceptsGameplayInput(uint32_t t, uint32_t epoch)
{
    return t == input_time && epoch == input_generation;
}
bool IngredientSM_PostSwitch(uint8_t n, uint32_t t, uint32_t epoch)
{
    /* Both posts carry exactly the same capture metadata; activity goes first. */
    assert(inputs > 0 && input_type == USER_ACTIVITY && t == input_time && epoch == input_generation);
    ++switches; ingredient_index = n; return !ingredient_fail;
}
bool IngredientSM_PostLifecycle(ES_EventType_t type, uint32_t epoch)
{
    assert(epoch == 7 && (type == GAME_START || type == GAME_END || type == GAME_RESET));
    ++lifecycle; return !lifecycle_fail;
}
uint16_t ES_Timer_GetTime(void) { return tick; }
bool GameSM_BindPort(const GameSMPort_t *p) { port = *p; return true; }
uint32_t GameSM_InputGeneration(void) { return 7; }
bool GameSM_HasFault(void) { return game_fault; }
bool PostGameSM(ES_Event_t event)
{
    assert(event.EventType == ES_ERROR); ++faults; return true;
}
bool GameSM_PostInput(ES_EventType_t type, uint32_t t, uint32_t generation)
{
    ++inputs; input_type = type; input_time = t; input_generation = generation;
    return !input_fail;
}
uint8_t Terminal_ReadByte(void)
{
    assert(U1STAbits.URXDA); ++reads; U1STAbits.URXDA = 0; return (uint8_t)U1RXREG;
}
void Terminal_MoveBuffer2UART(void) { ++drains; }
bool ScoreTimerDisplay_Init(const ScoreTimerDisplay_Config *c)
{
    assert(c && c->intensity == 1); return true;
}
ScoreTimerDisplay_State ScoreTimerDisplay_Service(void)
{
    ++services;
    if (batch) assert(fields == 7); /* No partial SCORE/TIME dashboard snapshot. */
    return bus_fault ? SCORE_TIMER_FAULT : SCORE_TIMER_IDLE;
}
bool ScoreTimerDisplay_ShowLabels(void) { fields |= 1; return true; }
bool ScoreTimerDisplay_SetScore(int32_t s) { assert(s >= 0 && s <= 50); fields |= 2; return true; }
bool ScoreTimerDisplay_SetTimerSeconds(uint32_t s) { assert(s <= 60); fields |= 4; return true; }
bool ScoreTimerDisplay_SetBanner(const char *s, int16_t x)
{
    assert(strcmp(s, WELCOME_TEXT) == 0 || strcmp(s, DISH_TEXT) == 0);
    assert(x >= -(int)strlen(s) * 8 && x <= 32); return true;
}
static void reset(void)
{
    tick = 0; reads = drains = services = faults = inputs = fields = 0;
    bus_fault = input_fail = game_fault = batch = false;
    ingredient_fail = lifecycle_fail = ingredient_fault = false;
    score_fail = score_fault = false; score_ingredients = score_lifecycle = 0;
    switches = lifecycle = 0;
    U1STAbits = (HostUARTStatus){0};
    assert(GameBenchIO_Init());
}
static bool key(char c)
{
    U1RXREG = (uint8_t)c; U1STAbits.URXDA = 1; return CheckGameBenchIO();
}
int main(void)
{
    reset();
    assert(!CheckGameBenchIO() && reads == 0 && drains == 1 && services == 0);
    tick = 100; assert(!CheckGameBenchIO() && services == 1);
    assert(key('b') && input_type == START_PRESSED && input_generation == 7 && input_time == 100);
    assert(key('f') && input_type == FINISH_PRESSED);
    assert(key('a') && input_type == USER_ACTIVITY);
    assert(!key('\n') && inputs == 3);
    /* Each read is guarded; no extra read during an empty idle loop. */
    unsigned old_reads = reads; assert(!CheckGameBenchIO() && reads == old_reads);
    tick = 65535; assert(!CheckGameBenchIO());
    tick = 0; assert(key('b') && input_time == 65536u);
    tick = 65535; assert(!CheckGameBenchIO());
    tick = 0; assert(key('a') && input_time == 131072u);
    for (char c = '1'; c <= '5'; ++c) {
        assert(key(c) && ingredient_index == (uint8_t)(c - '1'));
        assert(input_type == USER_ACTIVITY);
    }
    assert(switches == 5 && ingredient_port.accept_input(input_time, input_generation));
    assert(ingredient_port.generation() == 7);
    assert(port.output(GAME_ACTION_START, 0));
    assert(port.output(GAME_ACTION_END, GAME_COMPLETED));
    assert(port.output(GAME_ACTION_RESET, 0) && lifecycle == 3);
    assert(score_lifecycle == 2); /* Score stays Active through End. */
    lifecycle_fail = true; assert(!port.output(GAME_ACTION_START, 0));
    lifecycle_fail = false;
    batch = true; assert(port.output(GAME_ACTION_DASHBOARD, 60) && fields == 7);
    batch = false; assert(port.output(GAME_ACTION_WELCOME, 32));
    assert(port.output(GAME_ACTION_DISH, 32));
    assert(ingredient_port.output(INGREDIENT_ACTION_ADDED, 2) && score_ingredients == 1);
    assert(score_port.display(10));
    score_fail = true;
    assert(!ingredient_port.output(INGREDIENT_ACTION_ADDED, 3));
    assert(!port.output(GAME_ACTION_START, 0));
    score_fail = false;
    bus_fault = true; assert(!port.output(GAME_ACTION_COUNTDOWN, 59));
    assert(CheckGameBenchIO() && faults == 1);
    assert(!CheckGameBenchIO() && faults == 1); /* Do not flood the ES queue. */

    reset(); U1STAbits.OERR = 1;
    assert(CheckGameBenchIO() && faults == 1 && reads == 0 && U1STACLR == _U1STA_OERR_MASK);
    reset(); U1STAbits.FERR = U1STAbits.URXDA = 1;
    assert(CheckGameBenchIO() && faults == 1 && reads == 0);
    reset(); U1STAbits.PERR = U1STAbits.URXDA = 1;
    assert(CheckGameBenchIO() && faults == 1 && reads == 0);
    reset(); input_fail = true; assert(key('b') && faults == 1);
    reset(); input_fail = true; assert(key('1') && faults == 1 && switches == 0);
    reset(); ingredient_fail = true; assert(key('1') && faults == 1);
    reset(); ingredient_fault = true; assert(CheckGameBenchIO() && faults == 1);
    reset(); score_fault = true; assert(CheckGameBenchIO() && faults == 1);
    reset(); game_fault = true; assert(CheckGameBenchIO() && faults == 1);
    puts("GameSM bench I/O passed (clock extension, display batching, UART, faults).");
    return 0;
}
