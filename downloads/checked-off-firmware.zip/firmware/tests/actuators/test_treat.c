#include "fake_actuators.h"
#include "Treat.h"
#include "Servo50Hz.h"

#define T fake_servo[SERVO_TREAT]

static void test_power_up_and_flag(void)
{
    Treat_Init(0);
    CHECK(T.pulsing && T.pulse_us == TREAT_CLOSED_US && T.writes == 1);
    CHECK(!Treat_Rotated());
    Treat_CloseIfRotated(10);               /* not rotated: no move at all */
    CHECK(T.writes == 1);
    Treat_Release(20);
    CHECK(Treat_Rotated() && T.pulse_us == TREAT_RELEASE_US && T.pulsing);
    Treat_Release(30);                      /* repeat keeps the one flag */
    CHECK(Treat_Rotated() && T.pulse_us == TREAT_RELEASE_US);
    Treat_CloseIfRotated(40);
    CHECK(!Treat_Rotated() && T.pulse_us == TREAT_CLOSED_US && T.pulsing);
    unsigned writes = T.writes;
    Treat_CloseIfRotated(50);               /* flag cleared: second call does nothing */
    CHECK(T.writes == writes && T.pulse_us == TREAT_CLOSED_US);
    CHECK(fake_servo[SERVO_SPOON].writes == 0);
    /* Game start: always commands closed, rotated or not, and clears the flag. */
    writes = T.writes;
    Treat_Close(60);
    CHECK(T.writes == writes + 1 && T.pulse_us == TREAT_CLOSED_US && T.pulsing && !Treat_Rotated());
    Treat_Release(70);
    Treat_Close(80);
    CHECK(T.pulse_us == TREAT_CLOSED_US && !Treat_Rotated());
    writes = T.writes;
    Treat_CloseIfRotated(90);               /* already closed by Treat_Close: no move */
    CHECK(T.writes == writes);
}

static void test_drive_window(void)
{
    Treat_Init(1000);
#if TREAT_DRIVE_MS > 0
    Treat_Service(1000 + TREAT_DRIVE_MS - 1);
    CHECK(T.pulsing);
    Treat_Service(1000 + TREAT_DRIVE_MS);
    CHECK(!T.pulsing && T.disables == 1);
    Treat_Service(5000);
    CHECK(T.disables == 1);                 /* one stop per move */
    Treat_Release(6000);
    CHECK(T.pulsing && T.pulse_us == TREAT_RELEASE_US);
    Treat_Service(6000 + TREAT_DRIVE_MS);
    Treat_Service(60000);                   /* open: keeps pulsing until closed */
    CHECK(T.pulsing && T.disables == 1 && Treat_Rotated());
    Treat_CloseIfRotated(0xFFFFFFF0u);      /* window survives ms wraparound */
    Treat_Service(0xFFFFFFF0u + TREAT_DRIVE_MS - 1);
    CHECK(T.pulsing && T.pulse_us == TREAT_CLOSED_US);
    Treat_Service(0xFFFFFFF0u + TREAT_DRIVE_MS);
    CHECK(!T.pulsing && T.disables == 2);
#else
    for (uint32_t t = 1000; t < 200000; t += 997) Treat_Service(t);
    CHECK(T.pulsing && T.disables == 0);    /* hold: keep pulsing */
    Treat_Release(200000);
    Treat_Service(900000);
    CHECK(T.pulsing && T.pulse_us == TREAT_RELEASE_US);
    Treat_CloseIfRotated(900001);
#endif
}

static void test_keys(void)
{
    Treat_Init(0);
    CHECK(!Treat_Key('x', 0) && !Treat_Key('1', 0) && !Treat_Key('s', 0));
    CHECK(Treat_Key('o', 1) && Treat_Rotated() && T.pulse_us == TREAT_RELEASE_US);
    CHECK(Treat_Key('-', 2) && T.pulse_us == TREAT_RELEASE_US - 25u);
    CHECK(Treat_Key('c', 3) && !Treat_Rotated() && T.pulse_us == TREAT_CLOSED_US);
    CHECK(Treat_Key('+', 4) && T.pulse_us == TREAT_CLOSED_US + 25u);
    CHECK(Treat_Key('+', 5) && T.pulse_us == TREAT_CLOSED_US + 50u);
    /* The nudged values are what the game later uses. */
    Treat_Release(6);
    CHECK(T.pulse_us == TREAT_RELEASE_US - 25u);
    Treat_CloseIfRotated(7);
    CHECK(T.pulse_us == TREAT_CLOSED_US + 50u);
    /* Bounds: release saturates at the top, closed at the bottom. */
    Treat_Key('o', 8);
    for (int i = 0; i < 100; ++i) CHECK(Treat_Key('+', 9));
    CHECK(T.pulse_us <= SERVO50HZ_MAX_US && T.pulse_us + 25u > SERVO50HZ_MAX_US);
    Treat_Key('c', 10);
    for (int i = 0; i < 100; ++i) CHECK(Treat_Key('-', 11));
    CHECK(T.pulse_us >= SERVO50HZ_MIN_US && T.pulse_us < SERVO50HZ_MIN_US + 25u);
    Treat_Release(12);
    CHECK(T.pulse_us <= SERVO50HZ_MAX_US && T.pulse_us + 25u > SERVO50HZ_MAX_US);
}

int main(void)
{
    fake_servo_reset();
    test_power_up_and_flag();
    fake_servo_reset();
    test_drive_window();
    fake_servo_reset();
    test_keys();                            /* last: leaves nudged values in RAM */
    printf("test_treat (TREAT_DRIVE_MS=%u): PASS\n", (unsigned)TREAT_DRIVE_MS);
    return 0;
}
