#include "fake_actuators.h"
#include "Stirrer.h"
#include "Servo50Hz.h"
#include <math.h>

#define S fake_servo[SERVO_SPOON]
static uint32_t now;

/* One main-loop pass per ms, the way pic1_main calls Stirrer_Service. */
static void run(uint32_t ms, bool cooking)
{
    for (uint32_t end = now + ms; now != end; ++now) {
        Stirrer_Service(now, cooking);
        CHECK(S.pulse_us >= STIR_PULSE_MIN_US && S.pulse_us <= STIR_PULSE_MAX_US);
        CHECK(S.pulse_us == Stirrer_PulseUs());
    }
}

static void at(int cx, int cy, double deg, int r)
{
    fake_x = (uint16_t)(cx + (int)lround(r * cos(deg * M_PI / 180.0)));
    fake_y = (uint16_t)(cy + (int)lround(r * sin(deg * M_PI / 180.0)));
}

/* This bench stick rests near X=330: learn it, arm around it, follow X. */
static void test_learned_centre_and_follow(void)
{
    now = 100;
    fake_x = 330; fake_y = 500;
    Stirrer_Init(now);
    CHECK(S.pulsing && S.pulse_us == STIR_PULSE_CENTER_US && fake_adc_inits == 1);
    run(1000, false);                       /* learn (0.3 s still) + arm (0.5 s centred) */
    CHECK(fake_adc_samples >= 90);
    CHECK(!Stirrer_OffCentre());            /* resting at 330 is NOT stirring */
    fake_x = 1023;
    run(1000, false);                       /* not cooking: home regardless of X */
    CHECK(S.pulse_us == STIR_PULSE_CENTER_US);
    fake_x = 330;
    run(700, false);
    fake_x = 1023;
    uint16_t last = S.pulse_us;
    for (int i = 0; i < 40; ++i) {          /* slew <= 10 us per 20 ms */
        run(20, true);
        CHECK(S.pulse_us >= last && S.pulse_us - last <= 10u);
        last = S.pulse_us;
    }
    CHECK(S.pulse_us == STIR_PULSE_MAX_US);
    fake_x = 0;
    run(1000, true);
    CHECK(S.pulse_us == STIR_PULSE_MIN_US);
    run(1, false);                          /* cooking ends: home now */
    CHECK(S.pulse_us == STIR_PULSE_CENTER_US);
    fake_x = 330;
    run(1000, true);
    CHECK(S.pulse_us == STIR_PULSE_CENTER_US);
}

/* Rest 330, but one side only reaches 651 (e.g. a stick supplied below 3.3 V).
 * Each side must still reach its full spoon travel at its own end. */
static void test_asymmetric_range(void)
{
    now = 10000;
    fake_x = 330; fake_y = 500;
    Stirrer_Init(now);
    run(1000, false);
    fake_x = 651;
    run(1500, true);                        /* slew 250 us at 10 us / 20 ms */
    CHECK(S.pulse_us == STIR_PULSE_MAX_US);
    fake_x = 0;
    run(1500, true);
    CHECK(S.pulse_us == STIR_PULSE_MIN_US);
    fake_x = 510;                           /* about halfway across 370..651 */
    run(1500, true);
    CHECK(S.pulse_us > STIR_PULSE_CENTER_US + 80u && S.pulse_us < STIR_PULSE_MAX_US - 80u);
    fake_x = 330;
    run(1500, true);
    CHECK(S.pulse_us == STIR_PULSE_CENTER_US);
}

static void test_motion_by_angle(void)
{
    now = 20000;
    fake_x = 330; fake_y = 500;
    Stirrer_Init(now);
    run(1000, false);
    (void)Stirrer_TakeActivity();
    CHECK(!Stirrer_OffCentre() && !Stirrer_TakeActivity());
    /* Circling: every 10 deg step is a move; stir time keeps counting. */
    for (int deg = 0; deg <= 360; deg += 10) {
        at(330, 500, deg, 200);
        run(30, true);
        CHECK(Stirrer_OffCentre() && Stirrer_TakeActivity());
    }
    /* Holding the stick still while deflected: not moving after 300 ms. */
    run(400, true);
    CHECK(!Stirrer_OffCentre() && !Stirrer_TakeActivity());
    /* A 5 deg nudge is below the 8 deg threshold. */
    at(330, 500, 5, 200);
    run(50, true);
    CHECK(!Stirrer_TakeActivity());
    /* Side to side through the centre counts (out -> centre -> out). */
    fake_x = 330; fake_y = 500;
    run(30, true);
    CHECK(Stirrer_TakeActivity());          /* returned to centre */
    fake_x = 600;
    run(30, true);
    CHECK(Stirrer_TakeActivity() && Stirrer_OffCentre());
    fake_x = 330;
    run(30, true);
    CHECK(Stirrer_TakeActivity());
    fake_x = 60;
    run(30, true);
    CHECK(Stirrer_TakeActivity());
    /* Small jitter inside the centre zone is never a move. */
    fake_x = 330; run(400, true); (void)Stirrer_TakeActivity();
    for (int i = 0; i < 20; ++i) { fake_x = (uint16_t)(330 + (i & 1 ? 30 : -30)); run(20, true); }
    CHECK(!Stirrer_TakeActivity());
    /* Stale samples stop stir time. */
    fake_x = 600; run(30, true);
    fake_adc_stall = true;
    run(150, true);
    CHECK(!Stirrer_OffCentre());
    fake_adc_stall = false;
    fake_x = 330;
    run(500, true);
}

static void test_relearn(void)
{
    now = 50000;
    fake_x = 330; fake_y = 500;
    Stirrer_Init(now);
    run(1000, false);
    /* Cooking: holding still off-centre never re-centres. */
    fake_x = 700;
    run(5000, true);
    (void)Stirrer_TakeActivity();
    fake_x = 900;                           /* same direction from 330: not a move */
    run(30, true);
    CHECK(!Stirrer_TakeActivity());
    fake_x = 330;                           /* back to the ORIGINAL centre: a move, so */
    run(30, true);                          /* the centre was not re-learned at 700 */
    CHECK(Stirrer_TakeActivity());
    /* Not cooking: still 3 s at a new rest position -> re-centred there. */
    fake_x = 520; fake_y = 510;
    run(3500, false);
    (void)Stirrer_TakeActivity();
    fake_x = 530;                           /* 10 counts from the new centre: centre zone */
    run(100, false);
    CHECK(!Stirrer_TakeActivity() && !Stirrer_OffCentre());
    fake_x = 330;                           /* 190 counts from 520: out -> a move */
    run(30, false);
    CHECK(Stirrer_TakeActivity());
}

static void test_fault_recovery(void)
{
    now = 90000;
    fake_x = 512; fake_y = 512;
    Stirrer_Init(now);
    run(1000, false);
    fake_x = 1023;
    run(600, true);
    CHECK(S.pulse_us == STIR_PULSE_MAX_US);
    /* ADC conversion fault: driver re-initialised, sampling resumes. */
    unsigned inits = fake_adc_inits, samples = fake_adc_samples;
    fake_adc_fault = true;
    run(3, true);
    CHECK(fake_adc_inits > inits);
    fake_adc_fault = false;
    run(50, true);
    CHECK(fake_adc_samples > samples && S.pulse_us == STIR_PULSE_MAX_US);
    /* Persistent fault keeps retrying instead of latching. */
    inits = fake_adc_inits;
    fake_adc_fault = true;
    run(50, true);
    CHECK(fake_adc_inits >= inits + 5);
    fake_adc_fault = false;
    /* No samples for > 100 ms: follower faults, re-arms, spoon goes home. */
    fake_adc_stall = true;
    run(150, true);
    CHECK(S.pulse_us == STIR_PULSE_CENTER_US);
    fake_adc_stall = false;
    run(300, true);                         /* X still 1023: must not re-arm */
    CHECK(S.pulse_us == STIR_PULSE_CENTER_US);
    fake_x = 512;
    run(600, true);
    fake_x = 1023;
    run(600, true);
    CHECK(S.pulse_us == STIR_PULSE_MAX_US);
}

int main(void)
{
    fake_servo_reset();
    test_learned_centre_and_follow();
    test_asymmetric_range();
    test_motion_by_angle();
    test_relearn();
    test_fault_recovery();
    Stirrer_Report();
    printf("test_stirrer: PASS\n");
    return 0;
}
