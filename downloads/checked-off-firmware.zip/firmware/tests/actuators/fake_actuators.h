#ifndef FAKE_ACTUATORS_H
#define FAKE_ACTUATORS_H
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

/* Host fakes for Servo50Hz and JoystickADC. */
typedef struct { uint16_t pulse_us; bool pulsing; unsigned writes, disables; } FakeServo;
extern FakeServo fake_servo[2];
void fake_servo_reset(void);

/* JoystickADC: a started conversion completes on the next Poll with fake_x/y,
 * unless fake_adc_stall (stays BUSY) or fake_adc_fault (latches FAULT). */
extern uint16_t fake_x, fake_y;
extern bool fake_adc_stall, fake_adc_fault;
extern unsigned fake_adc_inits, fake_adc_samples;

#define CHECK(cond) do { if (!(cond)) { \
    fprintf(stderr, "%s:%d: CHECK failed: %s\n", __FILE__, __LINE__, #cond); \
    exit(1); } } while (0)
#endif
