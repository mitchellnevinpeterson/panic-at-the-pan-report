#include "fake_actuators.h"
#include "JoystickADC.h"
#include "Servo50Hz.h"

FakeServo fake_servo[2];
void fake_servo_reset(void) { fake_servo[0] = fake_servo[1] = (FakeServo){0}; }
void Servo50Hz_Init(void) { fake_servo_reset(); }
bool Servo50Hz_Write(Servo50Hz_Channel channel, uint16_t pulse_us)
{
    CHECK(channel == SERVO_SPOON || channel == SERVO_TREAT);
    if (pulse_us < SERVO50HZ_MIN_US || pulse_us > SERVO50HZ_MAX_US) return false;
    fake_servo[channel].pulse_us = pulse_us;
    fake_servo[channel].pulsing = true;
    ++fake_servo[channel].writes;
    return true;
}
void Servo50Hz_Disable(Servo50Hz_Channel channel)
{
    fake_servo[channel].pulsing = false;
    ++fake_servo[channel].disables;
}
bool Servo50Hz_Routed(void) { return true; }
void Servo50Hz_Report(void) {}

uint16_t fake_x = 512, fake_y = 512;
bool fake_adc_stall, fake_adc_fault;
unsigned fake_adc_inits, fake_adc_samples;
static JoystickADC_State state = JOYSTICK_ADC_FAULT;

void JoystickADC_Init(void) { ++fake_adc_inits; state = JOYSTICK_ADC_IDLE; }
bool JoystickADC_Start(void)
{
    if (state != JOYSTICK_ADC_IDLE) return false;
    state = JOYSTICK_ADC_BUSY;
    return true;
}
JoystickADC_State JoystickADC_Poll(uint16_t *x, uint16_t *y)
{
    if (state != JOYSTICK_ADC_BUSY || fake_adc_stall) return state;
    if (fake_adc_fault) return state = JOYSTICK_ADC_FAULT;
    *x = fake_x;
    *y = fake_y;
    ++fake_adc_samples;
    state = JOYSTICK_ADC_IDLE;
    return JOYSTICK_ADC_READY;
}
