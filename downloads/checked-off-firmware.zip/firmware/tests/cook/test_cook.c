/* Real CookSM; fake ES queue/timer, sensors and a ScoreSM_PostDelta recorder. */
#include "CookSM.h"
#include "ScoreSM.h"
#include "ES_Configure.h"
#include "ES_Framework.h"
#include <assert.h>
#include <stdio.h>

static ES_Event_t queue[64];
static unsigned head, count;
static bool reject_post, reject_timer, reject_delta, timer_armed;
static uint16_t timer_delay;
static uint32_t clock_ms, expected_round;
static bool hand, stirring;
static uint16_t hand_mm;
static int32_t deltas[256], delta_sum;
static unsigned delta_count;

bool ES_PostToService(uint8_t priority, ES_Event_t event)
{
    assert(priority == 1);
    if (reject_post || count == 64) return false;
    queue[(head + count++) % 64] = event;
    return true;
}
ES_TimerReturn_t ES_Timer_InitTimer(uint8_t timer, uint16_t delay)
{
    assert(timer == COOK_TICK_TIMER);
    if (reject_timer) return ES_Timer_ERR;
    timer_armed = true; timer_delay = delay; return ES_Timer_OK;
}
ES_TimerReturn_t ES_Timer_StopTimer(uint8_t timer)
{
    assert(timer == COOK_TICK_TIMER);
    timer_armed = false; return ES_Timer_OK;
}
uint16_t ES_Timer_GetTime(void) { return (uint16_t)clock_ms; }
bool ScoreSM_PostDelta(uint32_t round, int32_t millipoints)
{
    assert(round == expected_round && millipoints != 0);
    if (reject_delta) return false;
    assert(delta_count < 256);
    deltas[delta_count++] = millipoints; delta_sum += millipoints;
    return true;
}

static uint32_t now_ms(void) { return clock_ms; }
static bool distance_mm(uint16_t *mm) { *mm = hand_mm; return hand; }
static bool off_centre(void) { return stirring; }

static ES_Event_t pop(void)
{
    assert(count); ES_Event_t e = queue[head]; head = (head + 1) % 64; --count; return e;
}
static void drain(void) { while (count) assert(RunCookSM(pop()).EventType == ES_NO_EVENT); }
static void clear_deltas(void) { delta_count = 0; delta_sum = 0; }
static void tick(uint32_t ms)
{
    clock_ms += ms;
    assert(timer_armed && timer_delay == COOK_TICK_MS);
    timer_armed = false; /* one-shot, like the ES timer */
    assert(PostCookSM((ES_Event_t){ES_TIMEOUT, COOK_TICK_TIMER})); drain();
}
static void ticks(unsigned n) { while (n--) tick(COOK_TICK_MS); }
static void set_hand(uint16_t mm) { hand = true; hand_mm = mm; }
static void start(uint32_t round)
{
    expected_round = round;
    assert(CookSM_PostLifecycle(GAME_START, round)); drain();
}
static void add(uint8_t n) { assert(CookSM_PostIngredient(n, expected_round)); drain(); }
static void flip(void) { assert(CookSM_PostFlip(expected_round)); drain(); }
static void end(void) { assert(CookSM_PostLifecycle(GAME_END, expected_round + 1)); drain(); }
static void reset_all(uint32_t generation)
{
    assert(CookSM_PostLifecycle(GAME_RESET, generation)); drain();
    hand = stirring = false; clear_deltas();
}
static unsigned burns(void)
{
    unsigned n = 0;
    for (unsigned i = 0; i < delta_count; ++i) n += deltas[i] == COOK_BURN_MILLI;
    return n;
}
/* Stir score as a lone delta: hand away so no heat is earned. */
static int32_t stir_score(uint8_t n, unsigned stir_ticks, unsigned idle_ticks)
{
    int32_t score;
    hand = false; add(n); clear_deltas();
    stirring = true; ticks(stir_ticks); stirring = false; ticks(idle_ticks);
    assert(delta_count == 0);
    end(); /* End closes the last ingredient; then a fresh round */
    score = delta_sum;
    start(expected_round + 2); clear_deltas();
    return score;
}

int main(void)
{
    CookOutput_t out;
    assert(!InitCookSM(1));
    CookSMPort_t port = {now_ms, distance_mm, 0};
    assert(!CookSM_BindPort(&port)); port.joystick_off_centre = off_centre;
    assert(CookSM_BindPort(&port));
    assert(InitCookSM(1)); drain();
    assert(!CookSM_BindPort(&port)); /* bound once registered */
    out = CookSM_Output();
    assert(out.lcd_mode == COOK_LCD_ATTRACT && out.zone == COOK_ZONE_NONE && !out.sizzle &&
           out.target_cm == 0 && !out.burnt && out.burn_seq == 0);
    assert(!CookSM_PostIngredient(5, 1) && !CookSM_PostLifecycle(USER_ACTIVITY, 1));

    /* Empty pan: WAITING, no heat, no sizzle, flips score nothing. */
    clock_ms = 1000; start(10); set_hand(140);
    out = CookSM_Output();
    assert(timer_armed && out.lcd_mode == COOK_LCD_WAITING && out.zone == COOK_ZONE_NONE &&
           !out.sizzle && out.target_cm == 0);
    ticks(20); flip(); flip(); flip();
    assert(delta_count == 0);

    /* On target: exactly +1 point/s, batched ~1 post per point. */
    add(0); out = CookSM_Output();
    assert(out.lcd_mode == COOK_LCD_ZONE && out.zone == COOK_ZONE_RIGHT && out.sizzle &&
           out.target_cm == 14 && !out.burnt);
    ticks(100);
    assert(delta_sum == 10000 && delta_count == 10);
    /* 40 mm off (band edge, JUST RIGHT): half rate. */
    clear_deltas(); set_hand(180); ticks(100); assert(delta_sum == 5000);
    /* 80 mm or more off, or no hand: nothing. */
    clear_deltas(); set_hand(220); ticks(50); set_hand(400); ticks(50);
    hand = false; ticks(50); assert(delta_count == 0);
    hand_mm = 140; ticks(20); assert(delta_count == 0); /* stale mm with no hand */
    /* Out-of-range readings count as no hand. */
    set_hand(20); ticks(30); set_hand(401); ticks(30); assert(delta_count == 0);
    assert(CookSM_Output().zone == COOK_ZONE_LOW);

    /* Zone confirmation: two identical ticks; a one-tick glitch never shows. */
    set_hand(140); tick(100); assert(CookSM_Output().zone == COOK_ZONE_LOW);
    tick(100); assert(CookSM_Output().zone == COOK_ZONE_RIGHT);
    set_hand(250); tick(100); assert(CookSM_Output().zone == COOK_ZONE_RIGHT);
    set_hand(140); tick(100); tick(100); assert(CookSM_Output().zone == COOK_ZONE_RIGHT);
    set_hand(99); tick(100); assert(CookSM_Output().zone == COOK_ZONE_RIGHT);
    tick(100); assert(CookSM_Output().zone == COOK_ZONE_HIGH);
    set_hand(100); ticks(2); assert(CookSM_Output().zone == COOK_ZONE_RIGHT); /* T-40 is RIGHT */
    set_hand(181); ticks(2); assert(CookSM_Output().zone == COOK_ZONE_LOW);

    /* Interrupted TOO MUCH never burns. */
    clear_deltas();
    for (int i = 0; i < 5; ++i) { set_hand(90); ticks(29); set_hand(140); ticks(1); }
    assert(burns() == 0 && !CookSM_Output().burnt);
    /* 3 s straight burns once: -10, burn_seq +1, then no more heat. */
    set_hand(90); ticks(29); assert(!CookSM_Output().burnt);
    clear_deltas(); tick(100);
    out = CookSM_Output();
    assert(out.burnt && out.burn_seq == 1 && out.zone == COOK_ZONE_HIGH && out.sizzle);
    assert(burns() == 1 && deltas[delta_count - 1] == COOK_BURN_MILLI);
    clear_deltas(); ticks(50); set_hand(140); ticks(100);
    assert(delta_count == 0 && CookSM_Output().burnt && CookSM_Output().burn_seq == 1);
    /* Next ingredient clears the burn and sets the new target. */
    add(4); out = CookSM_Output();
    assert(!out.burnt && out.burn_seq == 1 && out.target_cm == 10 && out.zone == COOK_ZONE_RIGHT);
    clear_deltas(); set_hand(100); ticks(10); assert(delta_sum == 1000);
    set_hand(50); ticks(30); assert(burns() == 1 && CookSM_Output().burn_seq == 2);
    end();
    out = CookSM_Output();
    assert(out.lcd_mode == COOK_LCD_ATTRACT && out.zone == COOK_ZONE_NONE && !out.sizzle &&
           !out.burnt && out.target_cm == 0 && out.burn_seq == 2 && !timer_armed);

    /* Stir formula: T * max(0, 1 - |t-T|/T); oil 10 * max(0, 1 - t/3 s). */
    reset_all(12); start(13);
    assert(stir_score(0, 30, 10) == 10000);  /* exactly 3 s */
    assert(stir_score(0, 15, 0) == 5000);    /* half */
    assert(stir_score(0, 45, 0) == 5000);    /* 1.5 T */
    assert(stir_score(0, 60, 0) == 0);       /* 2 T */
    assert(stir_score(0, 0, 10) == 0);       /* never stirred */
    assert(stir_score(1, 70, 0) == 10000);   /* carb 7 s */
    assert(stir_score(3, 1, 0) == 111);      /* 0.1 s of 9 s: 10000*100/9000 */
    assert(stir_score(4, 0, 20) == 10000);   /* oil untouched */
    assert(stir_score(4, 15, 0) == 5000);
    assert(stir_score(4, 30, 0) == 0);
    assert(stir_score(4, 80, 0) == 0);
    /* A burnt ingredient still gets its stir score. */
    hand = false; add(2); clear_deltas();
    stirring = true; set_hand(200); ticks(50); /* 32 cm target: 200 is TOO MUCH */
    stirring = false; ticks(5);
    assert(CookSM_Output().burnt && burns() == 1);
    clear_deltas(); hand = false; add(0); assert(delta_sum == 10000 && delta_count == 1);

    /* Flips: +2, +2, then -2 each; count resets with the next ingredient. */
    clear_deltas(); flip(); flip(); flip(); flip();
    assert(delta_count == 4 && deltas[0] == 2000 && deltas[1] == 2000 &&
           deltas[2] == -2000 && deltas[3] == -2000);
    add(1); clear_deltas(); flip(); assert(delta_count == 1 && deltas[0] == 2000);
    add(1); flip(); assert(delta_count == 2 && deltas[1] == 2000); /* repeat ignored */

    /* End flushes pending heat and scores the last ingredient's stir. */
    reset_all(114); start(115); add(1); set_hand(240);
    stirring = true; ticks(15); assert(delta_sum == 1000); /* 1.5 s: one batch posted */
    stirring = false; clear_deltas(); end();
    assert(delta_count == 2 && deltas[0] == 500 && deltas[1] == 10000 * 1500 / 7000);
    assert(!timer_armed && CookSM_Output().lcd_mode == COOK_LCD_ATTRACT);
    /* Stale tick after End: ignored, not re-armed. */
    assert(PostCookSM((ES_Event_t){ES_TIMEOUT, COOK_TICK_TIMER})); drain();
    assert(!timer_armed);

    /* Stale rounds and lifecycles. */
    reset_all(120); start(121); add(0);
    assert(CookSM_PostIngredient(1, 120) && CookSM_PostFlip(120) && CookSM_PostFlip(122)); drain();
    assert(CookSM_Output().target_cm == 14 && delta_count == 0);
    assert(CookSM_PostLifecycle(GAME_END, 120)); drain();      /* older than Start */
    assert(CookSM_PostLifecycle(GAME_RESET, 119)); drain();
    assert(CookSM_PostLifecycle(GAME_START, 121)); drain();    /* repeated Start */
    assert(CookSM_Output().lcd_mode == COOK_LCD_ZONE && CookSM_Output().target_cm == 14);
    assert(PostCookSM((ES_Event_t){ES_TIMEOUT, COOK_TICK_TIMER + 1})); drain(); /* not ours */
    /* A repeated owned ticket is consumed once. */
    assert(CookSM_PostFlip(121)); ES_Event_t dup = queue[head]; drain();
    assert(PostCookSM(dup)); drain(); assert(delta_count == 1);
    assert(PostCookSM((ES_Event_t){FLIP_PRESSED, 999})); drain(); assert(delta_count == 1);
    end();
    assert(CookSM_PostIngredient(2, 121) && CookSM_PostFlip(121)); drain(); /* after End */
    assert(CookSM_Output().lcd_mode == COOK_LCD_ATTRACT);
    assert(CookSM_PostLifecycle(GAME_RESET, 123)); drain();
    assert(CookSM_PostLifecycle(GAME_START, 121)); drain();    /* delayed old Start */
    assert(CookSM_Output().lcd_mode == COOK_LCD_ATTRACT && !timer_armed);
    /* Reset mid-round discards pending heat/stir and stops the tick. */
    clear_deltas(); start(124); add(0); set_hand(140); stirring = true; ticks(5);
    assert(CookSM_PostLifecycle(GAME_RESET, 125)); drain();
    assert(delta_count == 0 && !timer_armed && CookSM_Output().lcd_mode == COOK_LCD_ATTRACT);
    reset_all(126);

    /* dt robustness: irregular ticks give exact totals; long stalls are capped. */
    /* 10 mm off: 875 milli/s; remainders carried so 20 s is exactly 17.5. */
    start(130); set_hand(150); add(0); clear_deltas();
    static const uint16_t steps[] = {37, 163, 90, 210, 1, 99, 250, 150};
    uint32_t total = 0;
    while (total < 20000) for (unsigned i = 0; i < 8; ++i) { tick(steps[i]); total += steps[i]; }
    end(); assert(total == 20000 && delta_sum == 17500);
    reset_all(132); start(133); set_hand(140); add(0);
    clear_deltas(); tick(3000); tick(100); /* 3 s stall credits 0.5 s */
    assert(delta_count == 0);
    tick(400); assert(delta_sum == 1000);
    /* Stall in TOO MUCH: burn still needs >= 3 s of measured (capped) time. */
    set_hand(90); clear_deltas(); tick(2000); tick(2000); tick(1000);
    assert(burns() == 0);
    ticks(15); assert(burns() == 1);
    /* Stir with irregular ticks. */
    hand = false; add(1); clear_deltas(); stirring = true;
    total = 0;
    while (total < 7000) for (unsigned i = 0; i < 8; ++i) { tick(steps[i]); total += steps[i]; }
    stirring = false; tick(100); assert(total == 7000); end();
    assert(delta_sum == 10000);
    reset_all(135);

    /* Faults: ScoreSM refusal, timer failure, queue failure. */
    start(140); add(0); flip(); reject_delta = true;
    assert(CookSM_PostFlip(140));
    assert(RunCookSM(pop()).EventType == ES_ERROR && CookSM_HasFault());
    assert(!CookSM_PostFlip(140));
    reject_delta = false;
    assert(InitCookSM(1)); drain(); assert(!CookSM_HasFault());
    reject_timer = true; assert(CookSM_PostLifecycle(GAME_START, 41));
    assert(RunCookSM(pop()).EventType == ES_ERROR && CookSM_HasFault());
    reject_timer = false;
    assert(InitCookSM(1)); drain();
    reject_post = true; assert(!CookSM_PostFlip(1) && CookSM_HasFault()); reject_post = false;
    assert(InitCookSM(1)); drain();
    for (unsigned i = 0; i < 16; ++i) assert(CookSM_PostFlip(1));
    assert(!CookSM_PostFlip(1) && CookSM_HasFault());

    /* Wrap-around generations after a fresh init. */
    head = count = 0; assert(InitCookSM(1)); drain();
    start(UINT32_MAX); add(3); set_hand(280); ticks(10);
    assert(CookSM_PostLifecycle(GAME_END, 0)); drain();
    assert(CookSM_Output().lcd_mode == COOK_LCD_ATTRACT);
    assert(CookSM_PostLifecycle(GAME_RESET, 1)); drain();
    expected_round = 2; assert(CookSM_PostLifecycle(GAME_START, 2)); drain();
    assert(CookSM_Output().lcd_mode == COOK_LCD_WAITING);

    puts("CookSM passed: heat rate/falloff, zones, burn, stir, flips, End, stale rounds, dt, faults.");
    return 0;
}
