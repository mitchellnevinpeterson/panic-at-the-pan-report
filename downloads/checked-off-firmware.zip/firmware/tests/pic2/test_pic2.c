#include "Inputs.h"
#include "Range.h"
#include "ButtonSensor.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
/* ButtonSensor (PIC2) <-> PeerLink controller (PIC1) over an in-memory wire. */
static uint32_t ms;
static uint8_t to_ctrl[8192],to_sensor[8192]; static size_t n_ctrl,n_sensor;
static PeerLink ctrl; static unsigned inputs,sensors; static uint8_t last_id; static uint16_t last_mm; static bool last_valid;
static uint32_t clock_fn(void *v) { (void)v; return ms; }
static bool sensor_send(const uint8_t *b,size_t n,void *v) { (void)v; assert(n_ctrl+n<=sizeof to_ctrl); memcpy(to_ctrl+n_ctrl,b,n); n_ctrl+=n; return true; }
static bool ctrl_send(const uint8_t *b,size_t n,void *v) { (void)v; assert(n_sensor+n<=sizeof to_sensor); memcpy(to_sensor+n_sensor,b,n); n_sensor+=n; return true; }
static void ctrl_event(const PeerEvent *e,void *v) {
    (void)v;
    if(e->kind==PEER_INPUT) { ++inputs; last_id=e->input_id; }
    if(e->kind==PEER_SENSOR_READING) { ++sensors; last_mm=e->distance_mm; last_valid=e->valid; }
}
static void pump(ButtonSensor *s,unsigned ticks,uint8_t gpio) {
    while(ticks--) {
        size_t i,n;
        PeerLink_Service(&ctrl); PeerLink_Service(&s->link);
        n=n_sensor; n_sensor=0; for(i=0;i<n;i++) PeerLink_ReceiveByte(&s->link,to_sensor[i]);
        n=n_ctrl; n_ctrl=0; for(i=0;i<n;i++) PeerLink_ReceiveByte(&ctrl,to_ctrl[i]);
        ButtonSensor_Sample(s,gpio); ++ms;
    }
}
static void sensor_tests(void) {
    static ButtonSensor s; PeerControl c;
    ms=1000; PeerLink_Init(&ctrl,PEER_CONTROLLER,1,clock_fn,ctrl_send,ctrl_event,0);
    ButtonSensor_Init(&s,clock_fn,sensor_send,0);
    assert(!ButtonSensor_SendRange(&s,200,true,ms)); /* not synchronized: dropped */
    pump(&s,900,0xff); assert(PeerLink_IsSynchronized(&ctrl)&&PeerLink_IsSynchronized(&s.link));
    /* GPA6 press edge -> input id 6 at PIC1, once per press. */
    pump(&s,30,0xbf); pump(&s,100,0xbf); assert(inputs==1&&last_id==6);
    pump(&s,30,0xff); pump(&s,30,0xbf); pump(&s,100,0xbf); assert(inputs==2&&last_id==6);
    pump(&s,30,0xff);
    /* Control fields reach ButtonSensor_Control. */
    PeerControl want={.lamp=true,.start_lamp=false,.audio_enabled=true,.audio_zone=3,.lcd_mode=2,.burnt=true,.burn_seq=2,.target_cm=28};
    PeerLink_SendControl(&ctrl,&want); pump(&s,150,0xff); c=ButtonSensor_Control(&s);
    assert(c.lamp&&c.audio_enabled&&c.audio_zone==3&&c.lcd_mode==2&&c.burnt&&c.burn_seq==2&&c.target_cm==28);
    assert(ButtonSensor_Outputs(&s)==1u);
    /* Range samples reach PIC1 while synchronized. */
    assert(ButtonSensor_SendRange(&s,143,true,ms)); pump(&s,2,0xff); assert(sensors==1&&last_mm==143&&last_valid);
    assert(ButtonSensor_SendRange(&s,0,false,ms)); pump(&s,2,0xff); assert(sensors==2&&!last_valid);
    /* Link loss clears all controller state. */
    PeerLink_Fault(&s.link); c=ButtonSensor_Control(&s);
    assert(!c.lamp&&!c.audio_enabled&&c.lcd_mode==0&&!c.burnt&&c.target_cm==0&&ButtonSensor_Outputs(&s)==0);
}
int main(void) {
    sensor_tests();
    Pic2Inputs p; Pic2Range r; uint32_t t=0xfffffff0u;
    Pic2Inputs_Reset(&p,0x7f,0); /* Start held at power-on. */
    assert(Pic2Inputs_Update(&p,0x7f,100,true)==0);
    assert(Pic2Inputs_Update(&p,0xff,101,true)==0);
    assert(Pic2Inputs_Update(&p,0xff,121,true)==0);
    assert(Pic2Inputs_Update(&p,0x7f,130,true)==0);
    assert(Pic2Inputs_Update(&p,0xff,135,true)==0); /* bounce */
    assert(Pic2Inputs_Update(&p,0x7f,138,true)==0);
    assert(Pic2Inputs_Update(&p,0x7f,157,true)==0);
    assert(Pic2Inputs_Update(&p,0x7f,158,true)==0x80);
    assert(p.changed[7]==138);
    assert(Pic2Inputs_Update(&p,0x7f,1000,true)==0);
    Pic2Inputs_Reset(&p,0x7f,1001); assert(Pic2Inputs_Update(&p,0x7f,2000,true)==0);
    assert(Pic2Inputs_Update(&p,0xff,2001,false)==0);
    assert(Pic2Inputs_Update(&p,0xff,2022,true)==0);
    assert(Pic2Inputs_Update(&p,0xbf,2023,true)==0);
    assert(Pic2Inputs_Update(&p,0xbf,2043,true)==0x40); /* pan flip GPA6 forwarded */
    assert(p.changed[6]==2023);
    assert(Pic2Inputs_Update(&p,0xbf,2100,true)==0); /* held: one edge only */
    assert(Pic2Inputs_Update(&p,0xff,2101,true)==0); /* release must be stable 20 ms */
    assert(Pic2Inputs_Update(&p,0xbf,2110,true)==0); /* bounce during release */
    assert(Pic2Inputs_Update(&p,0xbf,2135,true)==0); /* never re-armed: no edge */
    assert(Pic2Inputs_Update(&p,0xff,2136,true)==0);
    assert(Pic2Inputs_Update(&p,0xff,2156,true)==0); /* stable release re-arms */
    assert(Pic2Inputs_Update(&p,0xbf,2157,true)==0);
    assert(Pic2Inputs_Update(&p,0xbf,2177,true)==0x40); /* second flip */
    /* Flip held through a reset/resync never counts. */
    Pic2Inputs_Reset(&p,0xbf,3000); assert(Pic2Inputs_Update(&p,0xbf,3100,true)==0);
    Pic2Inputs_Reset(&p,0xff,t); assert(!Pic2Inputs_Update(&p,0xff,t+21,true));
    assert(!Pic2Inputs_Update(&p,0xdf,t+22,true));
    assert(Pic2Inputs_Update(&p,0xdf,t+42,true)==0x20);
    Pic2Range_Init(&r,t); Pic2Range_Poll(&r,t,false); assert(r.trigger);
    Pic2Range_Poll(&r,t+239,false); assert(r.trigger);
    Pic2Range_Poll(&r,t+240,false); assert(!r.trigger);
    Pic2Range_Poll(&r,t+1000,true); Pic2Range_Poll(&r,t+24200,false);
    assert(r.sample_ready&&r.valid&&r.mm==198); /* 1160 us, ~199 mm */
    r.sample_ready=false; Pic2Range_Poll(&r,t+24200+1999999,false); assert(!r.trigger);
    Pic2Range_Poll(&r,t+24200+2000000,false); assert(r.trigger);
    uint32_t start=t+24200+2000000;
    Pic2Range_Poll(&r,start+240,false); Pic2Range_Poll(&r,start+600240,false);
    assert(r.sample_ready&&!r.valid&&!r.trigger);
    Pic2Range_Init(&r,0); Pic2Range_Poll(&r,0,true); assert(r.sample_ready&&!r.valid); /* stuck high */
    Pic2Range_Init(&r,0); Pic2Range_Poll(&r,0,false); Pic2Range_Poll(&r,240,false);
    Pic2Range_Poll(&r,500,true); Pic2Range_Poll(&r,600500,true); assert(!r.valid&&r.sample_ready);
    puts("pic2 tests: ButtonSensor flip/control/range, held startup/reset, release gating, bounce, edge timestamp, pan flip GPA6, timer wrap, trigger, range, stuck/missing echo passed");
    return 0;
}
