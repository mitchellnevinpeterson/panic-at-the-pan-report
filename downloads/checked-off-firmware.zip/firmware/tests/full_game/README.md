# Full gameplay subservice tests

Run `make -C firmware/tests/full_game test` from the repository root. The host
suite compiles the actual HeatSM, StirSM, PanDisplaySM and ScoreSM with strict
warnings, AddressSanitizer and UndefinedBehaviorSanitizer. It emulates the ES
priority queues, timers, GameSM's generation/round gates and bounded I/O ports.
The synthetic recipe and tuning values in the test are **not calibration**.

Covered behavior includes a complete configured round with ingredient changes,
heat integration, stirring, final stir credit after the input generation changes
at End, duplicate End/result suppression, reset, and stale prior-round events.
The suite also exercises invalid/stale/repeated/future distance readings,
interrupted and sustained burn clocks, configurable burn-clock transfer,
irregular valid heat-sample intervals, fractional score accumulation, stationary
and centered joystick input, shortest-path angular wrap, input timestamp wrap,
icon-over-swirl priority, superseded timeout tickets, display saturation, queue
exhaustion, and timer/output/post failures. A separate process binds the real
unconfigured production tuning and verifies zero formal score, safe disabled
heat/motor outputs, and working lifecycle/pan states.

The unchanged ingredient-only bench is validated separately with
`make -C firmware/bench/game_sm test`; its four-member ScoreSM port and explicit
+10 rule remain supported.

## Contracts for adapters

Bind ports and tuning before ES initialization. Ports run in the foreground,
return failure explicitly, and must never block. Services copy tuning at bind;
there is no runtime tuning mutation. Use the owned message APIs, not raw event
parameters. GameSM owns generation changes. Start/End/Reset use its current
lifecycle generation; score callbacks use the **earned round** retained through
results. The adapter must keep accepting that round until reset, while rejecting
new gameplay input as soon as End/deadlines become authoritative.

Heat accepts only fresh completed sensor measurements. Distance min/max map to
1000/0 heat, clamped at either endpoint. Between adjacent valid readings it uses
the mean of the two normalized closeness values and actual elapsed milliseconds.
Invalid, repeated, out-of-order or excessively separated readings break scoring
and burn continuity. Burn checks occur on fresh samples after at least 3000 ms
above 1.5 times target; a timer alone cannot prove sustained heat. New ingredients
always clear a latched burn. The explicit burn-transfer selector determines
whether an *unburnt* overheat clock survives an ingredient change.

Stir accepts fresh angle observations in millidegrees. It credits only elapsed
intervals whose shortest angular delta reaches the configured threshold, with
both observations non-home and separated by no more than the configured motion
timeout. Timers can stop the logical movement indication but never add time.
Holding an angle and automatic return-home earn no credit. This measures commanded
movement, not physical position feedback. End posts the retained result once;
Reset discards it.

Pan sends semantic frame requests and one icon-expiry transition. It promises no
fast animation. An e-ink adapter must coalesce and rate-limit those requests.

## Scoring and remaining team choices

`ScoreSM_BindTuning` selects formal mode; `configured=false` means zero formal
score. Not calling it preserves the separate bench's ingredient-only mode.
Configured scoring requires every mandatory value to pass `GameTuning_IsValid`:
recipe mask/reward/penalties, distance endpoints and freshness limit, heat targets,
optimal stir times, movement threshold/home/timeout, both weights, and the explicit
stir-curve and burn-transfer selectors. No production values are provided.

Heat awards `heat_weight * closeness * elapsed_seconds`, where closeness is 0..1.
The selectable stir curve is
`stir_weight * max(0, 1 - abs(actual_ms-optimal_ms)/optimal_ms)`.
**The team must approve this curve** before selecting it; the design specifies
only qualitative closeness. Awards retain micro-point precision, rounded once per
award, with integer overflow protection. The displayed integer truncates fractional
points and saturates to -999..9999; ordinary above-display balance remains available
for later penalties. The negative-score policy is explicit. Burn and stir results
are accepted at most once per ingredient, and consumed event tickets cannot replay.

Default unconfigured Heat remains safely empty. Stir retains logical ingredient
state while leaving the motor disabled and emitting no stir results. These defaults
do not replace hardware calibration, waveform validation, or play testing.
