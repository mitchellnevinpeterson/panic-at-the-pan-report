/* Synthetic tuning is test data, never production calibration. Test the actual
 * four service implementations, with bounded ES queues and captured I/O. */
#include "HeatSM.h"
#include "StirSM.h"
#include "PanDisplaySM.h"
#include "ScoreSM.h"
#include "ES_Framework.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

typedef struct { ES_Event_t data[32]; unsigned head, count; } Queue;
static Queue queues[4];
static uint32_t now, generation, round_id, measurement_at;
static uint16_t distance, heat;
static bool playing, accepts_results, measurement_valid, heat_valid, burned, motor_enabled;
static bool reject_post, reject_timer, reject_output;
static unsigned burns, heat_credits, stir_results, motor_calls, frame_calls;
static uint32_t last_stir_elapsed, last_stir_round;
static bool timers[16];
static uint32_t deadlines[16];
static PanDisplaySMState_t pan_frame;
static int32_t displayed;
static uint8_t pan_mask;
static uint32_t clock_now(void) { return now; }
static uint32_t current_generation(void) { return generation; }
static bool accepts_input(uint32_t at, uint32_t gen)
{ return playing && gen == generation && now - at <= GAME_INPUT_MAX_AGE_MS; }
static bool accepts_round(uint32_t gen) { return accepts_results && gen == round_id; }
static bool read_distance(uint16_t *mm, uint32_t *at)
{ *mm = distance; *at = measurement_at; return measurement_valid; }
static bool heat_output(uint16_t level, bool burning, bool valid)
{ heat = level; burned = burning; heat_valid = valid; return !reject_output; }
static bool heat_score(uint8_t id, uint32_t gen, uint16_t closeness, uint32_t ms)
{ ++heat_credits; return ScoreSM_PostHeat(id, gen, closeness, ms); }
static bool burn_score(uint8_t id, uint32_t gen)
{ ++burns; return ScoreSM_PostBurn(id, gen); }
static bool motor(uint32_t angle, bool home, bool enabled)
{ (void)home; assert(angle < 360000u); motor_enabled = enabled; ++motor_calls; return !reject_output; }
static bool motion(bool moving, uint32_t at, uint32_t gen)
{ return PanDisplaySM_PostMotion(moving, at, gen); }
static bool stir_score(uint8_t id, uint32_t gen, uint32_t ms)
{ ++stir_results; last_stir_elapsed = ms; last_stir_round = gen; return ScoreSM_PostStir(id, gen, ms); }
static bool frame(PanDisplaySMState_t state, uint8_t mask, uint8_t latest)
{ assert(latest < INGREDIENT_COUNT); pan_frame = state; pan_mask = mask; ++frame_calls; return !reject_output; }
static bool display(int32_t score)
{ assert(accepts_results); assert(score >= -999 && score <= 9999); displayed = score; return !reject_output; }
bool ES_PostToService(uint8_t priority, ES_Event_t event)
{
    assert(priority < 4);
    Queue *q = &queues[priority];
    if (reject_post || q->count == 32) return false;
    q->data[(q->head + q->count++) % 32] = event;
    return true;
}
ES_TimerReturn_t ES_Timer_InitTimer(uint8_t id, uint16_t delay)
{ assert(id < 16 && delay > 0); if (reject_timer) return ES_Timer_ERR; timers[id] = true; deadlines[id] = now + delay; return ES_Timer_OK; }
ES_TimerReturn_t ES_Timer_StopTimer(uint8_t id)
{ assert(id < 16); if (reject_timer) return ES_Timer_ERR; timers[id] = false; return ES_Timer_OK; }
uint16_t ES_Timer_GetTime(void) { return (uint16_t)now; }
static ES_Event_t pop(uint8_t priority)
{ Queue *q = &queues[priority]; assert(q->count); ES_Event_t e = q->data[q->head]; q->head = (q->head + 1) % 32; --q->count; return e; }
static ES_Event_t run(uint8_t priority, ES_Event_t event)
{
    switch (priority) {
        case 0: return RunPanDisplaySM(event);
        case 1: return RunScoreSM(event);
        case 2: return RunStirSM(event);
        default: return RunHeatSM(event);
    }
}
static void drain(void)
{
    for (;;) {
        int p;
        for (p = 3; p >= 0 && !queues[p].count; --p) {}
        if (p < 0) return;
        assert(run((uint8_t)p, pop((uint8_t)p)).EventType == ES_NO_EVENT);
    }
}
static void lifecycle(ES_EventType_t type)
{
    assert(HeatSM_PostLifecycle(type, generation, now));
    assert(StirSM_PostLifecycle(type, generation, now));
    assert(PanDisplaySM_PostLifecycle(type, generation, now, GAME_COMPLETED));
    if (type != GAME_END) assert(ScoreSM_PostLifecycle(type, generation));
}
static void reset(void)
{
    memset(queues, 0, sizeof queues); memset(timers, 0, sizeof timers);
    playing = accepts_results = reject_post = reject_timer = reject_output = false;
    now = 1000; ++generation;
    assert(InitPanDisplaySM(0)); assert(InitScoreSM(1)); assert(InitStirSM(2)); assert(InitHeatSM(3));
    /* Lifecycle queued behind Init must work; duplicate Init is harmless. */
    lifecycle(GAME_RESET); drain();
    burns = heat_credits = stir_results = motor_calls = frame_calls = 0;
    measurement_valid = true; distance = 600; measurement_at = now;
    assert(!motor_enabled && !heat_valid && pan_frame == PAN_ATTRACT);
}
static void start(void)
{ ++generation; round_id = generation; playing = accepts_results = true; lifecycle(GAME_START); drain(); }
static void ingredient_event(uint8_t id)
{
    assert(ScoreSM_PostIngredient(id, round_id));
    assert(HeatSM_PostIngredient(id, round_id, now));
    assert(StirSM_PostIngredient(id, round_id, now));
    assert(PanDisplaySM_PostIngredient(id, round_id, now));
    drain();
}
static void heat_tick(uint32_t dt)
{
    now += dt; measurement_at = now;
    assert(PostHeatSM((ES_Event_t){ES_TIMEOUT, HEAT_SAMPLE_TIMER})); drain();
}
static void angle(uint32_t angle_mdeg, bool home, uint32_t dt)
{ now += dt; assert(StirSM_PostMotion(angle_mdeg, home, now, generation)); drain(); }
static GameTuning_t fixture(void)
{
    GameTuning_t t = {.configured=true, .distance_min_mm=100, .distance_max_mm=1100,
        .heat_target={500,500,500,500,500}, .optimal_stir_ms={100,100,100,100,100},
        .heat_sample_max_age_ms=200, .burn_transfer_rule=GAME_BURN_TRANSFER_RESET,
        .stir_debounce_ms=100, .stir_motion_threshold_mdeg=500,
        .stir_home_angle_mdeg=0, .stir_score_rule=GAME_STIR_SCORE_LINEAR_RELATIVE_ERROR,
        .recipe_mask=15, .points_right=100, .penalty_wrong=150, .penalty_burn=30,
        .heat_weight=10, .stir_weight=20, .allow_negative_score=true};
    return t;
}
static void bind(GameTuning_t *t)
{
    HeatSMPort_t h={clock_now,current_generation,accepts_input,accepts_round,read_distance,heat_output,heat_score,burn_score};
    StirSMPort_t s={clock_now,current_generation,accepts_input,accepts_round,motor,motion,stir_score};
    PanDisplaySMPort_t p={clock_now,current_generation,accepts_input,frame};
    ScoreSMPort_t c={current_generation,accepts_round,display,10,0,false};
    assert(HeatSM_BindPort(&h,t)); assert(StirSM_BindPort(&s,t)); assert(PanDisplaySM_BindPort(&p,t));
    assert(ScoreSM_BindPort(&c)); assert(ScoreSM_BindTuning(t));
}
int main(int argc, char **argv)
{
    GameTuning_t t=fixture(), bad=t;
    assert(!GameTuning_IsValid(&GameTuning)); assert(GameTuning_IsValid(&t));
    bad.heat_target[2]=0; assert(!GameTuning_IsValid(&bad)); bad=t;
    bad.heat_weight=NAN; assert(!GameTuning_IsValid(&bad)); bad=t;
    bad.stir_motion_threshold_mdeg=0; assert(!GameTuning_IsValid(&bad)); bad=t;
    bad.recipe_mask=128; assert(!GameTuning_IsValid(&bad)); bad=t;
    bad.stir_score_rule=GAME_STIR_SCORE_UNCONFIGURED; assert(!GameTuning_IsValid(&bad)); bad=t;
    bad.burn_transfer_rule=GAME_BURN_TRANSFER_UNCONFIGURED; assert(!GameTuning_IsValid(&bad));
    if (argc > 1 && !strcmp(argv[1],"unconfigured")) {
        t=GameTuning; bind(&t); reset(); start(); ingredient_event(0);
        assert(!ScoreSM_IsConfigured() && !HeatSM_IsConfigured() && !StirSM_IsConfigured());
        assert(ScoreSM_Value()==0 && !motor_enabled && !heat_valid);
        assert(QueryHeatSM()==HEAT_PAN_EMPTY && QueryStirSM()==STIR_NOT_STIRRING);
        assert(QueryPanDisplaySM()==PAN_NEW_INGREDIENT);
        angle(100000,false,50); heat_tick(100);
        assert(ScoreSM_Value()==0 && !motor_enabled && !heat_valid && !burns && !stir_results);
        playing=false; ++generation; lifecycle(GAME_END); drain();
        assert(!stir_results && pan_frame==PAN_GAME_OVER_TEXT);
        puts("Unconfigured full mode: six-service-compatible lifecycle, semantic pan, safe motor/heat, score zero.");
        return 0;
    }
    if (argc > 1 && !strcmp(argv[1],"preserve-burn")) {
        t.burn_transfer_rule=GAME_BURN_TRANSFER_PRESERVE; bind(&t); reset(); start(); ingredient_event(0);
        distance=100; for(unsigned i=0;i<20;++i) heat_tick(100);
        ingredient_event(1); assert(QueryHeatSM()==HEAT_OVERHEATING);
        for(unsigned i=0;i<11;++i) heat_tick(100);
        assert(burns==1 && QueryHeatSM()==HEAT_BURNING);
        ingredient_event(2); assert(QueryHeatSM()==HEAT_COOKING && !burned);
        puts("Explicit preserve-burn policy: threshold clock transfers; burnt status clears on next ingredient.");
        return 0;
    }
    bind(&t); reset(); start(); ingredient_event(0);
    assert(displayed==100 && motor_enabled && pan_mask==1);
    heat_tick(100); assert(heat==500 && heat_valid && displayed==100);
    for(unsigned i=0;i<10;++i) heat_tick(100);
    assert(displayed==110); /* 10 points/sec independent of sample count. */
    unsigned credits=heat_credits;
    measurement_valid=false; heat_tick(100); assert(!heat_valid && heat_credits==credits);
    measurement_valid=true; heat_tick(100); assert(heat_credits==credits);
    heat_tick(100); assert(displayed==111);
    /* Stale timeout cannot sample early after a newer arm. */
    assert(PostHeatSM((ES_Event_t){ES_TIMEOUT,HEAT_SAMPLE_TIMER})); drain(); assert(displayed==111);
    /* Repeated and future readings invalidate the clock. */
    now+=100; assert(PostHeatSM((ES_Event_t){ES_TIMEOUT,HEAT_SAMPLE_TIMER})); drain(); assert(!heat_valid);
    now+=100; measurement_at=now+1; assert(PostHeatSM((ES_Event_t){ES_TIMEOUT,HEAT_SAMPLE_TIMER})); drain(); assert(!heat_valid);
    distance=100; for(unsigned i=0;i<30;++i) heat_tick(100);
    assert(QueryHeatSM()==HEAT_OVERHEATING && burns==0);
    measurement_valid=false; heat_tick(100); assert(QueryHeatSM()==HEAT_COOKING);
    measurement_valid=true; for(unsigned i=0;i<30;++i) heat_tick(100);
    assert(burns==0); heat_tick(100); assert(burns==1 && burned && QueryHeatSM()==HEAT_BURNING);
    credits=heat_credits; distance=600; for(unsigned i=0;i<4;++i) heat_tick(100);
    assert(burns==1 && heat_credits==credits && burned);
    int32_t before=displayed;
    assert(ScoreSM_PostBurn(0,round_id)); drain(); assert(displayed==before);
    ingredient_event(1); assert(QueryHeatSM()==HEAT_COOKING && !burned);
    /* Distinct ingredients reset burn timing under selected RESET policy. */
    distance=100; for(unsigned i=0;i<20;++i) heat_tick(100);
    ingredient_event(2); for(unsigned i=0;i<20;++i) heat_tick(100); assert(burns==1);

    reset(); start(); ingredient_event(0);
    angle(359000,false,0); angle(0,false,50); /* Shortest wraparound delta is 1 degree. */
    assert(StirSM_ElapsedMs()==50 && QueryStirSM()==STIR_STIRRING);
    assert(pan_frame==PAN_NEW_INGREDIENT); /* Icon masks swirl until due. */
    angle(1000,false,50); assert(StirSM_ElapsedMs()==100);
    angle(1000,false,50); assert(QueryStirSM()==STIR_NOT_STIRRING && StirSM_ElapsedMs()==100);
    angle(2000,true,50); angle(2000,false,50); assert(StirSM_ElapsedMs()==100);
    angle(3000,false,50); assert(StirSM_ElapsedMs()==150);
    now+=500; assert(PostStirSM((ES_Event_t){ES_TIMEOUT,STIR_TICK_TIMER})); drain();
    assert(QueryStirSM()==STIR_NOT_STIRRING && StirSM_ElapsedMs()==150);
    angle(4000,false,0); angle(5000,false,50); assert(StirSM_ElapsedMs()==200);
    /* New icon supersedes a queued earlier icon timeout. */
    ingredient_event(1); assert(stir_results==1 && last_stir_elapsed==200);
    assert(PostPanDisplaySM((ES_Event_t){ES_TIMEOUT,ICON_TIMER})); drain(); assert(pan_frame==PAN_NEW_INGREDIENT);
    angle(10000,false,0); angle(11000,false,50); angle(12000,false,50);
    assert(StirSM_ElapsedMs()==100);
    now=deadlines[ICON_TIMER]; assert(PostPanDisplaySM((ES_Event_t){ES_TIMEOUT,ICON_TIMER})); drain();
    assert(pan_frame==PAN_SWIRL);
    /* End changes input generation before the final stir is delivered. */
    playing=false; ++generation;
    assert(PostStirSM((ES_Event_t){ES_TIMEOUT,STIR_TICK_TIMER}));
    lifecycle(GAME_END); drain();
    assert(stir_results==2 && last_stir_elapsed==100 && last_stir_round==round_id);
    assert(displayed==220 && !motor_enabled && pan_frame==PAN_GAME_OVER_TEXT);
    lifecycle(GAME_END); drain(); assert(stir_results==2); /* Duplicate End cannot rescore. */
    before=displayed; assert(ScoreSM_PostStir(1,round_id,100)); drain(); assert(displayed==before);
    accepts_results=false; ++generation; lifecycle(GAME_RESET); drain();
    assert(ScoreSM_Value()==0 && pan_frame==PAN_ATTRACT);
    assert(ScoreSM_PostStir(1,round_id,100)); drain(); assert(ScoreSM_Value()==0);

    reset(); now=UINT32_MAX-70u; start(); ingredient_event(0);
    angle(1000,false,0); angle(2000,false,50); angle(3000,false,50);
    assert(now==29u && StirSM_ElapsedMs()==100);
    heat_tick(100); heat_tick(100); assert(heat_valid);
    uint32_t stale=generation; ++generation; round_id=generation; lifecycle(GAME_START); drain();
    assert(StirSM_PostLifecycle(GAME_RESET,stale,now));
    assert(HeatSM_PostLifecycle(GAME_RESET,stale,now));
    assert(PanDisplaySM_PostLifecycle(GAME_RESET,stale,now,GAME_COMPLETED)); drain();
    ingredient_event(0); assert(motor_enabled && pan_frame==PAN_NEW_INGREDIENT);

    reset(); start(); ingredient_event(0);
    heat_tick(100); heat_tick(200); assert(displayed==102); /* Irregular valid cadence. */
    reset(); start(); ingredient_event(0);
    for(unsigned i=0;i<10;++i) { assert(ScoreSM_PostHeat(0,round_id,100,100)); drain(); }
    assert(displayed==101); /* Fractional credits accumulate, not per-tick rounding. */
    angle(1000,false,0); angle(2000,false,50); angle(0,true,50);
    unsigned calls=motor_calls;
    assert(StirSM_PostMotion(3000,false,now-50,generation)); drain();
    assert(motor_calls==calls); /* Center must not allow older queued angles back in. */
    uint32_t old_round=round_id;
    assert(PostPanDisplaySM((ES_Event_t){ES_INIT,0})); drain(); assert(pan_frame==PAN_NEW_INGREDIENT);
    playing=false; ++generation;
    assert(PanDisplaySM_PostLifecycle(GAME_END,generation,now,GAME_IDLE_TIMEOUT)); drain();
    assert(pan_frame==PAN_TIMEOUT_ICON);
    accepts_results=false; ++generation; lifecycle(GAME_RESET); drain(); start();
    assert(ScoreSM_PostHeat(0,old_round,1000,100)); drain(); assert(displayed==0);

    reset(); start(); ingredient_event(4); assert(displayed==-150);
    assert(ScoreSM_PostHeat(4,round_id,1000,60000)); drain(); assert(displayed==450);
    /* Large finite awards and penalties saturate safely, preserving fractional totals. */
    for(unsigned i=0;i<20;++i) { assert(ScoreSM_PostHeat(4,round_id,1000,60000)); drain(); }
    assert(displayed==9999);
    assert(!ScoreSM_PostHeat(4,round_id,1001,100)); assert(!ScoreSM_PostStir(4,round_id,60001));
    assert(!ScoreSM_HasFault());

    /* Faults stop physical outputs and cannot be mistaken for success. */
    reset(); start(); ingredient_event(0); reject_output=true;
    now+=100; measurement_at=now;
    assert(RunHeatSM((ES_Event_t){ES_TIMEOUT,HEAT_SAMPLE_TIMER}).EventType==ES_ERROR);
    assert(HeatSM_HasFault() && !heat_valid);
    reset(); start(); ingredient_event(0); reject_timer=true;
    now+=100; measurement_at=now;
    assert(RunHeatSM((ES_Event_t){ES_TIMEOUT,HEAT_SAMPLE_TIMER}).EventType==ES_ERROR);
    assert(HeatSM_HasFault());
    reset(); start(); ingredient_event(0);
    for(unsigned i=0;i<16;++i) assert(StirSM_PostMotion(i*1000,false,now,generation));
    assert(!StirSM_PostMotion(17000,false,now,generation));
    assert(run(2,pop(2)).EventType==ES_ERROR && StirSM_HasFault() && !motor_enabled);
    reset(); reject_post=true; assert(!PanDisplaySM_PostIngredient(0,generation,now));
    assert(PanDisplaySM_HasFault());
    puts("Full subservices passed: freshness/burn clocks, elapsed heat, real angle intervals, final-End stir, semantic pan priority, round isolation, score saturation, faults.");
    return 0;
}
