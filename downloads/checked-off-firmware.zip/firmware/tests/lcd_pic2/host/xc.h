#ifndef LCD_TEST_XC_H
#define LCD_TEST_XC_H
#include <stdint.h>
/* Model atomic SET/CLR writes so the real bit-bang loop can be checked. */
struct RegisterWrite {
    uint32_t *value;
    bool set;
    bool output;
    void operator=(uint32_t mask) const;
};
extern uint32_t host_lat, host_tris, host_ans, host_odc, host_cn, host_pu, host_pd;
extern RegisterWrite LATBSET, LATBCLR, TRISBCLR, ANSELBCLR, ODCBCLR;
extern RegisterWrite CNENBCLR, CNPUBCLR, CNPDBCLR;
extern uint32_t SYSKEY, RPB5R, RPB7R, RPB9R, RPB13R;
struct HostJtag { unsigned JTAGEN; };
struct HostConfig { unsigned IOLOCK; };
extern HostJtag DDPCONbits;
extern HostConfig CFGCONbits;
unsigned host_disable(void);
void host_enable(void);
uint32_t host_count(void);
#define __builtin_disable_interrupts host_disable
#define __builtin_enable_interrupts host_enable
#define _CP0_GET_COUNT host_count
#endif
