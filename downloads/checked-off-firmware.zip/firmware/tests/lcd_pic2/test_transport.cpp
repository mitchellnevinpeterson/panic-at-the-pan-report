#include "LcdSoftSPI.h"
#include <cassert>
#include <cstdio>
#include <vector>
uint32_t host_lat, host_tris, host_ans, host_odc, host_cn, host_pu, host_pd;
RegisterWrite LATBSET{&host_lat,true,true}, LATBCLR{&host_lat,false,true};
RegisterWrite TRISBCLR{&host_tris,false,false}, ANSELBCLR{&host_ans,false,false};
RegisterWrite ODCBCLR{&host_odc,false,false}, CNENBCLR{&host_cn,false,false};
RegisterWrite CNPUBCLR{&host_pu,false,false}, CNPDBCLR{&host_pd,false,false};
uint32_t SYSKEY, RPB5R, RPB7R, RPB9R, RPB13R;
HostJtag DDPCONbits;
HostConfig CFGCONbits;
static bool irq, transfer;
static uint32_t ticks;
static unsigned edges_down;
static std::vector<bool> bits;
unsigned host_disable(void) { unsigned old=irq; irq=false; return old; }
void host_enable(void) { irq=true; }
uint32_t host_count(void) { ticks+=20; return ticks; }
void RegisterWrite::operator=(uint32_t mask) const {
    uint32_t before=*value;
    *value=set ? before|mask : before&~mask;
    if (transfer && output) {
        assert(!(mask & ~(LCD_MOSI|LCD_SCK))); // Never touch CS/DC/reset or other peripherals.
        assert(irq); // No long interrupt blackout while drawing.
        if (!(before&LCD_SCK) && (*value&LCD_SCK)) bits.push_back((*value&LCD_MOSI)!=0);
        if ((before&LCD_SCK) && !(*value&LCD_SCK)) ++edges_down;
    }
}
int main(void) {
    const uint32_t pins=LCD_MOSI|LCD_SCK|LCD_CS|LCD_DC|LCD_RST;
    assert(LCD_MOSI==(1u<<5) && LCD_SCK==(1u<<7) && LCD_CS==(1u<<9));
    assert(LCD_DC==(1u<<12) && LCD_RST==(1u<<13));
    for (bool initial_irq : {false,true}) {
        host_lat=0xa5a5a5a5u;
        const uint32_t other=host_lat&~pins;
        host_tris=host_ans=host_odc=host_cn=host_pu=host_pd=0xffffffffu;
        RPB5R=RPB7R=RPB9R=RPB13R=7; irq=initial_irq;
        display_spi_start();
        assert(irq==initial_irq);
        assert((host_lat&~pins)==other && (host_lat&pins)==(LCD_CS|LCD_RST));
        assert(host_tris==~pins && host_ans==~pins && host_odc==~pins);
        assert(host_cn==~pins && host_pu==~pins && host_pd==~pins);
        assert(!RPB5R && !RPB7R && !RPB9R && !RPB13R);
        assert(!DDPCONbits.JTAGEN && CFGCONbits.IOLOCK==1);
    }
    irq=true;
    // Validate all bytes at both ordinary and wrapped timer counts.
    for (unsigned wrap=0;wrap<2;++wrap) for(unsigned value=0;value<256;++value) {
        ticks=wrap ? 0xfffffff0u : 1000u;
        bits.clear(); edges_down=0; transfer=true;
        const uint32_t control=host_lat&~(LCD_MOSI|LCD_SCK);
        assert(display_spi_write((uint8_t)value));
        transfer=false;
        assert(bits.size()==8 && edges_down==8 && !(host_lat&LCD_SCK));
        assert((host_lat&~(LCD_MOSI|LCD_SCK))==control);
        for(unsigned b=0;b<8;++b) assert(bits[b]==!!(value&(0x80u>>b)));
    }
    std::puts("LCD transport passed: pins, GPIO isolation, mode0/MSB-first all256 bytes, clock wrap, interrupt preservation.");
}
