#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "BenchConfig.h"

static uint32_t feed(Follower *f, uint16_t x, uint16_t y, uint32_t now, unsigned count)
{
    while (count-- != 0) {
        uint16_t previous = f->pulse_us;
        now += 10;
        Follower_Sample(f, x, y, now);
        (void)Follower_Service(f, now);
        assert(abs((int)f->pulse_us - previous) <= f->config.slew_us_per_step);
        assert(f->pulse_us >= f->config.pulse_min_us);
        assert(f->pulse_us <= f->config.pulse_max_us);
        previous = f->pulse_us;
        (void)Follower_Service(f, now);
        assert(f->pulse_us == previous); /* Repeated poll cannot advance PWM. */
    }
    return now;
}

static uint32_t arm(Follower *f, const Follower_Config *c, uint32_t now)
{
    assert(Follower_Init(f, c, now));
    now = feed(f, c->x.center, c->y.center, now,
               (FOLLOWER_CAL_SETTLE_MS + FOLLOWER_CAL_WINDOW_MS) / 10 - 1);
    assert(f->state == FOLLOWER_CALIBRATING);
    now = feed(f, c->x.center, c->y.center, now, 1);
    assert(f->state == FOLLOWER_ACTIVE);
    assert(f->pulse_us == c->pulse_center_us);
    return now;
}

/* Physical readings independent of axis inversion in the implementation. */
static uint16_t adc(float unit, const Follower_Axis *axis)
{
    float span = unit < 0 ? axis->center - axis->min : axis->max - axis->center;
    return (uint16_t)lroundf(axis->center + unit * span / 512.0f);
}

static uint32_t position(Follower *f, float x, float y, uint32_t now, unsigned count)
{
    return feed(f, adc(x, &f->config.x), adc(y, &f->config.y), now, count);
}

static uint32_t polar(Follower *f, float deg, uint32_t now, unsigned count)
{
    float rad = deg * 0.0174532925199f;
    return position(f, 400.0f * cosf(rad), 400.0f * sinf(rad), now, count);
}

static uint32_t arc(Follower *f, float start, float step, unsigned count, uint32_t now)
{
    for (unsigned i = 1; i <= count; ++i) now = polar(f, start + step * i, now, 1);
    return now;
}

static void test_arming_and_noise(void)
{
    Follower f;
    const Follower_Config *c = &BenchFollowerConfig;
    uint32_t now = 0;
    assert(Follower_Init(&f, c, now));
    now = feed(&f, c->x.center, 1023, now, 150);
    assert(f.state == FOLLOWER_CALIBRATING); /* Both axes must be centered. */
    now = feed(&f, c->x.center, c->y.center, now, 30);
    now = feed(&f, 0, c->y.center, now, 1);
    now = feed(&f, c->x.center, c->y.center, now, FOLLOWER_CAL_WINDOW_MS / 10);
    assert(f.state == FOLLOWER_CALIBRATING);
    now = feed(&f, c->x.center, c->y.center, now, 1);
    assert(f.state == FOLLOWER_ACTIVE);
    for (unsigned i = 0; i < 1000; ++i) {
        now = feed(&f, c->x.center - 5 + i % 11,
                   c->y.center - 20 + i % 41, now, 1);
        assert(f.pulse_us == 1500 && f.motion == FOLLOWER_STOPPED);
    }
    now = polar(&f, 35, now, 100);
    assert(f.pulse_us == 1500); /* Outward push does not imply rotation. */
    uint16_t x = f.raw_x, y = f.raw_y;
    for (unsigned i = 0; i < 500; ++i) {
        now = feed(&f, x + (i % 3) - 1, y + ((i + 1) % 3) - 1, now, 1);
    }
    assert(f.pulse_us == 1500 && f.motion == FOLLOWER_STOPPED);
    (void)now;
}

static void test_reported_boot_offsets(void)
{
    const uint16_t centers[] = {240, 320, 350, 531};
    Follower f;
    for (unsigned i = 0; i < sizeof centers / sizeof centers[0]; ++i) {
        uint32_t now = 0;
        assert(Follower_Init(&f, &BenchFollowerConfig, now));
        now = feed(&f, 506, centers[i], now, 149);
        assert(f.state == FOLLOWER_CALIBRATING);
        now = feed(&f, 506, centers[i], now, 1);
        assert(f.state == FOLLOWER_ACTIVE && f.pulse_us == 1500);
        assert(f.config.x.center == 506 && f.config.y.center == centers[i]);
        now = polar(&f, 0, now, 60);
        now = arc(&f, 0, -2, 45, now);
        assert(f.motion == FOLLOWER_CW && f.pulse_us > 1550);
        now = feed(&f, 700, 700, now, 300); /* A held input must not be relearned. */
        assert(f.config.x.center == 506 && f.config.y.center == centers[i]);
        now = feed(&f, 506, centers[i], now, 100);
        assert(f.pulse_us == 1500);
        (void)now;
    }
}

static void test_calibration_stability(void)
{
    Follower f;
    uint32_t now = 0;
    assert(Follower_Init(&f, &BenchFollowerConfig, now));
    for (unsigned i = 0; i < 150; ++i) {
        now = feed(&f, i & 1 ? 504 : 508, i & 1 ? 340 : 360, now, 1);
    }
    assert(f.state == FOLLOWER_ACTIVE);
    assert(f.config.x.center == 506 && f.config.y.center == 350);

    /* Large changing input cannot become a learned center or enable pulses. */
    assert(Follower_Init(&f, &BenchFollowerConfig, 0));
    now = 0;
    for (unsigned i = 0; i < FOLLOWER_CAL_TIMEOUT_MS / 10 - 1; ++i) {
        now = feed(&f, 506, i & 1 ? 240 : 350, now, 1);
        assert(f.state == FOLLOWER_CALIBRATING);
    }
    now = feed(&f, 506, 350, now, 1);
    assert(f.state == FOLLOWER_FAULT && f.error == FOLLOWER_ERROR_CALIBRATION);
    now = feed(&f, 506, 350, now, 200);
    assert(f.state == FOLLOWER_FAULT);

    /* Reject a slow ramp even when each 1-second span fits the noise limit. */
    assert(Follower_Init(&f, &BenchFollowerConfig, 0));
    now = 0;
    for (unsigned i = 0; i < FOLLOWER_CAL_TIMEOUT_MS / 10; ++i) {
        now = feed(&f, 506, 300 + i / 5, now, 1);
        assert(f.state != FOLLOWER_ACTIVE);
    }
    assert(f.error == FOLLOWER_ERROR_CALIBRATION);
    for (unsigned axis = 0; axis < 2; ++axis) {
        assert(Follower_Init(&f, &BenchFollowerConfig, 0));
        now = feed(&f, axis ? 1023 : 506, axis ? 350 : 0, 0,
                   FOLLOWER_CAL_TIMEOUT_MS / 10);
        assert(f.state == FOLLOWER_FAULT && f.error == FOLLOWER_ERROR_CALIBRATION);
    }

    /* One timestamp cannot impersonate a full sample window. */
    assert(Follower_Init(&f, &BenchFollowerConfig, 0));
    now = feed(&f, 506, 350, 0, FOLLOWER_CAL_SETTLE_MS / 10);
    for (unsigned i = 0; i < 10000; ++i) Follower_Sample(&f, 506, 350, now);
    assert(f.state == FOLLOWER_CALIBRATING && f.cal_samples == 1);
    now = feed(&f, 506, 350, now, FOLLOWER_CAL_WINDOW_MS / 10);
    assert(f.state == FOLLOWER_ACTIVE);
    (void)now;
}

static void test_direction_gain_and_home(void)
{
    Follower f;
    for (unsigned reverse = 0; reverse < 2; ++reverse) {
        Follower_Config c = BenchFollowerConfig;
        c.reverse = reverse != 0;
        uint32_t now = arm(&f, &c, 0);
        now = polar(&f, 0, now, 60);
        now = arc(&f, 0, -2, 45, now); /* 90 degrees clockwise. */
        assert(f.motion == FOLLOWER_CW);
        now = polar(&f, -90, now, 60);
        assert(abs((int)f.pulse_us - (reverse ? 1375 : 1625)) <= 10);
        assert(f.motion == FOLLOWER_STOPPED);
        uint16_t held = f.pulse_us;
        now = polar(&f, -90, now, 300);
        assert(f.pulse_us == held);
        now = arc(&f, -90, 2, 45, now);
        assert(f.motion == FOLLOWER_CCW);
        now = polar(&f, 0, now, 60);
        assert(abs((int)f.pulse_us - 1500) <= 15);
        now = arc(&f, 0, 2, 45, now);
        now = polar(&f, 90, now, 60);
        assert(reverse ? f.pulse_us > 1550 : f.pulse_us < 1450);
        now = feed(&f, c.x.center, c.y.center, now, 100);
        assert(f.pulse_us == 1500 && !f.tracking && f.motion == FOLLOWER_STOPPED);
        now = polar(&f, -120, now, 100); /* New gesture establishes a new baseline. */
        assert(f.pulse_us == 1500);
        (void)now;
    }
}

static void test_limits_and_reversal(void)
{
    Follower f;
    uint32_t now = arm(&f, &BenchFollowerConfig, 0);
    now = polar(&f, 0, now, 60);
    now = arc(&f, 0, -2, 900, now); /* Five full turns, well beyond endpoint. */
    now = polar(&f, -1800, now, 100);
    assert(f.pulse_us == 1750);
    now = arc(&f, -1800, 2, 15, now);
    assert(f.motion == FOLLOWER_CCW && f.pulse_us < 1740);
    now = arc(&f, -1770, 2, 900, now);
    now = polar(&f, 30, now, 100);
    assert(f.pulse_us == 1250);
    now = arc(&f, 30, -2, 15, now);
    assert(f.motion == FOLLOWER_CW && f.pulse_us > 1260);

    Follower_Config slow = BenchFollowerConfig;
    slow.slew_us_per_step = 1;
    now = arm(&f, &slow, 0);
    now = polar(&f, 0, now, 60);
    now = arc(&f, 0, -5, 20, now);
    assert(f.target_pulse_us > f.pulse_us + 50); /* Deliberately pending movement. */
    bool reversed = false;
    for (unsigned i = 1; i <= 20; ++i) {
        uint16_t before = f.pulse_us;
        now = polar(&f, -100.0f + 5.0f * i, now, 1);
        if (f.motion == FOLLOWER_CCW) {
            reversed = true;
            assert(f.pulse_us <= before);
            assert(f.target_pulse_us <= before);
        }
    }
    assert(reversed);
    (void)now;
}

static void test_angle_wrap_reposition_and_axes(void)
{
    Follower f;
    uint32_t now = arm(&f, &BenchFollowerConfig, UINT32_MAX - 200);
    now = polar(&f, 170, now, 60);
    now = arc(&f, 170, 2, 10, now); /* Cross atan2's +180/-180 boundary. */
    now = polar(&f, 190, now, 60);
    assert(f.pulse_us < 1490 && f.pulse_us > 1460);
    now = arc(&f, 190, -2, 10, now);
    now = polar(&f, 170, now, 60);
    assert(abs((int)f.pulse_us - 1500) <= 12);

    now = arm(&f, &BenchFollowerConfig, 0);
    now = position(&f, 400, 0, now, 60);
    now = position(&f, -400, 0, now, 100); /* Straight through center, not a circle. */
    assert(f.pulse_us == 1500 && f.motion == FOLLOWER_STOPPED);
    now = position(&f, 0, 0, now, 100);
    now = position(&f, 30, 30, now, 100);
    assert(!f.tracking && f.pulse_us == 1500);

    for (unsigned mask = 0; mask < 4; ++mask) {
        Follower_Config c = BenchFollowerConfig;
        c.x.inverted = (mask & 1) != 0;
        c.y.inverted = (mask & 2) != 0;
        now = arm(&f, &c, 0);
        now = polar(&f, 0, now, 60);
        now = arc(&f, 0, -2, 45, now);
        now = polar(&f, -90, now, 60);
        assert(mask == 1 || mask == 2 ? f.pulse_us < 1450 : f.pulse_us > 1550);
    }
    (void)now;
}

static void test_faults_and_random_limits(void)
{
    Follower f;
    uint32_t now, rng = 1;
    assert(Follower_Init(&f, &BenchFollowerConfig, 0));
    assert(Follower_Service(&f, 100) == FOLLOWER_FAULT);
    Follower_Sample(&f, 506, 320, 101);
    assert(f.state == FOLLOWER_FAULT);
    now = arm(&f, &BenchFollowerConfig, 0);
    for (unsigned i = 0; i < 5000; ++i) {
        rng = rng * 1664525u + 1013904223u;
        now = feed(&f, (rng >> 16) & 1023, (rng >> 6) & 1023, now, 1);
    }
    assert(f.state == FOLLOWER_ACTIVE);
    assert(Follower_Service(&f, now + 99) == FOLLOWER_ACTIVE);
    assert(Follower_Service(&f, now + 100) == FOLLOWER_FAULT);
    now = arm(&f, &BenchFollowerConfig, 0);
    Follower_Sample(&f, 506, 320, now + 100);
    assert(f.state == FOLLOWER_FAULT); /* A resumed stream cannot hide a gap. */
    now = arm(&f, &BenchFollowerConfig, 0);
    Follower_Sample(&f, 1024, 320, now + 10);
    assert(f.state == FOLLOWER_FAULT);
    now = arm(&f, &BenchFollowerConfig, 0);
    Follower_Sample(&f, 506, 1024, now + 10);
    assert(f.state == FOLLOWER_FAULT);
    now = arm(&f, &BenchFollowerConfig, 0);
    Follower_Fault(&f);
    now = feed(&f, 506, 320, now, 200);
    assert(f.state == FOLLOWER_FAULT);
    (void)now;
}

static void test_invalid_calibration(void)
{
    Follower f;
    Follower_Config c;
    assert(!Follower_Init(0, &BenchFollowerConfig, 0));
    assert(!Follower_Init(&f, 0, 0));
#define REJECT(change) do { c = BenchFollowerConfig; change; assert(!Follower_Init(&f, &c, 0)); } while (0)
    REJECT(c.x.min = c.x.center);
    REJECT(c.y.max = c.y.center);
    REJECT(c.y.center = 1024);
    REJECT(c.x.min = 450; c.x.max = 550);
    REJECT(c.x.max = 1024);
    REJECT(c.deadband = 0);
    REJECT(c.deadband = c.track_radius);
    REJECT(c.track_radius = 513);
    REJECT(c.pulse_us_per_turn = 0);
    REJECT(c.pulse_us_per_turn = 2001);
    REJECT(c.pulse_min_us = 999);
    REJECT(c.pulse_max_us = 2001);
    REJECT(c.pulse_center_us = c.pulse_max_us);
    REJECT(c.slew_us_per_step = 0);
#undef REJECT
    assert(f.state == FOLLOWER_FAULT);
}

int main(void)
{
    test_arming_and_noise();
    test_reported_boot_offsets();
    test_calibration_stability();
    test_direction_gain_and_home();
    test_limits_and_reversal();
    test_angle_wrap_reposition_and_axes();
    test_faults_and_random_limits();
    test_invalid_calibration();
    puts("Angular follower: learned centers, stability/timeout, X/Y, CW/CCW, wrap, limits/reversal and faults pass.");
    return 0;
}
