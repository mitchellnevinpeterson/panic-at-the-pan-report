#include "EInkDisplay.h"
#include "BenchImages.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct { uint8_t command, first[8]; size_t length; } Transaction;
static Transaction transactions[256];
static size_t tx_count, writes, fail_write, plane_count[2];
static uint8_t planes[2][EINK_PLANE_BYTES];
static uint32_t clock_ms, refresh_started;
static EInkProfile emulated;
static bool refreshing, never_busy, stuck_busy, init_stuck, reset_high;
static unsigned int reset_lows, refresh_count, status_polls;
static uint8_t last_command;
static EInkFrame frame;

static bool write_spi(bool data, const uint8_t *bytes, size_t count)
{
    assert(count && bytes);
    if (++writes == fail_write) return false;
    if (!data) {
        assert(count == 1);
        last_command = bytes[0];
        if (last_command == 0x71 && emulated == EINK_UC8151D) { ++status_polls; return true; }
        assert(tx_count < sizeof transactions / sizeof transactions[0]);
        transactions[tx_count++] = (Transaction){ .command=last_command };
        if ((emulated == EINK_SSD1680 && last_command == 0x20) ||
            (emulated != EINK_SSD1680 && last_command == 0x12)) {
            refreshing = true;
            refresh_started = clock_ms;
            ++refresh_count;
        }
    } else {
        int plane = -1;
        Transaction *t = &transactions[tx_count-1];
        if (!t->length) memcpy(t->first, bytes, count < sizeof t->first ? count : sizeof t->first);
        t->length += count;
        if (last_command == (emulated == EINK_SSD1680 ? 0x24 : 0x10)) plane = 0;
        if (last_command == (emulated == EINK_SSD1680 ? 0x26 : 0x13)) plane = 1;
        if (plane >= 0) {
            assert(plane_count[plane] + count <= EINK_PLANE_BYTES);
            memcpy(planes[plane] + plane_count[plane], bytes, count);
            plane_count[plane] += count;
        }
    }
    return true;
}

static bool busy(void)
{
    bool active = init_stuck && EInk_Phase() == EINK_INITIALIZING;
    if (refreshing && !never_busy &&
        (stuck_busy || (uint32_t)(clock_ms-refresh_started) < 500u)) active = true;
    return active == (emulated == EINK_SSD1680);
}
static void reset(bool high) { reset_high=high; if (!high) ++reset_lows; }
static uint32_t now(void) { return clock_ms; }
static void delay(uint32_t ms) { clock_ms += ms; }
static const EInkPort port = { write_spi, reset, busy, now, delay };

static void fresh(EInkProfile selected)
{
    memset(transactions,0,sizeof transactions);
    memset(planes,0,sizeof planes);
    tx_count=writes=fail_write=plane_count[0]=plane_count[1]=0;
    clock_ms=0; refresh_started=0; refresh_count=reset_lows=status_polls=0;
    refreshing=never_busy=stuck_busy=init_stuck=false;
    reset_high=true; last_command=0; emulated=selected;
    assert(EInk_Bind(&port));
    EInk_Clear(&frame);
}

static Transaction *find_command(uint8_t command)
{
    for (size_t i=0;i<tx_count;++i) if (transactions[i].command==command) return &transactions[i];
    assert(!"expected command missing");
    return NULL;
}

static void assert_args(uint8_t command, const uint8_t *args, size_t count)
{
    Transaction *t=find_command(command);
    assert(t->length==count && memcmp(t->first,args,count)==0);
}

static EInkColor pixel(int x,int y)
{
    size_t offset=(295u-(unsigned)x)*16u+(unsigned)y/8u;
    uint8_t mask=(uint8_t)(128u >> (y%8));
    assert(!(frame.black[offset] & frame.red[offset] & mask));
    if (frame.black[offset] & mask) return EINK_BLACK;
    if (frame.red[offset] & mask) return EINK_RED;
    return EINK_WHITE;
}

static void test_pixels(void)
{
    EInk_Clear(&frame);
    assert(EInk_Pixel(&frame,295,0,EINK_BLACK)); assert(frame.black[0]==0x80);
    assert(EInk_Pixel(&frame,0,127,EINK_RED)); assert(frame.red[4735]==0x01);
    assert(EInk_Pixel(&frame,0,0,EINK_BLACK)); assert(frame.black[4720]==0x80);
    assert(EInk_Pixel(&frame,295,127,EINK_RED)); assert(frame.red[15]==0x01);
    assert(EInk_Pixel(&frame,295,0,EINK_RED)); assert(frame.black[0]==0 && frame.red[0]==0x80);
    assert(EInk_Pixel(&frame,295,0,EINK_WHITE)); assert(frame.red[0]==0);
    assert(!EInk_Pixel(NULL,0,0,EINK_BLACK));
    assert(!EInk_Pixel(&frame,-1,0,EINK_RED));
    assert(!EInk_Pixel(&frame,296,0,EINK_RED));
    assert(!EInk_Pixel(&frame,0,-1,EINK_RED));
    assert(!EInk_Pixel(&frame,0,128,EINK_RED));
    assert(!EInk_Pixel(&frame,0,0,(EInkColor)99));
}

static void test_profile(EInkProfile selected)
{
    fresh(selected);
    assert(EInk_Refresh(&frame)==EINK_NEEDS_PROFILE && writes==0);
    assert(EInk_Select(EINK_PROFILE_NONE)==EINK_BAD_ARGUMENT);
    assert(EInk_Select(selected)==EINK_OK && writes==0);
    assert(EInk_Pixel(&frame,295,0,EINK_BLACK));
    assert(EInk_Pixel(&frame,295,1,EINK_RED));
    assert(EInk_Pixel(&frame,0,127,EINK_RED));
    assert(EInk_Refresh(&frame)==EINK_OK && EInk_Phase()==EINK_IDLE);
    assert(refresh_count==1 && plane_count[0]==4736 && plane_count[1]==4736);
    /* Independent upstream drawPixel trace for BLACK at bit7, RED at bit6,
     * WHITE at bit5. Z10/Z13 swap layer bits as well as buffer names. */
    uint8_t upstream[2]={0xff, selected==EINK_SSD1680 ? 0 : 0xff};
    const uint8_t layers_old[]={2,1,0}, layers_ssd[]={1,2,0};
    for(unsigned int color=0;color<3;++color) {
        uint8_t layers=selected==EINK_SSD1680?layers_ssd[color]:layers_old[color];
        unsigned int black_index=selected==EINK_SSD1680?0:1;
        unsigned int red_index=1-black_index;
        uint8_t mask=(uint8_t)(0x80u>>color);
        if(layers&1) upstream[black_index]&=(uint8_t)~mask;
        else upstream[black_index]|=mask;
        bool color_inverted=selected!=EINK_SSD1680;
        bool color_bit=(layers&2)!=0;
        if(color_bit==color_inverted) upstream[red_index]&=(uint8_t)~mask;
        else upstream[red_index]|=mask;
    }
    assert(planes[0][0]==upstream[0] && planes[1][0]==upstream[1]);
    for (size_t i=0;i<EINK_PLANE_BYTES;++i) {
        uint8_t black=(uint8_t)(frame.black[i]^0xffu);
        uint8_t red=selected==EINK_SSD1680 ? frame.red[i] : (uint8_t)(frame.red[i]^0xffu);
        assert(planes[0][i]==black && planes[1][i]==red);
    }
    assert(reset_high && reset_lows==(selected==EINK_UC8151D ? 3u : 1u));
    if (selected==EINK_IL0373) {
        const uint8_t power[]={3,0,0x2b,0x2b,9};
        const uint8_t size[]={128,1,40};
        assert_args(0x01,power,sizeof power); assert_args(0x61,size,sizeof size);
        assert(transactions[tx_count-1].command==0x02);
    } else if (selected==EINK_UC8151D) {
        const uint8_t psr[]={0x0f,0x89}, size[]={128,1,40};
        assert_args(0x00,psr,sizeof psr); assert_args(0x61,size,sizeof size);
        assert(transactions[tx_count-1].command==0x07 && status_polls>0);
    } else {
        const uint8_t x[]={0,15}, y[]={0,0,0x27,1}, control[]={0xf4};
        assert_args(0x44,x,sizeof x); assert_args(0x45,y,sizeof y); assert_args(0x22,control,1);
        assert(transactions[tx_count-1].command==0x10);
        unsigned int origin_count=0;
        for(size_t i=0;i<tx_count;++i) if(transactions[i].command==0x4e) ++origin_count;
        assert(origin_count==2);
    }
    size_t old_writes=writes;
    assert(EInk_CooldownRemaining()==180000);
    assert(EInk_Select(selected==EINK_IL0373?EINK_SSD1680:EINK_IL0373)==EINK_OK);
    assert(EInk_Refresh(&frame)==EINK_COOLDOWN && writes==old_writes);
    clock_ms+=179999;
    assert(EInk_Refresh(&frame)==EINK_COOLDOWN && EInk_CooldownRemaining()==1);
    ++clock_ms;
    assert(EInk_CooldownRemaining()==0);
}

static void test_faults(void)
{
    for (EInkProfile p=EINK_IL0373;p<=EINK_SSD1680;p=(EInkProfile)(p+1)) {
        fresh(p); assert(EInk_Select(p)==EINK_OK); never_busy=true;
        assert(EInk_Refresh(&frame)==EINK_BUSY_NOT_ASSERTED);
        assert(EInk_Phase()==EINK_FAULT && !reset_high && refresh_count==1);
        size_t old_writes=writes;
        clock_ms+=300000;
        assert(EInk_Refresh(&frame)==EINK_FAULT_LATCHED && writes==old_writes);
        assert(EInk_Select(p)==EINK_FAULT_LATCHED);

        fresh(p); assert(EInk_Select(p)==EINK_OK); stuck_busy=true;
        assert(EInk_Refresh(&frame)==EINK_BUSY_TIMEOUT);
        assert((uint32_t)(clock_ms-refresh_started)>=45000 && !reset_high);

        fresh(p); assert(EInk_Select(p)==EINK_OK); init_stuck=true;
        assert(EInk_Refresh(&frame)==EINK_BUSY_TIMEOUT && refresh_count==0);
        assert(!reset_high && plane_count[0]==0);

        fresh(p); assert(EInk_Select(p)==EINK_OK); fail_write=30;
        assert(EInk_Refresh(&frame)==EINK_IO_ERROR && !reset_high && refresh_count==0);
    }
    fresh(EINK_IL0373); assert(EInk_Select(EINK_IL0373)==EINK_OK);
    fail_write=1;
    assert(EInk_Refresh(&frame)==EINK_IO_ERROR && plane_count[0]==0);
    fresh(EINK_IL0373); assert(EInk_Select(EINK_IL0373)==EINK_OK);
    clock_ms=UINT32_MAX-100;
    assert(EInk_Refresh(&frame)==EINK_OK && EInk_CooldownRemaining()==180000);
    clock_ms+=180000;
    assert(EInk_CooldownRemaining()==0);
    assert(EInk_Refresh(NULL)==EINK_BAD_ARGUMENT);
}

static void export_preview(const char *directory,const char *name)
{
    char path[1024];
    assert(snprintf(path,sizeof path,"%s/%s.ppm",directory,name)>0);
    FILE *f=fopen(path,"wb"); assert(f);
    fprintf(f,"P6\n296 128\n255\n");
    for (int y=0;y<128;++y) for(int x=0;x<296;++x) {
        EInkColor c=pixel(x,y);
        uint8_t rgb[3]={255,255,255};
        if(c==EINK_BLACK) memset(rgb,0,3);
        if(c==EINK_RED) {rgb[0]=200;rgb[1]=16;rgb[2]=46;}
        assert(fwrite(rgb,1,3,f)==3);
    }
    assert(fclose(f)==0);
}

static void test_images(const char *directory)
{
    BenchImages_Pattern(&frame);
    assert(pixel(0,0)==EINK_BLACK && pixel(295,127)==EINK_BLACK);
    assert(pixel(20,20)==EINK_BLACK && pixel(120,20)==EINK_RED && pixel(95,20)==EINK_WHITE);
    export_preview(directory,"test_pattern");
    BenchImages_Ingredients(&frame,0);
    for(size_t i=0;i<EINK_PLANE_BYTES;++i) assert(frame.black[i]==0 && frame.red[i]==0);
    for(unsigned int selected=0;selected<5;++selected) {
        BenchImages_Ingredients(&frame,1u<<selected);
        unsigned int black=0,red=0;
        for(int y=0;y<128;++y) for(int x=0;x<296;++x) {
            EInkColor c=pixel(x,y);
            if(c!=EINK_WHITE) {
                assert(x>=(int)(8+58*selected) && x<(int)(56+58*selected) && y>=40 && y<88);
                black+=c==EINK_BLACK; red+=c==EINK_RED;
            }
        }
        assert(black>10 && red>10);
    }
    BenchImages_Ingredients(&frame,31);
    export_preview(directory,"ingredients");
}

int main(int argc,char **argv)
{
    assert(argc==2);
    assert(EInk_Refresh(&frame)==EINK_NOT_BOUND);
    assert(!EInk_Bind(NULL));
    test_pixels();
    test_profile(EINK_IL0373); test_profile(EINK_UC8151D); test_profile(EINK_SSD1680);
    test_faults(); test_images(argv[1]);
    puts("E-ink host checks passed: controller sequences, planes, BUSY/SPI faults, cooldown, wrap and sprites.");
    return 0;
}
