#include <assert.h>
#include <limits.h>
#include <stdio.h>
#include <string.h>
#include "ScoreTimerDisplay.h"
#include "StatusDisplaySPI.h"

/* A chain model, not a mock of the renderer: first wire word lands in device7.
 * A transaction completes after multiple polls, so snapshot lifetime is exercised.
 */
static uint8_t chips[8][16];
static uint16_t wire_words[8], log_words[512][8];
static unsigned int transaction_count, polls_left;
static bool fail_bus;
static ScoreTimerDisplay_Config config = {true, {false, false}, {0, 0}, 1};

void StatusDisplaySPI_Init(void)
{
    memset(chips, 0xAA, sizeof chips);
    transaction_count = polls_left = 0;
    fail_bus = false;
}

bool StatusDisplaySPI_Start(const uint16_t *words, uint8_t count)
{
    assert(count == 8 && polls_left == 0 && transaction_count < 512);
    memcpy(wire_words, words, sizeof wire_words);
    memcpy(log_words[transaction_count++], words, sizeof wire_words);
    polls_left = 2;
    return true;
}

StatusDisplaySPI_State StatusDisplaySPI_Poll(void)
{
    unsigned int i;
    if (fail_bus) return STATUS_SPI_FAULT;
    if (!polls_left) return STATUS_SPI_IDLE;
    if (--polls_left) return STATUS_SPI_BUSY;
    for (i = 0; i < 8; ++i) {
        uint8_t reg = (uint8_t)(wire_words[i] >> 8);
        assert(reg > 0 && reg < 16);
        chips[7 - i][reg] = (uint8_t)wire_words[i];
    }
    return STATUS_SPI_IDLE;
}

static void settle(void)
{
    unsigned int limit = 1000;
    ScoreTimerDisplay_State status;
    do {
        status = ScoreTimerDisplay_Service();
        assert(status != SCORE_TIMER_FAULT && limit--);
    } while (status != SCORE_TIMER_IDLE);
}

static void initialize(void)
{
    assert(ScoreTimerDisplay_Init(&config));
    settle();
}

static void test_init_and_wire_order(void)
{
    static const uint16_t expected[] = {
        0x0C00,0x0F00,0x0900,0x0B07,0x0A01,
        0x0100,0x0200,0x0300,0x0400,0x0500,0x0600,0x0700,0x0800,0x0C01
    };
    uint32_t score[8] = {UINT32_C(0x80000000)}, timer[8] = {0};
    unsigned int t, chip, row;
    initialize();
    for (t = 0; t < 14; ++t)
        for (chip = 0; chip < 8; ++chip) assert(log_words[t][chip] == expected[t]);
    for (chip = 0; chip < 8; ++chip) {
        for (row = 1; row <= 8; ++row) assert(chips[chip][row] == 0);
        assert(chips[chip][9] == 0 && chips[chip][10] == 1);
        assert(chips[chip][11] == 7 && chips[chip][12] == 1 && chips[chip][15] == 0);
    }
    timer[7] = 1;
    transaction_count = 0;
    assert(ScoreTimerDisplay_SetFrame(DISPLAY_TOP, score));
    assert(ScoreTimerDisplay_SetFrame(DISPLAY_BOTTOM, timer));
    settle();
    assert(transaction_count == 13); /* 8 rows + 5 configuration re-asserts. */
    assert(log_words[0][7] == 0x0180); /* Nearest score chip is sent LAST. */
    assert(log_words[7][0] == 0x0801); /* Farthest timer chip is sent FIRST. */
    assert(chips[0][1] == 0x80 && chips[7][8] == 1);
    {
        static const uint16_t refresh[] = {0x0F00, 0x0900, 0x0B07, 0x0A01, 0x0C01};
        for (t = 0; t < 5; ++t)
            for (chip = 0; chip < 8; ++chip) assert(log_words[8 + t][chip] == refresh[t]);
    }
    /* A 5 V dip resets every MAX7219 to shutdown with defaults (dark). The next
     * frame must re-wake them without blanking (no 0x0C00, no row clears). */
    for (chip = 0; chip < 8; ++chip) { chips[chip][12] = 0; chips[chip][11] = 0; chips[chip][10] = 0; }
    timer[7] = 3;
    assert(ScoreTimerDisplay_SetFrame(DISPLAY_BOTTOM, timer));
    settle();
    for (chip = 0; chip < 8; ++chip)
        assert(chips[chip][12] == 1 && chips[chip][11] == 7 && chips[chip][10] == 1 && chips[chip][15] == 0);
    assert(chips[0][1] == 0x80 && chips[7][8] == 3);
    puts("PASS: blank-before-enable initialization, eight-chip wire order, config re-assert after a brownout");
}

static uint32_t panel_row(unsigned int panel, unsigned int y)
{
    uint32_t row = 0;
    unsigned int tile;
    for (tile = 0; tile < 4; ++tile) row = (row << 8) | chips[panel * 4 + tile][y + 1];
    return row;
}

static void test_numbers_and_independence(void)
{
    /* Readable golden pixels, independent of the packed heading constants. */
    static const char *headings[] = {
        "................................",
        "###.##.###.##..##...###.#.#.#.##",
        "#...#..#.#.#.#.#.....#..#.###.#.",
        "###.#..#.#.##..##....#..#.###.##",
        "..#.#..#.#.#.#.#.....#..#.#.#.#.",
        "###.##.###.#.#.##....#..#.#.#.##",
        "................................", "................................"
    };
    static const uint32_t one[] = {0, 0x00800000, 0x01800000,
        0x00800000, 0x00800000, 0x01C00000, 0, 0};
    uint8_t labels[4][16];
    uint32_t before[8], small[8], expected;
    unsigned int y, x;
    initialize();
    assert(ScoreTimerDisplay_ShowLabels());
    assert(ScoreTimerDisplay_SetScore(1));
    assert(ScoreTimerDisplay_SetTimerSeconds(65));
    settle();
    for (y = 0; y < 8; ++y) {
        assert(strlen(headings[y]) == 32);
        expected = 0;
        for (x = 0; x < 32; ++x) expected = (expected << 1) | (headings[y][x] == '#');
        assert(panel_row(DISPLAY_TOP, y) == expected);
        assert((panel_row(DISPLAY_BOTTOM, y) & 0xFFFFE000u) == one[y]);
        before[y] = panel_row(DISPLAY_BOTTOM, y);
    }
    memcpy(labels, chips, sizeof labels);
    assert(ScoreTimerDisplay_SetScore(-42));
    settle();
    for (y = 0; y < 8; ++y) {
        assert((panel_row(DISPLAY_BOTTOM, y) & 0x1FFFu) == (before[y] & 0x1FFFu));
        before[y] = panel_row(DISPLAY_BOTTOM, y);
    }
    assert(ScoreTimerDisplay_SetTimerSeconds(1));
    settle();
    for (y = 0; y < 8; ++y) {
        assert((panel_row(DISPLAY_BOTTOM, y) & 0xFFFFE000u) == (before[y] & 0xFFFFE000u));
        assert((panel_row(DISPLAY_BOTTOM, y) & 0x1FFFu) == (one[y] >> 16));
    }
    assert(ScoreTimerDisplay_SetScore(1));
    settle();
    for (y = 0; y < 8; ++y) small[y] = panel_row(DISPLAY_BOTTOM, y);
    assert(ScoreTimerDisplay_SetScore(-999));
    assert(ScoreTimerDisplay_SetTimerSeconds(999));
    settle();
    assert(ScoreTimerDisplay_SetScore(9999));
    settle();
    assert(!ScoreTimerDisplay_SetScore(10000));
    assert(!ScoreTimerDisplay_SetTimerSeconds(1000));
    settle();
    for (y = 0; y < 8; ++y) {
        assert((panel_row(DISPLAY_BOTTOM, y) & 0x2000u) == 0); /* Separator. */
    }
    assert(!ScoreTimerDisplay_SetScore(INT_MIN));
    assert(!ScoreTimerDisplay_SetTimerSeconds(UINT_MAX));
    settle();
    assert(ScoreTimerDisplay_SetScore(1));
    assert(ScoreTimerDisplay_SetTimerSeconds(1));
    settle();
    for (y = 0; y < 8; ++y) assert(panel_row(DISPLAY_BOTTOM, y) == small[y]);
    assert(memcmp(labels, chips, sizeof labels) == 0); /* Labels never change. */
    assert(!ScoreTimerDisplay_SetText(DISPLAY_TOP, "123456789"));
    assert(!ScoreTimerDisplay_SetText(DISPLAY_TOP, NULL));
    assert(!ScoreTimerDisplay_SetFrame((ScoreTimerDisplay_Panel)2, NULL));
    assert(ScoreTimerDisplay_SetText(DISPLAY_TOP, "TOP"));
    assert(ScoreTimerDisplay_ShowLabels());
    settle();
    assert(memcmp(labels, chips, sizeof labels) == 0);
    puts("PASS: 16x32 headings, bottom value isolation, seconds, bounds and clearing");
}

static void test_snapshot_and_fault(void)
{
    uint32_t old[8] = {UINT32_C(0x80000000)}, latest[8] = {0};
    unsigned int row, word;
    initialize();
    transaction_count = 0;
    assert(ScoreTimerDisplay_SetFrame(DISPLAY_TOP, old));
    assert(ScoreTimerDisplay_Service() == SCORE_TIMER_BUSY);
    latest[7] = 1;
    assert(ScoreTimerDisplay_SetFrame(DISPLAY_TOP, latest));
    settle();
    assert(transaction_count == 26); /* Two coherent snapshots (+5 re-asserts each), not mixed rows. */
    for (row = 0; row < 8; ++row) {
        for (word = 0; word < 8; ++word) {
            assert((log_words[row][word] & 0xFF) == ((row == 0 && word == 7) ? 0x80 : 0));
            assert((log_words[row+13][word] & 0xFF) == ((row == 7 && word == 4) ? 1 : 0));
        }
    }
    fail_bus = true;
    assert(ScoreTimerDisplay_Service() == SCORE_TIMER_FAULT);
    fail_bus = false;
    assert(ScoreTimerDisplay_Service() == SCORE_TIMER_FAULT);
    initialize(); /* Explicit reinitialization recovers; polling alone does not. */
    puts("PASS: immutable in-flight snapshot and latched transport fault");
}

static void test_welcome_banner(void)
{
    const char *message = "Welcome to Panic at the Pan";
    const int16_t offscreen[] = {32, -8, INT16_MAX, INT16_MIN};
    uint8_t before[8][16];
    uint32_t dashboard[2][8];
    char too_long[DISPLAY_BANNER_MAX_CHARS + 2];
    unsigned int i, panel, y;
    initialize();
    assert(ScoreTimerDisplay_SetBanner("W", 0));
    settle();
    /* Golden 2x-scaled W spans the strip boundary at global row8. */
    for (y = 0; y < 8; ++y) {
        assert(panel_row(DISPLAY_TOP, y) == (y >= 2 ? 0xCC000000u : 0));
        assert(panel_row(DISPLAY_BOTTOM, y) == (y < 2 ? 0xFC000000u :
                                               y < 4 ? 0xCC000000u : 0));
    }
    assert(ScoreTimerDisplay_SetBanner("W", 31));
    settle();
    assert(panel_row(DISPLAY_TOP, 2) == 1); /* Enters on rightmost column. */
    assert(ScoreTimerDisplay_SetBanner("W", -5));
    settle();
    assert(panel_row(DISPLAY_TOP, 2) == 0x80000000u); /* Exits at left edge. */
    for (i = 0; i < sizeof offscreen / sizeof offscreen[0]; ++i) {
        assert(ScoreTimerDisplay_SetBanner("W", offscreen[i]));
        settle();
        for (panel = 0; panel < 2; ++panel)
            for (y = 0; y < 8; ++y) assert(panel_row(panel, y) == 0);
    }
    /* The complete sentence is accepted; its final word reaches the viewport. */
    assert(ScoreTimerDisplay_SetBanner(message, (int16_t)(-((int)strlen(message) - 3) * 8)));
    settle();
    memcpy(before, chips, sizeof before);
    assert(ScoreTimerDisplay_SetBanner("Pan", 0));
    settle();
    assert(memcmp(before, chips, sizeof before) == 0);
    memset(too_long, 'W', sizeof too_long - 1);
    too_long[sizeof too_long - 1] = '\0';
    assert(!ScoreTimerDisplay_SetBanner(too_long, 0));
    assert(!ScoreTimerDisplay_SetBanner(NULL, 0));
    settle();
    assert(memcmp(before, chips, sizeof before) == 0);

    transaction_count = 0;
    /* Dashboard restoration must clear banner pixels in both numeric fields. */
    assert(ScoreTimerDisplay_ShowLabels());
    assert(ScoreTimerDisplay_SetScore(0));
    assert(ScoreTimerDisplay_SetTimerSeconds(60));
    settle();
    for (panel = 0; panel < 2; ++panel)
        for (y = 0; y < 8; ++y) dashboard[panel][y] = panel_row(panel, y);
    initialize();
    assert(ScoreTimerDisplay_ShowLabels());
    assert(ScoreTimerDisplay_SetScore(0));
    assert(ScoreTimerDisplay_SetTimerSeconds(60));
    settle();
    for (panel = 0; panel < 2; ++panel)
        for (y = 0; y < 8; ++y) assert(panel_row(panel, y) == dashboard[panel][y]);
    puts("PASS: full-height welcome text, edge clipping, final word and dashboard restoration");
}

static void test_strip_banner(void)
{
    static const uint32_t w[8] = {0, 0xCC000000u, 0xCC000000u, 0xCC000000u,
                                  0xFC000000u, 0xCC000000u, 0, 0};
    uint32_t bottom[8];
    char too_long[DISPLAY_BANNER_MAX_CHARS + 2];
    unsigned int y;
    initialize();
    assert(ScoreTimerDisplay_ShowLabels());
    assert(ScoreTimerDisplay_SetScore(7));
    assert(ScoreTimerDisplay_SetTimerSeconds(42));
    settle();
    for (y = 0; y < 8; ++y) bottom[y] = panel_row(DISPLAY_BOTTOM, y);
    /* 4x6 glyph doubled horizontally only: 8 px advance, rows 1..6. */
    assert(ScoreTimerDisplay_SetStripBanner(DISPLAY_TOP, "W", 0));
    settle();
    for (y = 0; y < 8; ++y) {
        assert(panel_row(DISPLAY_TOP, y) == w[y]);
        assert(panel_row(DISPLAY_BOTTOM, y) == bottom[y]); /* Other strip kept. */
    }
    assert(ScoreTimerDisplay_SetStripBanner(DISPLAY_TOP, "W", 31));
    settle();
    assert(panel_row(DISPLAY_TOP, 1) == 1); /* Enters on the rightmost column. */
    assert(ScoreTimerDisplay_SetStripBanner(DISPLAY_TOP, "W", -5));
    settle();
    assert(panel_row(DISPLAY_TOP, 1) == 0x80000000u); /* Exits at the left edge. */
    assert(ScoreTimerDisplay_SetStripBanner(DISPLAY_TOP, "WW", -8));
    settle();
    for (y = 0; y < 8; ++y) assert(panel_row(DISPLAY_TOP, y) == w[y]); /* Second char at x0. */
    assert(ScoreTimerDisplay_SetStripBanner(DISPLAY_TOP, "TIME'S UP. GAME OVER", 32));
    settle();
    for (y = 0; y < 8; ++y) assert(panel_row(DISPLAY_TOP, y) == 0);
    /* Bottom strip score text, centred, replaces the dashboard values. */
    assert(ScoreTimerDisplay_SetStripBanner(DISPLAY_BOTTOM, "W", 12));
    settle();
    for (y = 0; y < 8; ++y) {
        assert(panel_row(DISPLAY_BOTTOM, y) == w[y] >> 12);
        assert(panel_row(DISPLAY_TOP, y) == 0);
    }
    memset(too_long, 'W', sizeof too_long - 1);
    too_long[sizeof too_long - 1] = '\0';
    assert(!ScoreTimerDisplay_SetStripBanner(DISPLAY_TOP, too_long, 0));
    assert(!ScoreTimerDisplay_SetStripBanner(DISPLAY_TOP, NULL, 0));
    assert(!ScoreTimerDisplay_SetStripBanner((ScoreTimerDisplay_Panel)2, "W", 0));
    settle();
    for (y = 0; y < 8; ++y) assert(panel_row(DISPLAY_BOTTOM, y) == w[y] >> 12);
    puts("PASS: single-strip 8 px banner, clipping, other strip untouched");
}

static void test_orientation(void)
{
    static const uint8_t rows[] = {3, 2, 6, 7};
    static const uint8_t masks[] = {0x40, 0x04, 0x02, 0x20};
    uint32_t frame[8] = {0};
    unsigned int turn, chip, row;
    frame[2] = UINT32_C(1) << (31 - 17); /* Tile2, local x1/y2. */
    config.top_first = false;
    config.reverse_modules[DISPLAY_TOP] = true;
    for (turn = 0; turn < 4; ++turn) {
        config.rotation[DISPLAY_TOP] = (uint16_t)(turn * 90);
        initialize();
        assert(ScoreTimerDisplay_SetFrame(DISPLAY_TOP, frame));
        settle();
        for (chip = 0; chip < 8; ++chip)
            for (row = 1; row <= 8; ++row)
                assert(chips[chip][row] == ((chip == 5 && row == rows[turn]) ? masks[turn] : 0));
    }
    config.rotation[0] = 45;
    assert(!ScoreTimerDisplay_Init(&config));
    config.rotation[0] = 0;
    config.intensity = 16;
    assert(!ScoreTimerDisplay_Init(&config));
    puts("PASS: strip order, module order, four rotations and invalid configuration");
}

int main(void)
{
    test_init_and_wire_order();
    test_numbers_and_independence();
    test_snapshot_and_fault();
    test_welcome_banner();
    test_strip_banner();
    test_orientation();
    puts("All score/timer host checks passed (ASan + UBSan). No hardware test performed.");
    return 0;
}
