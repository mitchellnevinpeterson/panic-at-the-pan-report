/* Host-only compatibility for the unchanged FontStuff.c, which uses uint8_t
 * but no device registers. StatusDisplaySPI.c is NOT built against this header.
 */
#include <stdint.h>
