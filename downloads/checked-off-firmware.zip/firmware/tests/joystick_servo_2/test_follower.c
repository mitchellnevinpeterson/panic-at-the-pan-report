#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include "BenchConfig.h"

static uint32_t feed(Follower *f, uint16_t x, uint16_t y, uint32_t now, unsigned count)
{
    while (count--) {
        uint16_t previous = f->pulse_us;
        now += 10;
        Follower_Sample(f, x, y, now);
        (void)Follower_Service(f, now);
        assert(abs((int)f->pulse_us - previous) <= f->config.slew_us_per_step);
        assert(f->pulse_us >= f->config.pulse_min_us && f->pulse_us <= f->config.pulse_max_us);
        previous = f->pulse_us;
        (void)Follower_Service(f, now);
        assert(f->pulse_us == previous);
    }
    return now;
}

static uint32_t arm(Follower *f, const Follower_Config *c, uint16_t y, uint32_t now)
{
    assert(Follower_Init(f, c, now));
    now = feed(f, 506, y, now, 50);
    assert(f->state == FOLLOWER_WAIT_CENTER);
    now = feed(f, 506, y, now, 1);
    assert(f->state == FOLLOWER_ACTIVE && f->pulse_us == 1500);
    return now;
}

static void test_y_does_not_gate_or_drive(void)
{
    const uint16_t readings[] = {0, 240, 320, 350, 531, 1023};
    for (unsigned i = 0; i < sizeof readings / sizeof readings[0]; ++i) {
        Follower f;
        uint32_t now = arm(&f, &BenchFollowerConfig, readings[i], 0);
        now = feed(&f, 0, readings[i], now, 200);
        assert(f.pulse_us == 1250);
        now = feed(&f, 1023, readings[i], now, 200);
        assert(f.pulse_us == 1750);
        now = feed(&f, 506, readings[i], now, 200);
        assert(f.pulse_us == 1500);
        for (unsigned j = 0; j < 1000; ++j) {
            now = feed(&f, 506, j % 1024, now, 1);
            assert(f.state == FOLLOWER_ACTIVE && f.pulse_us == 1500);
        }
    }
}

static void test_position_hold_reverse_and_deadband(void)
{
    Follower f;
    Follower_Config c = BenchFollowerConfig;
    uint32_t now = arm(&f, &c, 350, UINT32_MAX - 200u);
    now = feed(&f, 256, 350, now, 200);
    assert(f.pulse_us == 1386);
    now = feed(&f, 768, 0, now, 200);
    assert(f.pulse_us == 1615);
    now = feed(&f, 768, 1023, now, 300);
    assert(f.pulse_us == 1615);
    for (unsigned x = 472; x <= 552; ++x) {
        now = feed(&f, x, 240, now, 60);
        assert(f.pulse_us == 1500);
    }
    c.reverse = true;
    now = arm(&f, &c, 240, 0);
    now = feed(&f, 0, 240, now, 200);
    assert(f.pulse_us == 1750);
    now = feed(&f, 1023, 240, now, 200);
    assert(f.pulse_us == 1250);
    (void)now;
}

static void test_startup_and_faults(void)
{
    Follower f;
    uint32_t now;
    assert(Follower_Init(&f, &BenchFollowerConfig, 0));
    now = feed(&f, 900, 350, 0, 200);
    assert(f.state == FOLLOWER_WAIT_CENTER);
    now = feed(&f, 506, 350, now, 30);
    now = feed(&f, 0, 350, now, 1);
    now = feed(&f, 506, 350, now, 50);
    assert(f.state == FOLLOWER_WAIT_CENTER);
    now = feed(&f, 506, 350, now, 1);
    assert(f.state == FOLLOWER_ACTIVE);
    assert(Follower_Service(&f, now + 100) == FOLLOWER_FAULT);
    Follower_Sample(&f, 506, 350, now + 101);
    assert(f.state == FOLLOWER_FAULT);
    now = arm(&f, &BenchFollowerConfig, 350, 0);
    Follower_Sample(&f, 506, 350, now + 100);
    assert(f.state == FOLLOWER_FAULT);
    now = arm(&f, &BenchFollowerConfig, 350, 0);
    Follower_Sample(&f, 1024, 350, now + 10);
    assert(f.state == FOLLOWER_FAULT);
    assert(Follower_Init(&f, &BenchFollowerConfig, 0));
    assert(Follower_Service(&f, 100) == FOLLOWER_FAULT);
    Follower_Config bad = BenchFollowerConfig;
    bad.deadband = 512;
    assert(!Follower_Init(&f, &bad, 0));
}

int main(void)
{
    test_y_does_not_gate_or_drive();
    test_position_hold_reverse_and_deadband();
    test_startup_and_faults();
    puts("Checkpoint X follower: Y-independent arming/control, position, hold/home, limits, slew, wrap and faults pass.");
    return 0;
}
