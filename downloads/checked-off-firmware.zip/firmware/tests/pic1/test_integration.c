/* Real six services + production GameIO + real two-endpoint protocol.
 * Only PIC registers/display raster transport are replaced at the boundary.
 */
#include "GameIO.h"
#include "Pic1Board.h"
#include "PeerLink.h"
#include "PeerUart.h"
#include "GameSM.h"
#include "IngredientSM.h"
#include "HeatSM.h"
#include "StirSM.h"
#include "ScoreSM.h"
#include "PanDisplaySM.h"
#include "ScoreTimerDisplay.h"
#include "ES_Framework.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
extern volatile uint32_t GameTreatRequests;
extern volatile bool GameLinkSynchronized,GameAdapterFault;
extern volatile uint16_t GameHeatPermille;
static uint32_t now, cooking_start;
static ES_Event_t queue[6][64];
static unsigned rd[6],wr[6];
static uint32_t timer_due[16];
static bool timer_on[16];
static const unsigned timer_owner[10]={5,5,5,5,3,3,2,0,0,5};
static ES_Event_t (*const run[6])(ES_Event_t)={RunPanDisplaySM,RunScoreSM,RunStirSM,RunHeatSM,RunIngredientSM,RunGameSM};
static PeerLink sensor;
static uint8_t to_sensor[4096],to_controller[4096];
static size_t ns,nc;
static bool disconnected, lamp, banner;
static bool audio_enabled;
static bool board_init_fails, display_init_fails;
static unsigned stop_calls;
static int32_t score;
static uint32_t seconds;
static uint32_t peer_clock(void *u) { (void)u; return now; }
static bool sensor_send(const uint8_t *b,size_t n,void *u) {
    (void)u; if(disconnected) return true;
    assert(nc+n<=sizeof to_controller); memcpy(to_controller+nc,b,n); nc+=n; return true;
}
bool PeerUart_Send(const uint8_t *b,size_t n,void *u) {
    (void)u; if(disconnected) return true;
    assert(ns+n<=sizeof to_sensor); memcpy(to_sensor+ns,b,n); ns+=n; return true;
}
static void sensor_event(const PeerEvent *e,void *u) {
    (void)u;
    if(e->kind==PEER_CONTROL) { lamp=e->control.lamp; audio_enabled=e->control.audio_enabled; }
    if(e->kind==PEER_STATUS&&!e->synchronized) lamp=false;
}
void PeerUart_Init(void) {
    PeerLink_Init(&sensor,PEER_SENSOR,1,peer_clock,sensor_send,sensor_event,0);
}
void PeerUart_Service(PeerLink *p) {
    if(!disconnected) for(size_t i=0;i<ns;++i) PeerLink_ReceiveByte(&sensor,to_sensor[i]);
    ns=0; PeerLink_Service(&sensor);
    if(!disconnected) for(size_t i=0;i<nc;++i) PeerLink_ReceiveByte(p,to_controller[i]);
    nc=0;
}
bool Pic1Board_Init(void) { return !board_init_fails; }
uint32_t Pic1Board_Now(void) { return now; }
bool Pic1Board_Service(void) { return true; }
void Pic1Board_Stop(void) { ++stop_calls; }
bool Pic1Board_Motor(uint32_t angle,bool home,bool enabled) {
    (void)angle; (void)home;
#ifndef TEST_CONFIGURED
    assert(!enabled);
#else
    (void)enabled;
#endif
    return true;
}
const EInkAsyncPort *Pic1Board_EInkPort(void) { return 0; }
bool ScoreTimerDisplay_Init(const ScoreTimerDisplay_Config *c) { assert(c); return !display_init_fails; }
ScoreTimerDisplay_State ScoreTimerDisplay_Service(void) { return SCORE_TIMER_IDLE; }
bool ScoreTimerDisplay_SetBanner(const char *t,int16_t x) { assert(t); (void)x; banner=true; return true; }
bool ScoreTimerDisplay_ShowLabels(void) { banner=false; return true; }
bool ScoreTimerDisplay_SetScore(int32_t v) { assert(!banner); score=v; return true; }
bool ScoreTimerDisplay_SetTimerSeconds(uint32_t v) { assert(!banner); seconds=v; return true; }
bool ES_PostToService(uint8_t s,ES_Event_t e) {
    assert(s<6 && wr[s]-rd[s]<64); queue[s][wr[s]++%64]=e; return true;
}
ES_TimerReturn_t ES_Timer_InitTimer(uint8_t t,uint16_t delay) {
    assert(t<16&&delay); timer_due[t]=now+delay; timer_on[t]=true; return ES_Timer_OK;
}
ES_TimerReturn_t ES_Timer_StopTimer(uint8_t t) { assert(t<16); timer_on[t]=false; return ES_Timer_OK; }
uint16_t ES_Timer_GetTime(void) { return (uint16_t)now; }
static void drain(void) {
    unsigned budget=1000;
    while(budget--) {
        int s; for(s=5;s>=0;--s) if(wr[s]!=rd[s]) break;
        if(s<0) return;
        ES_Event_t e=run[s](queue[s][rd[s]++%64]);
        assert(e.EventType==ES_NO_EVENT || (GameAdapterFault&&e.EventType==ES_ERROR));
    }
    assert(!"queue did not drain");
}
static void advance(unsigned duration) {
    while(duration--) {
        ++now;
        for(unsigned t=0;t<10;++t) if(timer_on[t]&&(int32_t)(now-timer_due[t])>=0) {
            timer_on[t]=false; ES_PostToService((uint8_t)timer_owner[t],(ES_Event_t){ES_TIMEOUT,t});
        }
        (void)GameIO_Service(); drain();
    }
}
static void press(uint8_t id) {
    assert(PeerLink_IsSynchronized(&sensor));
    assert(PeerLink_SendInput(&sensor,id,now)); advance(100);
}
static void start_round(void) {
    assert(QueryGameSM()==GAME_WELCOME && banner);
    press(7); assert(QueryGameSM()==GAME_DISH_INTRO && banner);
    while(QueryGameSM()==GAME_DISH_INTRO) advance(1);
    cooking_start=now;
    assert(QueryGameSM()==GAME_COOKING_EARLY&&!banner&&seconds==60&&score==0);
    advance(400); assert(GameLinkSynchronized);
}
int main(int argc, char **argv) {
    if (argc > 1) {
        board_init_fails = !strcmp(argv[1],"board-init-fails");
        display_init_fails = !strcmp(argv[1],"display-init-fails");
        assert(board_init_fails || display_init_fails);
        assert(!GameIO_Init());
        /* Match app/main's failure path before the peer clock is bound. */
        GameIO_Stop();
        GameIO_Stop();
        assert(stop_calls == 2 && ns == 0);
        puts("PIC1 initialization failure safely stops local outputs without an uninitialized peer call");
        return 0;
    }
    assert(GameIO_Init());
    assert(InitPanDisplaySM(0)&&InitScoreSM(1)&&InitStirSM(2)&&InitHeatSM(3)&&InitIngredientSM(4)&&InitGameSM(5));
    drain(); advance(1200); assert(GameLinkSynchronized&&!GameAdapterFault);
    start_round();
    press(0); press(0); assert(IngredientSM_AddedMask()==1);
#ifdef TEST_CONFIGURED
    assert(ScoreSM_Value()==10);
    for(unsigned i=0;i<20;++i) {
        assert(PeerLink_SendSensor(&sensor,300,true,now)); advance(100);
    }
    assert(GameHeatPermille==500&&audio_enabled&&ScoreSM_Value()>20);
    for(unsigned i=0;i<21;++i) {
        assert(GameIO_Joystick(i*10000u,false,true,now)); advance(50);
    }
    assert(StirSM_ElapsedMs()==1000);
    advance(400); assert(!audio_enabled); /* No stale range can sustain sizzle. */
#else
    assert(ScoreSM_Value()==0);
#endif
    press(5); assert(QueryGameSM()==GAME_COOKING_EARLY&&!lamp);
    while(now-cooking_start<30050) {
        if((now-cooking_start)%5000==0) press(0);
        else advance(1);
    }
    advance(100); assert(QueryGameSM()==GAME_COOKING_FINISHABLE&&lamp);
    press(5); assert(QueryGameSM()==GAME_OVER&&GameTreatRequests==1&&!lamp);
#ifdef TEST_CONFIGURED
    assert(ScoreSM_Value()>100&&!audio_enabled); /* Final stir drains after End. */
#endif
    uint32_t frozen=seconds; advance(1000); assert(seconds==frozen);
    while(QueryGameSM()!=GAME_WELCOME) advance(1);
    advance(400); start_round();
    while(QueryGameSM()!=GAME_TIMED_OUT) advance(1);
    assert(GameTreatRequests==1&&seconds==40);
    while(QueryGameSM()!=GAME_WELCOME) advance(1);
    advance(400); start_round();
    while(QueryGameSM()!=GAME_OVER) {
        if((now-cooking_start)%5000==0) press(0);
        else advance(1);
    }
    assert(GameTreatRequests==2&&seconds==0);
    while(QueryGameSM()!=GAME_WELCOME) advance(1);
    advance(400); start_round();
    disconnected=true; advance(1300);
    assert(GameAdapterFault&&QueryGameSM()==GAME_FAULT&&!lamp);
    puts("PIC1 six-service/peer integration tests passed");
}
