#include "EInkAsync.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static uint32_t now, refresh_at;
static bool level=true, simulate_refresh=true, fail_bus, in_bus, tick_on_read, mono_mode;
static unsigned commands[256], data_bytes[256], bytes, plane_bytes[2], command;
static uint8_t first_data[256];
static EInkFrame frame;
static uint32_t time_ms(void) { return tick_on_read ? now++ : now; }
static void reset(bool high) { (void)high; }
static bool busy(void) {
    if (simulate_refresh && refresh_at && now-refresh_at<30) return false;
    return level;
}
static bool start(bool data,const uint8_t *p,size_t count) {
    assert(!in_bus && p && count>0 && count<=32);
    in_bus=true; bytes+=(unsigned)count;
    if (!data) {
        assert(count==1); command=*p; ++commands[command];
        if (command==0x12) refresh_at=now;
    } else if (command==0x10 || command==0x13) {
        unsigned plane=command==0x13;
        for (size_t i=0;i<count;++i) {
            unsigned at=plane_bytes[plane]+(unsigned)i;
            uint8_t ink=mono_mode?(uint8_t)(frame.black[at]|frame.red[at]):(plane?frame.red:frame.black)[at];
            assert(p[i]==(uint8_t)~ink);
        }
        plane_bytes[plane]+=(unsigned)count;
    }
    if (data) {
        if (!data_bytes[command]) first_data[command]=*p;
        data_bytes[command]+=(unsigned)count;
    }
    return true;
}
static EInkBusState poll(void) {
    if (fail_bus) return EINK_BUS_FAULT;
    in_bus=false; return EINK_BUS_IDLE;
}
static void setup_mode(uint32_t at, bool mono) {
    now=at; mono_mode=mono; refresh_at=0; level=true; simulate_refresh=true; fail_bus=false; in_bus=false;
    tick_on_read=false;
    bytes=command=0; memset(commands,0,sizeof commands); memset(plane_bytes,0,sizeof plane_bytes);
    memset(data_bytes,0,sizeof data_bytes); memset(first_data,0,sizeof first_data);
    memset(&frame,0,sizeof frame); frame.black[3]=0x53; frame.red[19]=0x94;
    const EInkAsyncPort io={start,poll,reset,busy,time_ms};
    assert(mono ? EInkAsync_InitFastMono(&io,1) : EInkAsync_Init(&io));
}
static void setup(uint32_t at) { setup_mode(at,false); }
static void complete(void) {
    for (unsigned i=0;i<100000 && EInkAsync_IsBusy();++i) { ++now; (void)EInkAsync_Service(); }
    assert(!EInkAsync_IsBusy());
}
int main(void) {
    setup(0);
    assert(!EInkAsync_CanStart() && !EInkAsync_Start(&frame));
    now=179999; assert(!EInkAsync_CanStart());
    now=180000; assert(EInkAsync_Start(&frame));
    complete(); assert(EInkAsync_Result()==EINK_OK);
    assert(plane_bytes[0]==EINK_PLANE_BYTES && plane_bytes[1]==EINK_PLANE_BYTES);
    assert(commands[0x12]==1 && commands[0x02]==1 && bytes>2*EINK_PLANE_BYTES);
    assert(commands[0x20]==0 && first_data[0x00]==0xcf); /* Default keeps factory waveform. */
    assert(!EInkAsync_Start(&frame)); now+=180000; assert(EInkAsync_CanStart());
    setup(UINT32_MAX-90000u); now+=180000u; assert(EInkAsync_Start(&frame)); complete();
    assert(EInkAsync_Result()==EINK_OK);
    setup(0); now=180000; simulate_refresh=false; assert(EInkAsync_Start(&frame)); complete();
    assert(EInkAsync_Result()==EINK_BUSY_NOT_ASSERTED && !EInkAsync_CanStart());
    setup(0); now=180000; level=false; assert(EInkAsync_Start(&frame)); complete();
    assert(EInkAsync_Result()==EINK_BUSY_TIMEOUT);
    setup(0); now=180000; fail_bus=true; assert(EInkAsync_Start(&frame)); complete();
    assert(EInkAsync_Result()==EINK_IO_ERROR);
    /* A millisecond boundary between clock reads must not turn a normal
     * DELAY into a BUSY timeout. Let time advance inside each service call. */
    setup(0); now=180000; tick_on_read=true; assert(EInkAsync_Start(&frame));
    for(unsigned i=0;i<100000 && EInkAsync_IsBusy();++i) (void)EInkAsync_Service();
    assert(!EInkAsync_IsBusy() && EInkAsync_Result()==EINK_OK);
    /* Fast mono: register LUTs, black/white panel mode, and black|red in both
     * RAMs, so the red byte in frame.red[19] must arrive black. */
    setup_mode(0,true); now=1; assert(EInkAsync_Start(&frame)); complete();
    assert(EInkAsync_Result()==EINK_OK && first_data[0x00]==0x3f && first_data[0x30]==0x3c);
    for (unsigned c=0x20;c<=0x24;++c) assert(commands[c]==1 && data_bytes[c]==42);
    assert(first_data[0x21]==0x40 && first_data[0x24]==0x80);
    assert(plane_bytes[0]==EINK_PLANE_BYTES && plane_bytes[1]==EINK_PLANE_BYTES);
    assert(commands[0x12]==1 && commands[0x02]==1);
    puts("PIC1 asynchronous e-ink tests passed");
}
