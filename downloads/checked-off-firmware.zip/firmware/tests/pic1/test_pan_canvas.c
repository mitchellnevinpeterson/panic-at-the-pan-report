#include "PanCanvas.h"
#include "BenchImages.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static EInkFrame actual, expected;
int main(void)
{
    for (unsigned mask=0;mask<32;++mask) {
        memset(&actual,0xff,sizeof actual);
        assert(PanCanvas_Start(&actual,PAN_VIEW,(uint8_t)mask));
        unsigned calls=0;
        while (!PanCanvas_Service()) assert(++calls<1000);
        assert(calls>400); /* Composition is sliced, not one blocking draw. */
        BenchImages_Ingredients(&expected,mask);
        /* Stub font draws nothing, so compare the exact approved icon pixels. */
        assert(memcmp(&actual,&expected,sizeof actual)==0);
    }
    assert(PanCanvas_Start(&actual,PAN_ATTRACT,0));
    while(!PanCanvas_Service()) { }
    BenchImages_Ingredients(&expected,31);
    assert(memcmp(&actual,&expected,sizeof actual)==0);
    assert(!PanCanvas_Start(0,PAN_VIEW,0));
    puts("PIC1 incremental pan renderer matches all approved ingredient masks");
}
