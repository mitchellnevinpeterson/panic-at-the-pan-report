/* Synthetic integration fixture only. Never linked into a firmware image. */
#include "GameConfig.h"
const GameTuning_t GameTuning = {
    .configured=true, .distance_min_mm=100, .distance_max_mm=500,
    .heat_target={500,500,500,500,500}, .optimal_stir_ms={1000,1000,1000,1000,1000},
    .heat_sample_max_age_ms=300, .burn_transfer_rule=GAME_BURN_TRANSFER_RESET,
    .stir_debounce_ms=200, .stir_motion_threshold_mdeg=1000, .stir_home_angle_mdeg=0,
    .stir_score_rule=GAME_STIR_SCORE_LINEAR_RELATIVE_ERROR, .animation_period_ms=50,
    .recipe_mask=31, .points_right=10, .penalty_wrong=10, .penalty_burn=20,
    .heat_weight=10, .stir_weight=100, .allow_negative_score=false
};
