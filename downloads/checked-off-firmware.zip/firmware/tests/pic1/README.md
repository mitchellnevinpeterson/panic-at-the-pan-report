# PIC1 integration tests

Run `make -C firmware/tests/pic1 test`. All suites use strict warnings and ASan/UBSan.

- The asynchronous e-ink suite checks IL0373 command order, both full planes, BUSY assertion/completion, I/O failures, cooldown and clock wrap.
- The incremental renderer matches all 32 ingredient masks against the preserved bench renderer and enforces sliced composition.
- The integration harness runs all six real services, production GameIO and both real protocol endpoints. Only physical register/display boundaries are mocked; integrated e-ink is disabled in this harness.
- The default production tuning verifies zero score and disabled heat/motor. A separate synthetic fixture verifies heat/audio, stale-range mute, observed stir time and final score after End. No test values enter firmware builds.
- Lifecycle scenarios cover Start/dish/countdown, duplicate ingredients, early/eligible Finish, natural completion, idle timeout, treat request count, reset and link-loss fault. Separate process runs verify board/display initialization failure safely stops without accessing an uninitialized link.

These tests do not establish UART service margin, ADC stability, physical servo travel, echo timing under audio interrupts, display wiring or supply behavior.
