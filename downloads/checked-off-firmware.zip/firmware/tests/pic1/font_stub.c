#include <stdint.h>
uint8_t getFontLine(unsigned char c,int line) { (void)c; (void)line; return 0; }
