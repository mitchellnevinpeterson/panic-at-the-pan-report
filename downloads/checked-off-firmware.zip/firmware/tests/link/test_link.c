#include "PeerLink.h"
#include "PeerUart.h" /* header-only RX ring */
#include <assert.h>
#include <stdio.h>
#include <string.h>
typedef struct Endpoint Endpoint;
struct Endpoint { PeerLink link; Endpoint *peer; uint8_t wire[8192]; size_t length; unsigned inputs,sensors,statuses,controls; uint32_t event_time; uint8_t input_id; uint16_t mm; bool valid; PeerControl control; bool drop; };
static uint32_t ms;
static uint32_t clock_fn(void *v) { (void)v; return ms; }
static bool send_fn(const uint8_t *b,size_t n,void *v) {
    Endpoint *e=v;
    if(e->drop) return true;
    assert(e->length+n<=sizeof e->wire); memcpy(e->wire+e->length,b,n); e->length+=n; return true;
}
static void event_fn(const PeerEvent *event,void *v) {
    Endpoint *e=v;
    if(event->kind==PEER_INPUT) { ++e->inputs; e->event_time=event->time_ms; e->input_id=event->input_id; }
    if(event->kind==PEER_SENSOR_READING) { ++e->sensors; e->mm=event->distance_mm; e->valid=event->valid; }
    if(event->kind==PEER_CONTROL) { e->control=event->control; ++e->controls; }
    if(event->kind==PEER_STATUS) ++e->statuses;
}
static void deliver(Endpoint *e) { size_t i,n=e->length; e->length=0; for(i=0;i<n;i++) PeerLink_ReceiveByte(&e->peer->link,e->wire[i]); }
static void init(Endpoint *a,Endpoint *b) {
    memset(a,0,sizeof *a); memset(b,0,sizeof *b); a->peer=b; b->peer=a;
    PeerLink_Init(&a->link,PEER_CONTROLLER,1,clock_fn,send_fn,event_fn,a);
    PeerLink_Init(&b->link,PEER_SENSOR,1,clock_fn,send_fn,event_fn,b);
}
static void run(Endpoint *a,Endpoint *b,unsigned ticks) {
    while(ticks--) { PeerLink_Service(&a->link); PeerLink_Service(&b->link); deliver(a); deliver(b); ++ms; }
}
static void synchronized(Endpoint *a,Endpoint *b) { run(a,b,850); assert(PeerLink_IsSynchronized(&a->link)); assert(PeerLink_IsSynchronized(&b->link)); }
static bool same(const PeerControl *x,const PeerControl *y) {
    return x->lamp==y->lamp&&x->audio_zone==y->audio_zone&&x->audio_enabled==y->audio_enabled&&
        x->start_lamp==y->start_lamp&&x->lcd_mode==y->lcd_mode&&x->burnt==y->burnt&&
        x->burn_seq==y->burn_seq&&x->target_cm==y->target_cm;
}
/* Every heartbeat control field reaches the sensor alone, without crosstalk. */
static void control_round_trip(Endpoint *a,Endpoint *b) {
    static const PeerControl cases[]={
        {0}, {.lamp=true}, {.audio_enabled=true}, {.start_lamp=true}, {.burnt=true},
        {.lcd_mode=1}, {.lcd_mode=2}, {.burn_seq=1}, {.burn_seq=2}, {.burn_seq=3},
        {.audio_zone=1}, {.audio_zone=2}, {.audio_zone=3}, {.target_cm=1}, {.target_cm=14},
        {.target_cm=128}, {.target_cm=255},
        {.lamp=true,.audio_zone=3,.audio_enabled=true,.start_lamp=true,.lcd_mode=2,.burnt=true,.burn_seq=3,.target_cm=255},
        {.audio_zone=2,.audio_enabled=true,.lcd_mode=2,.burn_seq=1,.target_cm=24}
    };
    for(unsigned i=0;i<sizeof cases/sizeof cases[0];i++) {
        PeerLink_SendControl(&a->link,&cases[i]); run(a,b,120);
        assert(same(&b->control,&cases[i]));
    }
    /* Out-of-range values become the safe default instead of aliasing. */
    PeerControl bad={.lcd_mode=3,.audio_zone=4,.burn_seq=5,.target_cm=32},want={.burn_seq=1,.target_cm=32};
    PeerLink_SendControl(&a->link,&bad); run(a,b,120); assert(same(&b->control,&want));
}
static void ring_tests(void) {
    static PeerRxRing r; uint8_t v; unsigned i;
    memset(&r,0,sizeof r);
    assert(!PeerRxRing_Pop(&r,&v));
    for(i=0;i<255;i++) assert(PeerRxRing_Push(&r,(uint8_t)i));
    assert(!PeerRxRing_Push(&r,0xaa)); /* one slot stays empty: full at 255 */
    for(i=0;i<255;i++) { assert(PeerRxRing_Pop(&r,&v)); assert(v==(uint8_t)i); }
    assert(!PeerRxRing_Pop(&r,&v));
    /* Index wrap across many cycles preserves FIFO order. */
    for(i=0;i<1000;i++) { assert(PeerRxRing_Push(&r,(uint8_t)(i*7))); assert(PeerRxRing_Push(&r,(uint8_t)(i*7+1)));
        assert(PeerRxRing_Pop(&r,&v)&&v==(uint8_t)(i*7)); assert(PeerRxRing_Pop(&r,&v)&&v==(uint8_t)(i*7+1)); }
    for(i=0;i<100;i++) assert(PeerRxRing_Push(&r,(uint8_t)i));
    PeerRxRing_Flush(&r); assert(!PeerRxRing_Pop(&r,&v));
    assert(PeerRxRing_Push(&r,0x7e)&&PeerRxRing_Pop(&r,&v)&&v==0x7e);
}
int main(void) {
    Endpoint a,b; PeerControl control={.lamp=true,.audio_zone=3,.audio_enabled=true,.start_lamp=true}; unsigned i;
    ring_tests();
    ms=0; init(&a,&b);
    run(&a,&b,300); assert(!PeerLink_IsSynchronized(&a.link));
    synchronized(&a,&b);
    PeerLink_SendControl(&a.link,&control); run(&a,&b,120);
    assert(b.control.start_lamp&&b.control.lamp&&b.control.audio_enabled&&b.control.audio_zone==3);
    PeerControl start_only={.start_lamp=true};
    PeerLink_SendControl(&a.link,&start_only); run(&a,&b,120);
    assert(b.control.start_lamp && !b.control.lamp && !b.control.audio_enabled);
    PeerControl finish_only={.lamp=true};
    PeerLink_SendControl(&a.link,&finish_only); run(&a,&b,120);
    assert(!b.control.start_lamp && b.control.lamp && !b.control.audio_enabled);
    control_round_trip(&a,&b);
    assert(PeerLink_SendSensor(&b.link,250,true,ms)); deliver(&b); assert(a.sensors==1&&a.mm==250&&a.valid);
    assert(PeerLink_SendSensor(&b.link,0,false,ms)); deliver(&b); assert(a.sensors==2&&!a.valid);
    a.sensors=1;
    /* CRC damage is rejected; exact event retries once with original timestamp. */
    assert(PeerLink_SendInput(&b.link,5,ms)); uint32_t detected=ms;
    PeerLink_Service(&b.link); assert(b.length>10); b.wire[5]^=0x10; deliver(&b);
    assert(a.inputs==0); run(&a,&b,90); assert(a.inputs==1); assert((int32_t)(a.event_time-detected)<=0);
    /* Lost ACK causes replay, never duplicate input. */
    a.drop=true; assert(PeerLink_SendInput(&b.link,7,ms)); run(&a,&b,200);
    assert(a.inputs==2); a.drop=false; run(&a,&b,100); assert(a.inputs==2); assert(b.link.count==0);
    /* Delivery delay does not replace the physical detection timestamp. */
    detected=ms; assert(PeerLink_SendInput(&b.link,5,detected)); PeerLink_Service(&b.link);
    ms+=200; deliver(&b); assert(a.inputs==3); assert((int32_t)(a.event_time-detected)<=0);
    run(&a,&b,100);
    for(uint8_t id=8;id<=12;id++) {
        unsigned count=a.inputs;
        assert(PeerLink_SendInput(&b.link,id,ms)); run(&a,&b,100);
        assert(a.inputs==count+1);
    }
    /* Pan flip (id 6) is delivered end-to-end like any other input. */
    { unsigned count=a.inputs; assert(PeerLink_SendInput(&b.link,6,ms)); run(&a,&b,100);
      assert(a.inputs==count+1&&a.input_id==6); }
    assert(!PeerLink_SendInput(&b.link,13,ms));
    a.inputs=3; /* Preserve subsequent epoch/replay assertions. */
    /* Queued old-round input is flushed by authoritative generation change. */
    assert(PeerLink_SendInput(&b.link,0,ms)); PeerLink_ResetSession(&a.link);
    PeerLink_Service(&a.link); deliver(&a); assert(b.link.count==0);
    run(&a,&b,200); assert(a.inputs==3);
    assert(!PeerLink_SendInput(&b.link,5,detected)); /* pre-session edge cannot be relabelled */
    /* Overflow is a visible safe fault, not silent event loss. */
    for(i=0;i<PEER_EVENT_CAPACITY;i++) assert(PeerLink_SendInput(&b.link,1,ms));
    assert(!PeerLink_SendInput(&b.link,1,ms)); assert(!PeerLink_IsSynchronized(&b.link)); assert(b.link.faults>0);
    PeerLink_SendControl(&a.link,&control); PeerLink_Service(&a.link); deliver(&a);
    assert(!b.link.synchronized); /* buffered live heartbeat must not conceal fault */
    synchronized(&a,&b);
    PeerControl live={.lamp=true,.audio_enabled=true,.audio_zone=2,.lcd_mode=2,.burnt=true,.burn_seq=2,.target_cm=40};
    PeerLink_SendControl(&a.link,&live); run(&a,&b,120); assert(same(&b.control,&live));
    a.drop=b.drop=true; run(&a,&b,650); assert(!a.link.synchronized&&!b.link.synchronized);
    /* Unsynchronized heartbeats carry no actuation or LCD state, even when
       the controller already holds a live control word. */
    a.drop=b.drop=false; PeerLink_SendControl(&a.link,&live);
    { unsigned n=b.controls; PeerLink_Service(&a.link); assert(!a.link.synchronized); deliver(&a); assert(b.controls==n+1); }
    assert(!b.control.lamp&&!b.control.audio_enabled&&!b.control.start_lamp&&!b.control.burnt&&
           b.control.lcd_mode==0&&b.control.burn_seq==0&&b.control.target_cm==0);
    assert(!PeerLink_SendInput(&b.link,7,ms)); a.drop=b.drop=false; synchronized(&a,&b);
    /* Controller reset reusing epoch cannot consume pre-reset pending input. */
    assert(PeerLink_SendInput(&b.link,5,ms));
    PeerLink_Init(&a.link,PEER_CONTROLLER,b.link.epoch,clock_fn,send_fn,event_fn,&a);
    unsigned prior=a.inputs; run(&a,&b,300); assert(a.inputs==prior&&!a.link.synchronized);
    synchronized(&a,&b); assert(a.inputs==prior);
    /* Sensor reboot initiates a new controller epoch and fresh release gate. */
    uint32_t epoch=a.link.epoch;
    PeerLink_Init(&b.link,PEER_SENSOR,1,clock_fn,send_fn,event_fn,&b);
    synchronized(&a,&b); assert(a.link.epoch!=epoch);
    /* Bounded malformed frames recover at delimiter. */
    for(i=0;i<1000;i++) PeerLink_ReceiveByte(&a.link,0x11);
    PeerLink_ReceiveByte(&a.link,0x7e); run(&a,&b,200); assert(a.link.synchronized);
    ms=0xffffff00u; init(&a,&b); synchronized(&a,&b);
    assert(PeerLink_SendInput(&b.link,2,ms)); run(&a,&b,100); assert(a.inputs==1);
    puts("link tests: control fields, flip id 6, RX ring, sync, CRC, retries, dedup, timestamp, epoch, overflow, disconnect, both reboots, framing, clock wrap passed");
    return 0;
}
