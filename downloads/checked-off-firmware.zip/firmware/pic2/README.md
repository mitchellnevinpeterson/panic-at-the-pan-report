# PIC2 sensor, switches and audio firmware

This separate image implements the confirmed Combined wiring without the teammate display program. Nothing in `PIC32-Current-Code/` is changed. Its `src/DeviceConfig.c` supplies the existing 40 MHz SYSCLK / 20 MHz PBCLK configuration; `src/sizzle.h` supplies the teammates' original procedural frying engine. `Audio.c` adapts their PWM/sample setup to explicit PIC1 commands and hard mute. No startup sound or distance-to-heat threshold is embedded in PIC2.

Build and portable tests:

```sh
make -C firmware/pic2 all test
make -C firmware/pic2 all DEBUG=1
make -C firmware/pic2 test SANITIZE="-fsanitize=address,undefined -fno-omit-frame-pointer"
```

The compiler is resolved as `xc32-gcc` / `xc32-bin2hex` on PATH; validation used XC32 6.00 and PIC32MX_DFP 1.7.380. The newest installed device pack is selected by default. Override `XC32_CC`, `XC32_BIN2HEX`, `DFP_ROOT`, and `BUILD_DIR` as necessary. Output is `firmware/build/pic2/panic_pic2.{elf,hex,map}`. `DEBUG=1` selects SNAP reservations and `firmware/build/pic2_debug/`. These commands do not program hardware. UART1 debug is disabled, leaving optional TX11/RX15 unconfigured.

| Function | PIC2 wiring / resources |
| --- | --- |
| Ultrasonic | TRIG6/RB2, ECHO7/RB3; free-running Core timer at 20 MHz, no counter reset |
| Audio | OC1/RB15/pin 26; Timer 2 PR255, 78.125 kHz PWM; Timer 3 PR1599, 12.5 kHz sample interrupt |
| MCP23S17 | SPI1 mode 0, 100 kHz; SS2/RA0, MOSI3/RA1, MISO22/RB11, SCK25/RB14 |
| Link | UART2 TX21/RB10, RX17/RB8, 115200 8N1 requested (actual 116279,+0.94% at 20 MHz); cross TX/RX |
| Buttons | Active-low GPA0–4 ingredients, GPA5 Finish, GPA7 Start; GPA6 ignored |
| Finish lamp | GPB0; commanded only by PIC1, off without synchronized healthy link |

MCP startup first writes address 0x05 to normalize either surviving BANK layout, writes IOCON0, then OLATB0 **before** IODIRB0xFE. It initializes pull-ups, polarity and interrupt registers, and verifies IOCON, direction and output latch. Runtime SPI advances one byte per foreground pass with a 1 ms deadline. Direction/latch health reads alternate every 50 ms; a failed transfer or bad readback mutes audio, stops health acknowledgements, and retries initialization after 1 s. If the physical SPI connection fails while the lamp is on, software cannot force an unreachable MCP output low; this is a hardware fail-safe limitation, not an acknowledged safe lamp state.

Inputs are sampled approximately every 2 ms. A button must first be released for 20 ms, then pressed for 20 ms. Held startup, restart and reconnect buttons produce no edge until released. The event records the first sample of the accepted low interval; transport and debounce completion do not replace its timestamp. Optional GPA6 never generates an event. Inputs are rearmed on every link epoch/status transition.

Ultrasonic polling uses a 12 us trigger, 30 ms edge deadlines and at least 100 ms between completed attempts. Stuck-high, missing, too-short and out-of-range echoes produce invalid snapshots. Reads are nonblocking, including runtime SPI and UART. GPIO polling is not capture hardware: audio ISR/foreground latency affects pulse measurement and must be measured on the assembled system. No physical timing, amplifier/filter, power-load or sensor calibration claim is made by host tests.

PIC1 owns all heat/scoring policy, lamp eligibility and audio zone selection (0 silent, 1 low, 2 right, 3 high). Invalid/stale range policy must be applied by PIC1. PIC2 outputs are muted before synchronization, after 600 ms peer loss, and on local input peripheral fault. An unrecoverable main-loop hang is not covered by a hardware watchdog in this image; watchdog enable/reset validation remains an explicit hardware validation item.

The host suite covers release gating, bounce, held reset, disabled flip, source-edge timestamps, timer wrap, successful echoes, high/missing echoes, and the shared link faults below. XC32 builds use `-Wall -Wextra -Werror`. No flashing was performed.
