#ifndef PANIC_GAME_BENCH_IO_H
#define PANIC_GAME_BENCH_IO_H
#include <stdbool.h>
bool GameBenchIO_Init(void);
bool CheckGameBenchIO(void);
#endif
