# GameSM + IngredientSM + ScoreSM bench

Tests the game lifecycle, ingredients and score with the 16×32 status display and UART keyboard. **Bench rule: +10 per new ingredient, maximum 50.** Finish LED, treat, Heat, Stir and Pan outputs remain terminal stubs.

## Build and run

1. Keep the [score/timer wiring](../score_timer/README.md#wiring--power-off-first): DATA **PIC22**, SCK **PIC26**, SS **PIC24**, through 74ACT244. Two strips only; keep SNAP wiring.
2. In MPLAB, select **GameSMBench / default**, PIC32MX170F256B, XC32 6.00 and your connected SNAP. Reload the VS Code window if the project is missing. Build, then program; Continue if debugging stops at `main`.
3. Open the Lab UART terminal at **115200, 8N1**, no flow control. USB-UART TX → PIC15/RB6; USB-UART RX ← PIC16/RB7; common GND, 3.3 V logic.

| Key | Effect |
|---|---|
| `b` | Start from Welcome; scroll the dish, then show SCORE/TIME and 0/60 |
| `a` | Report activity while cooking; renew the 20-second idle deadline |
| `f` | Report activity; finish only after 30 seconds elapsed |
| `1`–`5` | Add that ingredient once per round; every press also reports activity |

No Enter required. Tap keys; each received byte is a new simulated press. Physical button debounce/release detection and the second-PIC link remain TODO.

The terminal prints `[RX]` plus the key when it receives and queues a recognized key. This confirms receipt, not that the current state accepts the action. The `a` key only extends the idle deadline while cooking. Ingredient keys also add points on their first accepted press.

```sh
make -C firmware game-sm
make -C firmware game-sm-test
```

Make produces `firmware/build/game_sm/game_sm_bench.hex`; MPLAB produces its separate image under `out/GameSMBench/`. Builds do not flash. Debug build: `make -C firmware/bench/game_sm DEBUG=1`.

XC32 Make release/debug builds, five host suites and the MPLAB-generated default build pass. The new dish intro and scoring behavior still need a board test.

## Ingredient quick check

1. In Welcome, press `1`: `[Ingredient 1] LOCKED - ignored`.
2. Press `b`, wait for the dish scroll to finish, then press `1`: `[Ingredient 1] ADDED`, `Score: 10`, and 10 on the display.
3. Press `1` again: `DUPLICATE - ignored`; idle timing still renews. Press `2`: score becomes 20.
4. End the game: ingredients lock. After the result hold and a fresh `b`, ingredient `1` can be added again.

Internal IDs are 0–4; keyboard keys and terminal labels are 1–5. The displayed dish is chicken fried rice. Recipe membership, wrong-ingredient penalties and heat/stir scoring remain TODO. `GameBenchConfig.h` explicitly selects the temporary +10 rule.

## Expected sequence

- Welcome scrolls continuously until `b`.
- Scroll `YOUR DISH TODAY: chicken fried rice` once (about 15.6 seconds). Ingredient keys stay Locked; repeated Start and Finish do not interrupt the intro. Game and idle timers are off.
- Only after the scroll finishes, show score 0 / time 60 and unlock ingredients. The 30-second Finish gate and 20-second idle deadline start here.
- Countdown runs **60 → 0**. Tap `a` or an ingredient key about every 10 seconds to stay active.
- At 30 seconds elapsed, terminal prints **Finish LED ON**. Press `f`, or keep active until 0: one stub treat request, hold values 10 seconds, then Welcome.
- No activity for 20 seconds: timeout, no treat, hold values 5 seconds, then Welcome.
- `b` during cooking/results is ignored. Pan `GAME OVER`/`TIMEOUT` is a terminal stub; status strips hold the final numbers.

A press at the exact idle deadline is too late. At the 60-second game deadline, normal completion wins a simultaneous idle timeout. A Finish detected before 30 seconds cannot become valid by waiting in the queue.

`FirmwareStatus` and `GameBenchState` are debugger watches. UART or detected SPI faults stop the bench; reset after correcting the cause. MAX7219 has no acknowledgement, so software cannot detect an unplugged panel. Board testing is still required.

## Integration boundary

`GAME_SM_BENCH` registers ScoreSM at priority 0, IngredientSM at 1 and GameSM at 2, each with a 32-event queue. Bind all three port adapters before framework initialization; full-game hardware adapters remain TODO. No vendor library is modified.

`GameSM_PostInput(type, detected_ms, generation)` owns timestamped queue metadata. Inputs older than 1000 ms or from another lifecycle generation are rejected. The bench timestamps UART reads on the main PIC; translating second-PIC timestamps is pending. `now_ms` must be sampled frequently enough to extend the course 16-bit clock without losing a wrap.

IngredientSM keeps a five-bit accepted mask and owned message tickets. Its live GameSM gate rejects stale, pre-Start or expired input even when End is still queued. Queue/output failure stops the bench; accepted ingredients are not retried.

ScoreSM accepts only trusted IngredientSM publications. Earned points queued before End can drain during results using the retained playing-round ID. Reset clears internal score without rendering over either banner.

Keyboard timestamps mean foreground read time, not exact UART arrival time. A byte near a timing boundary may be processed after that boundary; host tests verify the state machine using already-captured timestamps.
