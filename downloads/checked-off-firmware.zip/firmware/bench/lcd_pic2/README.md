# LCDPIC2Bench — ST7789 on the wired PIC2 pins

**Hardware checkpoint — November 17, 2026:** user confirmed this bench works
on the connected LCD with MOSI14/SCK16/CS18/DC23/RST24. Preserve these pins.
This confirms the standalone display test, not combined game operation.

Standalone screen test. Reuses the teammate's 320×240 PAN HEAT layout and colors
with a dedicated software SPI connection. The original `PIC32-LCD` targets keep
their original wiring unless compiled with `PIC2_LCD_SOFTSPI`.

| LCD label | PIC2 physical DIP pin |
|---|---:|
| SDA / MOSI | 14 / RB5 |
| SCL / SCK | 16 / RB7 |
| CS / SS | 18 / RB9; 10 kΩ pull-up to 3.3 V |
| DC | 23 / RB12 |
| RES / RST | 24 / RB13 |
| VCC | Regulated 3.3 V with enough backlight current |
| GND | Common GND |

Direct 3.3 V logic; no buffer. Leave A/B/PUSH/K0 unconnected. Follow the actual
board's BLK instructions if the backlight is dark. Do not connect an unknown
backlight power terminal directly to a PIC GPIO.

## Program and observe

1. In the **project root** VS Code workspace, select **LCDPIC2Bench**, configuration **default**.
2. Connect SNAP to **PIC2**, power the target and LCD, then select **Make and Program Device**.
3. Allow about 15 seconds for the initial drawing. Expect **PAN HEAT**, snowflake/flame icons and a heat bar.
4. The bar sweeps automatically through **NOT ENOUGH → JUST RIGHT → TOO MUCH**, then back.
5. Optional UART: adapter RX → PIC2 pin11, GND → common GND; **115200 baud**, 8N1.

Expected UART banner: `LCDPIC2Bench: MOSI14 SCK16 CS18 DC23 RST24`.
The bench sends status every five seconds after initialization. No keyboard input is required.
"Commands sent" means software completed writes; the LCD has no acknowledgment in this connection.

The distance sweep is simulated (400→50→400 mm). Ultrasonic does not control this test.
It does not run the game, UART2 link, button events, audio or encoders. The volume UI is hidden.
PIC1 does not need reprogramming; a game image on PIC1 may report link loss while PIC2 runs this bench.

On boot, audio pin26 and ultrasonic TRIG6 are held LOW. MCP initialization uses its
existing SPI1 wiring and clears both lamp latches; it then leaves SS HIGH.
If MCP initialization fails, the LCD test continues and UART reports that lamp state is unverified.
If the proposed GPB1 Start lamp circuit is fitted, its input/gate pulldowns
keep the lamp off while GPB1 is an input.

## Build and check

```sh
make -C firmware lcd-pic2
make -C firmware/bench/lcd_pic2 DEBUG=1 all
make -C firmware lcd-pic2-test
```

Production HEX: `firmware/build/lcd_pic2/lcd_pic2.hex`.
MPLAB fileset: `.vscode/LCDPIC2Bench.mplab.json`.
Both default user.cmake hooks retain the known SNAP boot-reservation fix.

The host test executes the actual software SPI transport against register models.
It checks pin isolation, idle levels, all 256 byte patterns, eight rising/falling
clock edges, MSB-first order, Core timer wrap and interrupt-state preservation.
It does not validate an attached LCD, electrical timing or display orientation.

Independent verifier: no blocking pin, transport, clock or build-configuration
issues found. Production and Debug XC32 builds and the host transport test passed;
the original LCD_Bench and Display_Dual targets also rebuilt successfully.

## Integration boundary

This bench uses blocking drawing and reset delays. At <=250 kHz, a full RGB565
screen fill takes at least 4.9 seconds before CPU overhead. Do not insert these
calls directly into the full game loop: chunk drawing and schedule it around
UART/MCP service and ultrasonic measurements first. No Timer2/Timer3 use is added.
Gameplay integration remains pending the user's rules.
