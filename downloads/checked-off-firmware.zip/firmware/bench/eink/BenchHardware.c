#include <xc.h>
#include <cp0defs.h>
#include <stdarg.h>
#include <stdio.h>
#include "BenchHardware.h"

#define CS_MASK (1u << 0)     /* RA0 / physical 2 */
#define MOSI_MASK (1u << 1)   /* RA1 / physical 3 */
#define DC_MASK (1u << 4)     /* RB4 / physical 11 */
#define RESET_MASK (1u << 9)  /* RB9 / physical 18 */
#define BUSY_MASK (1u << 12)  /* RB12 / physical 23 */
#define SCK_MASK (1u << 14)   /* RB14 / physical 25 */
#define STATUS_SS_MASK (1u << 13)
#define STATUS_DATA_CLOCK_MASK ((1u << 11) | (1u << 15))
#define CORE_TICKS_PER_MS 20000u

static uint32_t core_last, clock_ms;
static bool spi_failed;

uint32_t BenchHardware_Milliseconds(void)
{
    uint32_t delta = (uint32_t)(_CP0_GET_COUNT() - core_last);
    uint32_t whole = delta / CORE_TICKS_PER_MS;
    core_last += whole * CORE_TICKS_PER_MS;
    clock_ms += whole;
    return clock_ms;
}

static void delay_ms(uint32_t duration)
{
    uint32_t start = BenchHardware_Milliseconds();
    while ((uint32_t)(BenchHardware_Milliseconds() - start) < duration) { }
}

static void reset_pin(bool high)
{
    if (high) LATBSET = RESET_MASK;
    else LATBCLR = RESET_MASK;
}

static bool busy_level(void) { return (PORTB & BUSY_MASK) != 0; }

static bool spi_write(bool data, const uint8_t *bytes, size_t count)
{
    size_t i;
    if (spi_failed || !bytes || !count) return false;
    if (data) LATBSET = DC_MASK;
    else LATBCLR = DC_MASK;
    LATACLR = CS_MASK;
    for (i = 0; i < count; ++i) {
        uint32_t start = BenchHardware_Milliseconds();
        uint32_t shifted_at = _CP0_GET_COUNT();
        SPI1BUF = bytes[i];
        /* SPITBE alone does not mean the final clock edge has occurred. */
        for (;;) {
            if (SPI1STATbits.SPIROV ||
                (uint32_t)(BenchHardware_Milliseconds() - start) >= 5u) goto fault;
            if ((uint32_t)(_CP0_GET_COUNT() - shifted_at) >= 20u &&
                SPI1STATbits.SPITBE && !SPI1STATbits.SPIBUSY) break;
        }
        if (SPI1STATbits.SPIRBF) (void)SPI1BUF;
    }
    LATASET = CS_MASK;
    return true;
fault:
    SPI1CONCLR = _SPI1CON_ON_MASK;
    LATASET = CS_MASK;
    spi_failed = true;
    return false;
}

static const EInkPort port = { spi_write, reset_pin, busy_level,
                               BenchHardware_Milliseconds, delay_ms };
const EInkPort *BenchHardware_Port(void) { return &port; }

void BenchHardware_Init(void)
{
    __builtin_disable_interrupts();
    core_last = _CP0_GET_COUNT();
    clock_ms = 0;
    spi_failed = false;
    SYSKEY = 0; SYSKEY = 0xaa996655; SYSKEY = 0x556699aa;
    CFGCONbits.IOLOCK = 0;
    DDPCONbits.JTAGEN = 0;
    PMD5bits.SPI1MD = 0;
    PMD5bits.U1MD = 0;
    SPI1CON = 0; SPI1CON2 = 0;
    RPA0R = 0; RPA1R = 3; /* Manual SS and SDO1. */
    RPB4R = 0; RPB9R = 0; RPB12R = 0;
    RPA4R = 0; RPB5R = 0; /* Keep attached spoon/treat control lines LOW. */
    RPB11R = 0; RPB13R = 0; RPB15R = 0; /* Idle status display GPIO, not SPI2. */
    RPB7R = 1; U1RXR = 1; /* Working Lab UART1: TX p16, RX p15. */
    CFGCONbits.IOLOCK = 1;
    SYSKEY = 0;

    ANSELACLR = CS_MASK | MOSI_MASK;
    ANSELBCLR = DC_MASK | RESET_MASK | BUSY_MASK | SCK_MASK;
    ODCACLR = CS_MASK | MOSI_MASK;
    ODCBCLR = DC_MASK | RESET_MASK | SCK_MASK | (1u << 7);
    LATASET = CS_MASK;
    LATACLR = MOSI_MASK;
    LATBSET = RESET_MASK | (1u << 7);
    LATBCLR = DC_MASK | SCK_MASK;
    TRISACLR = CS_MASK | MOSI_MASK;
    TRISBCLR = DC_MASK | RESET_MASK | SCK_MASK | (1u << 7);
    TRISBSET = BUSY_MASK | (1u << 6);
    CNPUBCLR = BUSY_MASK;
    CNPDBSET = BUSY_MASK; /* Unplugged BUSY settles LOW, not random noise. */
    /* Other connected benches are inactive; do not leave buffer inputs floating. */
    ANSELBCLR = STATUS_SS_MASK | STATUS_DATA_CLOCK_MASK | (1u << 5);
    ODCACLR = (1u << 4);
    ODCBCLR = STATUS_SS_MASK | STATUS_DATA_CLOCK_MASK | (1u << 5);
    LATACLR = (1u << 4);
    LATBCLR = STATUS_DATA_CLOCK_MASK | (1u << 5);
    LATBSET = STATUS_SS_MASK;
    TRISACLR = (1u << 4);
    TRISBCLR = STATUS_SS_MASK | STATUS_DATA_CLOCK_MASK | (1u << 5);
    SPI1BRG = 99; /* PBCLK 20 MHz / 2 / 100 = 100 kHz. */
    (void)SPI1BUF;
    SPI1STATCLR = _SPI1STAT_SPIROV_MASK;
    SPI1CON = _SPI1CON_MSTEN_MASK | _SPI1CON_CKE_MASK | _SPI1CON_DISSDI_MASK;
    SPI1CONSET = _SPI1CON_ON_MASK; /* Mode 0, 8-bit, no hardware SS or MISO. */

    U1MODE = 0; U1STA = 0;
    U1BRG = 42; /* Same 115200, 8N1 terminal as Lab; actual 116279 baud. */
    U1MODE = _U1MODE_BRGH_MASK;
    U1STASET = _U1STA_UTXEN_MASK | _U1STA_URXEN_MASK;
    U1MODESET = _U1MODE_ON_MASK;
    delay_ms(100);
}

void BenchHardware_DrainInput(void)
{
    U1STACLR = _U1STA_OERR_MASK;
    while (U1STAbits.URXDA) (void)U1RXREG;
}

int BenchHardware_ReadKey(void)
{
    if (U1STAbits.OERR || (U1STAbits.URXDA && (U1STAbits.FERR || U1STAbits.PERR))) {
        BenchHardware_DrainInput();
        return -2;
    }
    return U1STAbits.URXDA ? (int)(U1RXREG & 0xffu) : -1;
}

void BenchHardware_Print(const char *format, ...)
{
    char text[256];
    size_t i;
    va_list args;
    va_start(args, format);
    (void)vsnprintf(text, sizeof text, format, args);
    va_end(args);
    for (i = 0; text[i]; ++i) {
        uint32_t start = BenchHardware_Milliseconds();
        while (U1STAbits.UTXBF) {
            if ((uint32_t)(BenchHardware_Milliseconds() - start) >= 10u) return;
        }
        U1TXREG = (uint8_t)text[i];
    }
}
