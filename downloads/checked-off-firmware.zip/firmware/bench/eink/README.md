# E-ink bench test

Standalone **PIC1 / PIC32MX170F256B** test for the 296x128 Adafruit #1028 tri-color display. Uses SPI1 and the existing Lab UART1. It waits for commands after startup; it does not run GameSM, servo motion or the status display.

## Wire and build

Follow the [reviewed wiring table](../../../hardware/docs/pan_eink_bench.md): **VIN=3.3 V**, common GND, SCK=25, MOSI=3, ECS=2, D/C=11, RST=18, BUSY=23. Direct PIC logic; no 74ACT244. Leave the display's 3V3 output unconnected. Confirm supply headroom and measure both rails during refresh.

1. In MPLAB select **EInkBench / default**, PIC32MX170F256B, XC32 v6.00, DFP 1.7.380 and the connected SNAP. Reload the VS Code window if the new project is absent.
2. Build, then program PIC1. For debugging, Continue after stopping at `main`. Keep [user.cmake](../../../cmake/EInkBench/default/user.cmake), which fixes the known SNAP boot-reservation overlap.
3. Open the existing UART terminal at **115200, 8N1, no flow control**. PIC15/RB6=RX, PIC16/RB7=TX, 3.3 V logic/common ground. Press `?` to print the menu; no Enter needed.
4. Select a controller profile, then send one image key. **IL0373 / Z10 worked in the user's test on this old lab board**; exact controller markings remain unconfirmed.

Terminal build alternative: `make -C firmware eink`. Output: `firmware/build/eink/eink_bench.hex`. MPLAB uses its separate `out/EInkBench/default.elf` image. Neither build command flashes the PIC.

## UART commands

| Key | Action |
|---|---|
| `1` | Select IL0373 / ThinkInk Z10, tested on this lab board |
| `2` | Select UC8151D / Z13, 2022 revision |
| `3` | Select SSD1680 / Z94, 2025 revision |
| `p` | Full refresh: black square, red square, checkerboard and border |
| `m` | Full refresh: protein icon only |
| `i` | Full refresh: PROTEIN, CARB, VEGETABLES, SPICE, OIL |
| `c` | Full refresh to white |
| `s` | Profile, raw BUSY level, phase and remaining cooldown |
| `?` | Menu |

For an IL0373 test: press `1`, then `p`. After `OK` and **180 seconds**, press `i`. There is no automatic profile probing or redraw loop. A profile selection alone sends no screen commands.

The user observed **approximately 3–5 seconds per refresh** with IL0373 on November 13, 2026; the test pattern and ingredient icons displayed successfully. This is an observed refresh duration, not a validated interval between updates. Commands typed during refresh are discarded. `OK` means SPI completed and BUSY asserted then released; visually inspect the screen to confirm colors/orientation. Reset/reflash cannot remember the previous update time: wait 180 seconds between actual refreshes across resets too.

## If it fails

| Result | Check |
|---|---|
| `select controller first` | Select the matching profile with `1`, `2` or `3` |
| `refresh cooldown` | Press `s`; wait for zero, then send the image key again |
| `BUSY did not become ready` | Power, common GND, BUSY/p23 and controller choice |
| `refresh BUSY never asserted` | ECS/DC/RST/SPI wiring, BUSY/p23 and controller choice |
| `SPI transfer failed` | Firmware/SPI peripheral fault; check the debugger and wiring |
| Correct pattern but wrong colors/orientation | Record the result and controller profile before changing the driver |

A fault holds display RST LOW and stops further attempts until reset. Correct the wiring/profile/power first; do not rapidly cycle through profiles. The exact controller revision remains unconfirmed. This bench supports **full refresh only**; the successful image test does not establish suitability for rapid ingredient updates.

## Implementation and checks

- [EInkDisplay](../../drivers/src/EInkDisplay.c): synchronous C port of [Adafruit_EPD / ThinkInk](https://github.com/adafruit/Adafruit_EPD); [pinned source and license](../../vendor/adafruit_epd/README.md). No Arduino dependencies or custom waveforms.
- [BenchHardware](BenchHardware.c): SPI1 at 100 kHz, 8-bit, mode 0; bounded transfers and UART diagnostics. BUSY has a weak internal pull-down. Other connected controls are held idle: status SS HIGH, data/clock LOW, spoon/treat signals LOW.
- [IngredientSprites](IngredientSprites.h): five 48x48 masks exported from approved artwork v3. [Exporter](../../tools/export_ingredient_sprites.py) needs Pillow only to regenerate this checked-in header. Frame storage is 9472 bytes in PIC RAM.
- `make -C firmware eink-test`: ASan/UBSan tests for profiles, color planes, coordinate edges, timeouts, cooldown/wrap and icons. Also writes native-size PPM previews under `firmware/build/eink/`.
- `make -C firmware/bench/eink DEBUG=1`: standalone SNAP debug link check.

This blocking bench driver needs a nonblocking service before game integration. Panel identification, actual refresh current, screen orientation and update limits require the physical test.
