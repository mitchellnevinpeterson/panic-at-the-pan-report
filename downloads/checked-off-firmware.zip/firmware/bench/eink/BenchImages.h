#ifndef PANIC_EINK_BENCH_IMAGES_H
#define PANIC_EINK_BENCH_IMAGES_H
#include "EInkDisplay.h"
void BenchImages_Pattern(EInkFrame *frame);
void BenchImages_Ingredients(EInkFrame *frame, unsigned int mask);
#endif
