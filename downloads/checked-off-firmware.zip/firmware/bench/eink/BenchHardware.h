#ifndef PANIC_EINK_BENCH_HARDWARE_H
#define PANIC_EINK_BENCH_HARDWARE_H
#include "EInkDisplay.h"
void BenchHardware_Init(void);
const EInkPort *BenchHardware_Port(void);
uint32_t BenchHardware_Milliseconds(void);
int BenchHardware_ReadKey(void); /* -1: none; -2: UART error, RX drained */
void BenchHardware_DrainInput(void);
void BenchHardware_Print(const char *format, ...);
#endif
