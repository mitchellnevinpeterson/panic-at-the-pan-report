#include "BenchImages.h"
#include "IngredientSprites.h"

static void rectangle(EInkFrame *frame, int x, int y, int w, int h, EInkColor color)
{
    int i, j;
    for (j = y; j < y + h; ++j)
        for (i = x; i < x + w; ++i) (void)EInk_Pixel(frame, i, j, color);
}

void BenchImages_Pattern(EInkFrame *frame)
{
    int x;
    EInk_Clear(frame);
    rectangle(frame, 0, 0, EINK_WIDTH, 2, EINK_BLACK);
    rectangle(frame, 0, 126, EINK_WIDTH, 2, EINK_BLACK);
    rectangle(frame, 0, 0, 2, EINK_HEIGHT, EINK_BLACK);
    rectangle(frame, 294, 0, 2, EINK_HEIGHT, EINK_BLACK);
    rectangle(frame, 12, 12, 72, 72, EINK_BLACK);
    rectangle(frame, 112, 12, 72, 72, EINK_RED);
    /* Right-hand checkerboard verifies color planes and byte boundaries. */
    for (int y = 12; y < 84; ++y)
        for (x = 212; x < 284; ++x)
            (void)EInk_Pixel(frame, x, y, (((x-212)/8 + (y-12)/8) & 1) ? EINK_RED : EINK_BLACK);
    /* One, two and three marks label columns without a font dependency. */
    for (int group = 0; group < 3; ++group)
        for (int mark = 0; mark <= group; ++mark)
            rectangle(frame, 32 + group*100 + mark*8, 100, 4, 12, EINK_BLACK);
}

void BenchImages_Ingredients(EInkFrame *frame, unsigned int mask)
{
    EInk_Clear(frame);
    for (unsigned int item = 0; item < INGREDIENT_SPRITE_COUNT; ++item) {
        if (!(mask & (1u << item))) continue;
        for (unsigned int y = 0; y < INGREDIENT_SPRITE_SIZE; ++y) {
            for (unsigned int x = 0; x < INGREDIENT_SPRITE_SIZE; ++x) {
                unsigned int index = y * (INGREDIENT_SPRITE_SIZE / 8u) + x / 8u;
                uint8_t bit = (uint8_t)(0x80u >> (x & 7u));
                EInkColor color = EINK_WHITE;
                if (IngredientSpriteBlack[item][index] & bit) color = EINK_BLACK;
                if (IngredientSpriteRed[item][index] & bit) color = EINK_RED;
                (void)EInk_Pixel(frame, (int)(8 + item*58 + x), (int)(40 + y), color);
            }
        }
    }
}
