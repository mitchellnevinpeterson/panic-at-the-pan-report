#include "BenchHardware.h"
#include "BenchImages.h"

/* Debugger watches; no display update occurs automatically at startup. */
volatile EInkResult EInkBenchResult = EINK_NEEDS_PROFILE;
volatile unsigned int EInkBenchCompleted;
static EInkFrame frame;

static void status(void)
{
    BenchHardware_Print("Profile: %s\r\nBUSY raw=%u; phase=%u; cooldown=%lu s\r\n",
        EInk_ProfileName(EInk_Profile()), (unsigned)BenchHardware_Port()->busy_level(),
        (unsigned)EInk_Phase(), (unsigned long)((EInk_CooldownRemaining()+999u)/1000u));
}

static void help(void)
{
    BenchHardware_Print("\r\nEInkBench: PIC1 / SPI1 / 296x128 tri-color\r\n"
        "Manual profile: 1=IL0373 (old), 2=UC8151D, 3=SSD1680. No auto-detection.\r\n"
        "p=pattern, i=all icons, m=protein only, c=white, s=status, ?=help\r\n");
    BenchHardware_Print("No update until a profile AND an image key are sent.\r\n"
        "One full refresh per command, then 180 s cooldown.\r\n"
        "Wait 180 s after any previous refresh, including across power/reset.\r\n");
    status();
}

int main(void)
{
    int key;
    BenchHardware_Init();
    if (!EInk_Bind(BenchHardware_Port())) for (;;) { }
    help();
    for (;;) {
        (void)BenchHardware_Milliseconds(); /* Extend core Count through wraps. */
        key = BenchHardware_ReadKey();
        if (key == -2) { BenchHardware_Print("UART error: input discarded.\r\n"); continue; }
        if (key < 0 || key == '\r' || key == '\n') continue;
        if (key >= 'A' && key <= 'Z') key += 'a' - 'A';
        if (key >= '1' && key <= '3') {
            EInkBenchResult = EInk_Select((EInkProfile)(key - '0'));
            BenchHardware_Print("Selection: %s\r\n", EInkBenchResult == EINK_OK ?
                EInk_ProfileName(EInk_Profile()) : EInk_ResultName(EInkBenchResult));
            continue;
        }
        if (key == '?' || key == 'h') { help(); continue; }
        if (key == 's') { status(); continue; }
        if (key != 'p' && key != 'i' && key != 'm' && key != 'c') {
            BenchHardware_Print("Unknown key; ? for help.\r\n"); continue;
        }
        if (key == 'p') BenchImages_Pattern(&frame);
        else if (key == 'c') EInk_Clear(&frame);
        else BenchImages_Ingredients(&frame, key == 'm' ? 1u : 31u);
        BenchHardware_Print("Request %c / %s. Wait for result; input during refresh is discarded.\r\n",
            key, EInk_ProfileName(EInk_Profile()));
        EInkBenchResult = EInk_Refresh(&frame);
        if (EInkBenchResult == EINK_OK) ++EInkBenchCompleted;
        BenchHardware_DrainInput();
        BenchHardware_Print("Result: %s\r\n", EInk_ResultName(EInkBenchResult));
        status();
    }
}
