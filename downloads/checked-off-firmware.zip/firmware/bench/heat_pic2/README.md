# HeatPIC2Bench — ultrasonic → LCD heat display + speaker

Standalone PIC2 test. The HC-SR04 distance sets the heat zone. The LCD bar and
label and the speaker sound all follow that zone. **No hardware changes**: it uses
the existing PIC2 wiring.

| Function | PIC2 physical pins |
| --- | --- |
| Ultrasonic | TRIG 6 (RB2, via U10 buffer), ECHO 7 (RB3, via divider) |
| Speaker | 26 (RB15 / OC1) through the existing RC filter and amplifier |
| LCD (confirmed in LCDPIC2Bench) | MOSI 14, SCK 16, CS 18, DC 23, RST 24 |
| Debug UART, 115200 8N1 | TX 11 → adapter RX; optional RX 15 |
| MCP | Initialized once to clear the lamp latches, then idle |

## Behavior

| Distance | Zone | LCD | Sound |
| --- | --- | --- | --- |
| < 150 mm | TOO MUCH | red label, long bar | intense crackle |
| 150–280 mm | JUST RIGHT | green label | gentle frying |
| > 280 mm | NOT ENOUGH | blue label, short bar | sparse oil pops |
| no echo | WAITING | empty bar | silent |

- **Zone switching:** needs 3 agreeing readings (~0.3 s), so a single bad echo doesn't flip it. Each switch plays a short cue.
- **Bar:** follows distance continuously, from empty at 400 mm to full at 50 mm.
- **Ranging:** about 10 readings per second (12 µs trigger, 30 ms echo timeout).

Zone thresholds and sounds are the teammate's, from `PIC32-LCD/src/heat_audio.c` and `sizzle.h`. The volume knob isn't wired, so volume stays at maximum.

## Program and observe

1. In VS Code, select **HeatPIC2Bench**, configuration **default**.
2. Connect SNAP to **PIC2** and select **Make and Program Device**.
3. Wait about 15 s for **PAN HEAT** to draw. A short chime then means audio started.
4. Move a hand from about 40 cm toward the sensor: NOT ENOUGH → JUST RIGHT → TOO MUCH.

The UART prints `HEAT -> <mm> mm <zone>` on each zone change, and the current reading twice a second.

## Limits

- **LCD drawing:** the LCD uses blocking software SPI, so the screen only redraws between distance readings. A zone change redraws the label, which can briefly delay the next reading. Audio keeps playing.
- **PIC1:** if PIC1 is running a game image, it may report link loss. This bench doesn't use UART2.
- **Audio pin routing workaround:** pin 26 is routed to the audio output in `main.c`'s first pin-routing block. On the bench, the identical write inside the teammate's `heat_audio_start()` read back 0 and left the speaker silent. The root cause is still unknown. The full PIC2 game image (`firmware/pic2/Audio.c`) does the same late write, so check its audio on hardware.
- **Diagnostics:** each status line ends in `audio=ok` (or names the failing part), and `AUDIOREG` lines dump the audio registers.
- **Testing:** sensor, zones, LCD and audio firmware confirmed on hardware Nov 17.

```sh
make -C firmware heat-pic2            # firmware/build/heat_pic2/heat_pic2.hex
make -C firmware/bench/heat_pic2 DEBUG=1 all
```
