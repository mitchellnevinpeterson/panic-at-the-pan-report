/* HeatPIC2Bench: ultrasonic distance drives the LCD heat display and the
 * speaker on the existing PIC2 wiring. Standalone; no game, UART2 or PIC1.
 *
 * Scheduling: the LCD transport is blocking software SPI, so the screen is
 * redrawn only right after a distance reading completes, while the ranger is
 * idle. A long redraw just delays the next trigger; it never cuts into an
 * echo measurement. Audio runs from the Timer3 interrupt throughout.
 */
#include "LcdSoftSPI.h"
#include "heat_lcd.h"
#include "heat_audio.h"
#include "st7789.h"
#include "McpInputs.h"
#include "Range.h"

#define US_TRIG (1u << 2) /* RB2, pin6 (through U10 buffer) */
#define US_ECHO (1u << 3) /* RB3, pin7 (through divider) */
#define REPORT_TICKS (500000u * CORE_TICKS_PER_US)

volatile unsigned HeatBenchPhase; /* 0 boot, 1 drawing LCD, 2 running, 3 LCD fault. */
volatile uint32_t HeatBenchDistanceMm; /* Last valid reading; 0 = none. */

static void debug_init(void)
{
    LATBSET = 1u << 4; /* PIC2 debug TX11. */
    ODCBCLR = 1u << 4;
    TRISBCLR = 1u << 4;
    TRISBSET = 1u << 6; /* Debug RX15. */
    pps_unlock();
    RPB4R = 1;
    U1RXR = 1;
    /* Route audio pin26 to OC1 here, in the first PPS block. On the bench,
     * heat_audio_start()'s later identical PPS write read back 0. OC1 stays
     * off (pin LOW) until heat_audio_start() enables it. */
    RPB15R = 5;
    pps_lock();
    U1MODE = 0;
    U1STA = 0;
    U1MODEbits.BRGH = 1;
    U1BRG = 42; /* PBCLK20MHz / (4*43), nominal 115200. */
    U1STAbits.UTXEN = 1;
    U1STAbits.URXEN = 1;
    U1MODEbits.ON = 1;
}

static void text(const char *s)
{
    while (*s) {
        uint32_t start = ticks_now();
        while (U1STAbits.UTXBF)
            if ((uint32_t)(ticks_now() - start) >= 20000u) return;
        U1TXREG = (uint8_t)*s++;
    }
}

static void number(uint32_t value)
{
    char digits[11];
    unsigned n = 0;
    do { digits[n++] = (char)('0' + value % 10u); value /= 10u; } while (value);
    char out[12];
    for (unsigned i = 0; i < n; ++i) out[i] = digits[n - 1u - i];
    out[n] = '\0';
    text(out);
}

/* Firmware side of the audio path. The music bed plays in every zone, so
 * "ok" here with a silent speaker points at the filter/amplifier/speaker. */
static const char *audio_status(void)
{
    if (RPB15R != 5u) return "PIN26-NOT-ROUTED";
    if (!OC1CONbits.ON) return "OC1-OFF";
    if (!T2CONbits.ON) return "TIMER2-OFF";
    if (!T3CONbits.ON || !IEC0bits.T3IE) return "ISR-OFF";
    /* Hardware sets T3IF every 80 us; a running ISR clears it at once. */
    for (unsigned i = 0; i < 4u; ++i) {
        if (!IFS0bits.T3IF) return "ok";
        delay_us(100u);
    }
    return "ISR-STUCK";
}

static void hex(uint32_t value)
{
    char out[9];
    for (unsigned i = 0; i < 8u; ++i) out[i] = "0123456789ABCDEF"[(value >> (28u - 4u * i)) & 15u];
    out[8] = '\0';
    text(out);
}

/* Raw registers: tells "write never took effect" from "undone later". */
static void audio_registers(const char *when)
{
    text("AUDIOREG "); text(when);
    text(" RPB15R="); hex(RPB15R); text(" OC1CON="); hex(OC1CON);
    text(" T2CON="); hex(T2CON); text(" T3CON="); hex(T3CON);
    text(" PMD3="); hex(PMD3); text(" PMD4="); hex(PMD4);
    text(" CFGCON="); hex(CFGCON); text("\r\n");
}

static void audio_report(void)
{
    text("audio="); text(audio_status());
    text(" vol="); number(heat_audio_volume()); text("/16");
}

static const char *zone_name(HeatZone zone)
{
    static const char *const names[] = {"WAITING", "NOT ENOUGH", "JUST RIGHT", "TOO MUCH"};
    return zone <= HEAT_HIGH ? names[zone] : "?";
}

int main(void)
{
    __builtin_disable_interrupts();
    DDPCONbits.JTAGEN = 0;
    /* Quiet outputs first: TRIG LOW, audio LOW, MCP SS HIGH. */
    ANSELBCLR = US_TRIG | US_ECHO | (1u << 15);
    LATBCLR = US_TRIG | (1u << 15);
    TRISBCLR = US_TRIG | (1u << 15);
    TRISBSET = US_ECHO;
    LATASET = 1u; TRISACLR = 1u; ANSELACLR = 1u;
    debug_init();
    text("\r\nHeatPIC2Bench: ultrasonic TRIG6/ECHO7 -> LCD heat + speaker26; 115200 baud\r\n"
         "LCD MOSI14 SCK16 CS18 DC23 RST24. Zones: <150 mm TOO MUCH, 150-280 JUST RIGHT,\r\n"
         ">280 NOT ENOUGH. No game, UART2, buttons or PIC1.\r\n");
    audio_registers("early");
    bool mcp = McpInputs_Init(); /* Clear retained lamp latches. */
    text(mcp ? "MCP lamp outputs cleared.\r\n" :
               "MCP unavailable; lamp state unverified. Bench continues.\r\n");

    /* Draw before audio starts, so the sample interrupt does not slow it. */
    display_spi_start();
    st7789_prepare_pins();
    HeatBenchPhase = 1;
    text("Drawing PAN HEAT; allow about 15 seconds.\r\n");
    if (!heat_lcd_start()) {
        HeatBenchPhase = 3;
        text("LCD drawing failed; audio and ranging continue.\r\n");
    }

    heat_audio_start(); /* Enables interrupts. */
    audio_registers("after-start");
    heat_audio_play_startup_cue();
    Pic2Range range;
    Pic2Range_Init(&range, ticks_now());
    if (HeatBenchPhase != 3) HeatBenchPhase = 2;
    text("Running. Music should play in every zone. ");
    audio_report();
    text("\r\nMove a hand or target in front of the sensor.\r\n");

    HeatZone reported = HEAT_SILENT;
    uint32_t report = ticks_now();
    unsigned reports = 0;
    for (;;) {
        Pic2Range_Poll(&range, ticks_now(), (PORTB & US_ECHO) != 0);
        if (range.trigger) LATBSET = US_TRIG; else LATBCLR = US_TRIG;
        if (range.sample_ready) {
            range.sample_ready = false;
            uint32_t mm = range.valid ? range.mm : 0u; /* 0 = invalid for both modules. */
            HeatBenchDistanceMm = mm;
            (void)heat_audio_update(mm); /* Zone switches after 3 agreeing readings. */
            heat_lcd_set_distance(mm);
            heat_lcd_update();
            HeatZone zone = heat_audio_zone();
            if (zone != reported || (uint32_t)(ticks_now() - report) >= REPORT_TICKS) {
                if (zone != reported) text("HEAT -> ");
                if (mm) { number(mm); text(" mm  "); } else text("no echo  ");
                text(zone_name(zone));
                text("  ");
                audio_report();
                text("\r\n");
                reported = zone;
                report = ticks_now();
                if (++reports % 20u == 0u) audio_registers("running");
            }
        }
        if (U1STAbits.OERR) U1STACLR = _U1STA_OERR_MASK;
        if (U1STAbits.URXDA) { volatile unsigned ignored = U1RXREG; (void)ignored; }
    }
}
