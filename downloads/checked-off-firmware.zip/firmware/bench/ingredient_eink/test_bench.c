#include "BenchModel.h"
#include "BenchWire.h"
#include "BenchCanvas.h"
#include "BenchImages.h"
#include "EInkAsync.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static void debounce(void) {
    BenchInputs p; BenchInputs_Init(&p,0);
    assert(!BenchInputs_Ready(&p,19));
    /* A held switch at boot is admitted, with no release/start-button rule. */
    assert(BenchInputs_Update(&p,0xfe,0)==0);
    assert(BenchInputs_Update(&p,0xfe,19)==0);
    assert(BenchInputs_Update(&p,0xfe,20)==1);
    assert(BenchInputs_Ready(&p,20));
    assert(BenchInputs_Update(&p,0xff,21)==1);
    assert(BenchInputs_Update(&p,0xfe,25)==1);
    assert(BenchInputs_Update(&p,0xff,30)==1);
    assert(BenchInputs_Update(&p,0xff,49)==1);
    assert(BenchInputs_Update(&p,0xff,50)==0);
    /* Start/Finish/reserved GPA5..7 can float without changing the mask. */
    for(unsigned i=0;i<8;++i) assert(BenchInputs_Update(&p,(uint8_t)((i<<5)|31),100+i*30)==0);
    for(unsigned mask=0;mask<32;++mask) {
        uint32_t at=1000+mask*100;
        (void)BenchInputs_Update(&p,(uint8_t)~mask,at);
        assert(BenchInputs_Update(&p,(uint8_t)~mask,at+20)==mask);
    }
    BenchInputs_Init(&p,UINT32_MAX-10u);
    assert(BenchInputs_Update(&p,0,UINT32_MAX-10u)==0);
    assert(BenchInputs_Update(&p,0,9)==31);
}
static void protocol(void) {
    uint8_t bytes[14]; BenchPacket got;
    for(unsigned seq=0;seq<256;++seq) for(unsigned mask=0;mask<32;++mask) {
        BenchPacket sent={BENCH_SNAPSHOT,(uint8_t)seq,(uint8_t)mask,true};
        size_t n=BenchWire_Encode(&sent,bytes); assert(n<=14);
        BenchParser p={0}; unsigned count=0;
        for(size_t j=0;j<n;++j) count+=BenchWire_Receive(&p,bytes[j],&got);
        assert(count==1 && got.mask==mask && got.sequence==seq && got.valid && got.type==BENCH_SNAPSHOT);
        /* Every single-bit corruption in payload/framing is rejected. */
        for(size_t j=1;j+1<n;++j) for(unsigned bit=0;bit<8;++bit) {
            p=(BenchParser){0}; count=0;
            for(size_t k=0;k<n;++k) count+=BenchWire_Receive(&p,bytes[k]^(k==j?(1u<<bit):0),&got);
            assert(count==0);
        }
    }
    BenchPacket sent={BENCH_ACK,0x7e,0,false}; size_t n=BenchWire_Encode(&sent,bytes);
    BenchParser p={0};
    for(unsigned i=0;i<100;++i) assert(!BenchWire_Receive(&p,0x55,&got));
    unsigned count=0;
    for(size_t i=0;i<n;++i) count+=BenchWire_Receive(&p,bytes[i],&got);
    assert(count==1 && got.type==BENCH_ACK && !got.valid);
    /* Truncated packet followed by a fresh delimiter resynchronizes. */
    for(size_t i=0;i<4;++i) assert(!BenchWire_Receive(&p,bytes[i],&got));
    count=0;
    for(size_t i=0;i<n;++i) count+=BenchWire_Receive(&p,bytes[i],&got);
    assert(count==1);
}
static EInkFrame frame,reference,frozen;
static uint32_t now,refresh_at;
static unsigned command,offsets[2],refreshes;
static bool bus;
static uint32_t clock_ms(void) { return now; }
static void reset(bool high) { (void)high; }
static bool busy(void) { return !refresh_at || (uint32_t)(now-refresh_at)>=30; }
static bool start(bool data,const uint8_t *bytes,size_t n) {
    assert(!bus && n && n<=32); bus=true;
    if(!data) { command=bytes[0]; if(command==0x12) { refresh_at=now; ++refreshes; } }
    else if(command==0x10 || command==0x13) {
        unsigned plane=command==0x13;
        const uint8_t *expected=plane?frozen.red:frozen.black;
        for(size_t i=0;i<n;++i) assert(bytes[i]==(uint8_t)~expected[offsets[plane]++]);
    }
    return true;
}
static EInkBusState poll(void) { assert(bus); bus=false; return EINK_BUS_IDLE; }
static void render(uint8_t mask) {
    BenchCanvas_Start(&frame,mask);
    unsigned calls=0;
    while(!BenchCanvas_Service()) assert(++calls<1000);
}
static void images(void) {
    for(unsigned mask=0;mask<32;++mask) {
        render((uint8_t)mask); BenchImages_Ingredients(&reference,mask);
        assert(memcmp(&frame,&reference,sizeof frame)==0);
    }
}
static void queue_and_refresh(void) {
    BenchDisplay d; BenchDisplay_Init(&d,0);
    const EInkAsyncPort port={start,poll,reset,busy,clock_ms};
    now=0; assert(!EInkAsync_InitWithCooldown(&port,0));
    assert(EInkAsync_InitWithCooldown(&port,BENCH_COOLDOWN_MS));
    now=BENCH_COOLDOWN_MS-1; assert(!EInkAsync_CanStart());
    BenchDisplay_Receive(&d,0,true,now);
    now=BENCH_COOLDOWN_MS; BenchDisplay_Receive(&d,0,true,now);
    assert(!BenchDisplay_Select(&d,now)); /* No blank startup refresh. */
    BenchDisplay_Receive(&d,1,true,now);
    assert(BenchDisplay_Select(&d,now)); render(d.selected); frozen=frame;
    assert(EInkAsync_Start(&frame));
    /* A newer complete wire snapshot arrives while SPI/BUSY is in progress. */
    uint8_t encoded[14]; BenchPacket sent={BENCH_SNAPSHOT,1,31,true},got;
    size_t n=BenchWire_Encode(&sent,encoded); BenchParser parser={0};
    for(size_t i=0;i<n;++i) if(BenchWire_Receive(&parser,encoded[i],&got))
        BenchDisplay_Receive(&d,got.mask,got.valid,now);
    assert(d.selected==1 && d.desired==31 && !BenchDisplay_Select(&d,now));
    for(unsigned i=0;i<10000 && EInkAsync_IsBusy();++i) { ++now; assert(EInkAsync_Service()); }
    assert(!EInkAsync_IsBusy() && refreshes==1 && memcmp(&frame,&frozen,sizeof frame)==0);
    assert(offsets[0]==EINK_PLANE_BYTES && offsets[1]==EINK_PLANE_BYTES);
    BenchDisplay_Finish(&d,now); uint32_t finished=now;
    assert(d.displayed==1 && BenchDisplay_Wait(&d,now)==BENCH_COOLDOWN_MS);
    now=finished+BENCH_COOLDOWN_MS-1; BenchDisplay_Receive(&d,31,true,now);
    assert(!BenchDisplay_Select(&d,now) && !EInkAsync_CanStart());
    ++now; assert(BenchDisplay_Select(&d,now) && EInkAsync_CanStart());
    /* A stale/invalid link must cancel the selected build before transfer. */
    now+=600; assert(!BenchDisplay_Current(&d,now)); d.busy=false;
    assert(!BenchDisplay_Select(&d,now));
    BenchDisplay_Receive(&d,31,false,now); assert(!BenchDisplay_Select(&d,now));
    BenchDisplay_Receive(&d,0,true,now); assert(d.desired==31); /* OFF keeps additions. */
    BenchDisplay_Clear(&d); assert(BenchDisplay_Select(&d,now));
    assert(d.selected==0); /* Explicit clear uses the normal update queue. */
    BenchDisplay_Finish(&d,now); now+=BENCH_COOLDOWN_MS;
    BenchDisplay_Receive(&d,0,true,now); assert(!BenchDisplay_Select(&d,now));
    BenchDisplay_Init(&d,UINT32_MAX-1500u); now=1499;
    BenchDisplay_Receive(&d,2,true,now); assert(BenchDisplay_Select(&d,now));
}
static void accumulation_and_clear(void) {
    BenchDisplay d; BenchDisplay_Init(&d,0);
    BenchDisplay_Receive(&d,1,true,20); assert(d.desired==1);
    BenchDisplay_Receive(&d,0,true,40); assert(d.desired==1 && d.live==0);
    BenchDisplay_Receive(&d,2,true,60); assert(d.desired==3);
    BenchDisplay_Receive(&d,31,false,80); assert(d.desired==3 && d.live==2);
    BenchDisplay_Clear(&d); assert(d.desired==0 && d.inhibited==2);
    BenchDisplay_Receive(&d,2,true,100); assert(d.desired==0);
    BenchDisplay_Receive(&d,6,true,120); assert(d.desired==4); /* Different new ON. */
    BenchDisplay_Receive(&d,4,true,140); assert(d.desired==4 && d.inhibited==0);
    BenchDisplay_Receive(&d,6,true,160); assert(d.desired==6); /* Released/re-ON. */
    BenchDisplay_Receive(&d,0,true,180); assert(d.desired==6); /* PIC2 reset doesn't clear. */
    BenchDisplay_Clear(&d);
    BenchDisplay_Receive(&d,0,true,BENCH_COOLDOWN_MS); assert(BenchDisplay_Select(&d,BENCH_COOLDOWN_MS));
    assert(d.selected==0); /* Explicit clear can erase retained unknown boot image. */
}
int main(void) {
    assert(BENCH_COOLDOWN_MS==3000u);
    debounce(); protocol(); images(); queue_and_refresh(); accumulation_and_clear();
    puts("Ingredient bench: debounce, framing, 32 images, accumulation/clear, stale link, immutable refresh, cooldown passed");
}
