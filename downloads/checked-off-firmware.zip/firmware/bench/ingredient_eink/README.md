# Ingredient switch → E-ink bench

Two standalone PIC32MX170F256B DIP-28 images. **ON adds an ingredient; OFF keeps its icon.** Startup-held switches also add. Start/Finish are ignored. Both bench images must run together; the old PIC2 audio/ultrasonic image cannot forward switches.

**Wait 3 seconds after PIC1 boot before the first transfer, then 3 seconds after each completed refresh.** New additions combine into the next permitted image. The old IL0373 EInkBench refresh took about 3–5 seconds in the user's test; the combined bench has now cleared the screen successfully, with a longer observed refresh. The 3-second interval is user-selected for this test, not a verified panel lifetime specification. Reset restarts the full wait. Old panel content remains until a refresh; no automatic blank refresh is spent at boot.

## 1. Wire with power off

Numbers below are **physical DIP pins**. Preserve tested PIC power, MCLR, VCAP and decoupling. Use one 3.3 V source and common GND; leave USB-UART VCC unconnected. Do not parallel separate 5 V supplies.

| PIC2 / rail | Bare MCP23S17 | Signal |
|---|---|---|
| Pin 2 / RA0 | Pin 11 | SS; existing 10 kΩ pull-up to 3.3 V |
| Pin 3 / RA1 | Pin 13 / SI | MOSI |
| Pin 22 / RB11 | Pin 14 / SO | MISO |
| Pin 25 / RB14 | Pin 12 / SCK | Clock |
| 3.3 V | Pin 9 / VDD | C22 = 0.1 µF to GND |
| GND | Pin 10 / VSS | Ground |
| 3.3 V | Pin 18 / RESET | Direct tie |
| GND | Pins 15, 16, 17 | A0–A2 = address zero |

| Ingredient | MCP input / physical pin | Mask |
|---|---|---|
| Protein | GPA0 / 21 | `0x01` |
| Carb | GPA1 / 22 | `0x02` |
| Vegetables | GPA2 / 23 | `0x04` |
| Spice | GPA3 / 24 | `0x08` |
| Oil | GPA4 / 25 | `0x10` |

Each switch retains its external 10 kΩ pull-up to 3.3 V; **ON/closed grounds its input**. Debounce is 20 ms. Unwired GPA5–7 do not affect the bench.

**Add the inter-PIC wires:** PIC1 **TX21 → PIC2 RX17**, PIC2 **TX21 → PIC1 RX17**, and common GND. This is UART2 with direct 3.3 V logic, **115200 8N1**, no flow control (actual 116279 baud). These are separate from USB debug pins; do not attach a USB-UART transmitter to pins 17/21.

| Existing E-ink connection | PIC1 / rail |
|---|---|
| VIN / GND | 3.3 V / common GND |
| MOSI / SCK / ECS | Pins 3 / 25 / 2 |
| D/C / RST / BUSY | Pins 11 / 18 / 23 |

Direct logic, no 74ACT244 here; display 3V3 output remains unconnected. Firmware automatically uses **IL0373**, the profile selected with `1` in the successful EInkBench test. No controller key is required. Exact controller markings remain unconfirmed.

Connected PIC1 status-display pins 22/26 stay LOW and SS24 HIGH; old digits may persist. Servo pin12 has PWM disabled; pin14 stays LOW. PIC2 audio pin26/RB15/OC1 and ultrasonic trigger pin6 stay LOW. MCP GPB0 is held LOW.

## 2. Build and program both PICs

| Target | MPLAB project / configuration | MPLAB image |
|---|---|---|
| PIC1, E-ink | **IngredientEInkPIC1 / default** | `out/IngredientEInkPIC1/default.elf` |
| PIC2, MCP | **IngredientEInkPIC2 / default** | `out/IngredientEInkPIC2/default.elf` |

Both specify PIC32MX170F256B, XC32 v6.00, DFP 1.7.380 and SNAP. Reload VS Code if absent. Preserve `cmake/IngredientEInkPIC*/default/user.cmake`: it fixes the known SNAP boot reservation overlapping DEVCFG3; production imports the same fix.

With one SNAP:

1. Power off. Move SNAP's target connections to **PIC2's own MCLR1, VDD sense, GND, PGED1/pin4 and PGEC1/pin5**, using the existing lab adapter. Its header order is not raw SNAP pin numbering. Never join the two PICs' MCLR/programming nets.
2. Power the target normally, select **IngredientEInkPIC2**, build and use MPLAB's program/run action. If debugging stops at `main`, Continue.
3. End debugging and power off. Move all target-specific SNAP connections to **PIC1's own** MCLR/VDD-sense/GND/pin4/pin5. Select **IngredientEInkPIC1**, build and program/run; Continue if debugging.
4. Run both PICs. Each PIC1 boot begins its 3-second wait; debugger pauses interrupt link service.

CLI commands from the repository root build only; **they do not flash**:

```sh
make -C firmware ingredient-eink
make -C firmware ingredient-eink-test
make -C firmware ingredient-eink DEBUG=1
```

Individual targets: `ingredient-eink-pic1` / `ingredient-eink-pic2`. Production output: `firmware/build/ingredient_eink/ingredient_eink_pic1.hex` and `ingredient_eink_pic2.hex`, with `.elf`/`.map`; debug output: `firmware/build/ingredient_eink_debug/`. Make and MPLAB outputs are separate. Existing EInkBench and JoystickServoBench_2 remain unchanged and can be reprogrammed to restore those tests.

## 3. Observe and test

Both debug terminals now use **115200 8N1, 3.3 V logic, no flow control**. This differs from the teammate PIC2 test's 9600 baud. USB-UART RX → PIC1 TX16, TX → PIC1 RX15, plus GND. For PIC2, adapter RX → PIC2 TX11; optional adapter TX → PIC2 RX15. One adapter observes one target at a time; never join their TX outputs. Status repeats every 10 seconds/on changes; `s` or `?` prints status without Enter.

1. All switches OFF: PIC2 should report `MCP=OK mask=0x00 ACK=OK`; PIC1 reports `link=OK live=0x00 added=0x00 phase=WAIT`, with decreasing `wait_s`. Actual lines also include other fields. Ignore unused upper bits of MCP `raw`.
2. Turn protein ON and leave it ON until accepted; use at least ~200 ms for a deliberate switch test. PIC2 reports `mask=0x01`; PIC1 reports `live=0x01 added=0x01`.
3. At the end of PIC1's boot wait, expect `EINK START mask=0x01`, then a refresh and `EINK DONE mask=0x01; cooldown 3s; visually verify panel`. Confirm the protein icon at the left. Completion verifies SPI/BUSY progression, not the visible pixels.
4. Turn protein OFF: `live=0x00 added=0x01`; its icon stays. Turn carb ON: `added=0x03`, displayed after cooldown. Turn all five ON during the wait to test one combined `0x1F` refresh: protein, carb, vegetables, spice, oil, left to right.
5. Send **`c` to PIC1's debug UART** to clear. It prints `CLEAR queued; held switches need OFF then ON; cooldown unchanged`. Leave switches OFF until the queued white frame finishes if you want a visible blank. Each switch last seen held ON at clear must be observed OFF then ON to add again. Other new ON switches can add during the wait.

PIC1 keeps additions across PIC2 reset/reconnect. PIC1 reset loses the accumulated RAM state while the panel retains its image; `c` can erase it after the boot wait. A clear or addition during an active refresh queues the next image without modifying the current frame. There is no promise of one refresh per switch action.

## Troubleshooting

| Symptom | Check / meaning |
|---|---|
| `MCP=FAULT` | Power, RESET, address ties, SS and four SPI wires. PIC2 sends invalid snapshots and retries once per second. |
| MCP raw low five bits unchanged | Check switches/pull-ups: all OFF = `0x1F`; GPA0 grounded = `0x1E`. |
| `link=STALE/INVALID` | Missing/invalid snapshot for 600 ms: matching bench images, both PICs running, crossed UART2 and common GND. New refreshes pause until valid input returns. |
| PIC1 link OK, PIC2 ACK stale | Check PIC1 TX21 → PIC2 RX17 return wire. ACK is diagnostic; it does not gate display updates. |
| `wait_s` nonzero | Normal boot/cooldown; no command bypasses it. The next cooldown starts after REFRESH completes. |
| `shown=unknown` | No successful refresh this PIC1 session. Retained screen content proves nothing. |
| `selected` differs from `added` | Current/last frame differs from latest queued additions. OFF preserving `added` is expected. |
| `EINK FAULT: ...` | SPI failure or BUSY assertion/timeout fault. Check power, wiring and profile before reset. RST stays LOW; automatic retries are disabled. |
| `uart_errors` increases | UART overflow/framing/parity error or TX congestion; inspect wiring/debugger pauses. |

A stale link blocks new refreshes but lets one already underway finish. A switch event entirely during disconnection cannot be reconstructed; hold intended switches ON after reconnect until PIC1 reports them in `added`.

## Software validation

Both production and SNAP-debug images compile with XC32 6.00/DFP 1.7.380 and `-Werror`; MPLAB manifest source lists/flags also compile in both modes. ASan/UBSan checks cover debounce/boot-held inputs/time wrap, ignored upper bits, accumulation/clear/re-arm, CRC framing/corruption, all 32 icon combinations, stale links, immutable in-flight frames, 3-second cooldown and async BUSY/SPI faults. The user has programmed both PICs, verified all five switch inputs and the UART link, and completed a white-screen refresh. The new 3-second interval still needs a hardware run.

The bench sends its own CRC8-framed snapshots on stable changes and every 100 ms; it is **incompatible with full-game PeerLink**. Canvas/SPI/debug work is incremental; hardware loop timing still needs measurement. Shared MCP, async E-ink driver, sprites and clock sources are reused unchanged; no full-game service is linked.
