# Score + timer bench test

This standalone demo auto-starts after one welcome banner. The revised game design repeats the banner until a physical Start press; that behavior is implemented in [GameSMBench](../game_sm/README.md) with UART inputs; physical Start integration is pending.

**One PIC32MX170F256B + two stacked 8×32 MAX7219 strips:** one 16×32 display, eight drivers total. This is a separate test image; it does not run the game.

```text
Top strip:     SCORE   TIME
Bottom strip:   120     48
```

Both labels remain visible above the values. TIME shows remaining **seconds**. Compact headings fit all32 columns; score supports -999..9999 and time0..999. Out-of-range values show dashes.

## Wiring — power off first

Keep the working PIC core and SNAP connections. Numbers below are physical DIP pins.

| Signal | PIC32 | 74ACT244 input → output | Destination |
|---|---|---|---|
| DATA / MOSI | **22 / RB11** | **13 → 7** | Top strip DIN |
| SCK | **26 / RB15** | **11 → 9** | Both CLK |
| SS | **24 / RB13** | **15 → 5** | Both CS / SS |

**Top DOUT → bottom DIN.** Bottom DOUT stays open. Connecting the first board's OUT header to the second board's IN header is correct: DOUT→DIN, CLK→CLK, CS→CS, GND→GND. CLK/SS pass through as shared signals. Match the printed labels rather than assuming connector order. Connect only these two strips; no heat driver or pan on this bench chain.

- PIC: **3.3 V**. Strips/buffer: **5 V**, with common GND. Feed each strip from the course load supply, not the ~100 mA breadboard regulator.
- 74ACT244: pin20 → 5 V; pins10/1/19 → GND; 100 nF between20/10 nearby.
- For this standalone test, unused buffer inputs2/4/6/8/17 → GND; outputs18/16/14/12/3 open.
- PIC SS/p24: 10 kΩ pull-up to **3.3 V**. SCK/p26 and DATA/p22: 10 kΩ pull-downs. These branch off the signals, not in series.
- This image uses **SPI2**, not the Lab SPI1 pins2/3/25. RB15/p26 is SCK, not a debug LED output.

## Build and program

### MPLAB in VS Code (Lab workflow)

Open the repository's **project root** in VS Code. The ready-made [ScoreTimerBench project](../../../.vscode/ScoreTimerBench.mplab.json) selects only the five bench sources and their headers.

1. `Cmd+Shift+P` → **MPLAB: Edit project properties (UI)**. Select `ScoreTimerBench`, configuration `default`. If it is missing, run **Developer: Reload Window**; enable workspace trust as in the lab.
2. Check **PIC32MX170F256B**, **XC32 v6.00**, **PIC32MX_DFP 1.7.380**. Under **Tool Configuration**, click **Configure Tool**. In **Select Tool**, choose the connected **SNAP** entry with its serial number; **Show only connected tools** narrows the list. Keep the existing external power arrangement.
3. `Cmd+Shift+P` → **MPLAB CMake: Build**. Select `ScoreTimerBench` if prompted; wait for a successful build.
4. Use **Program device** in the MPLAB commands/menu for the selected project. For a source-level debug session instead, use **Start debugging**, then Continue if execution stops at `main`.

MPLAB generates its own `cmake/ScoreTimerBench`, `_build/ScoreTimerBench` and `out/ScoreTimerBench` folders. Its image is separate from the Make-built HEX below. No source copying, generated `main.c`, game framework or host test files are needed. The programmer serial number stays in an ignored `*.mplab-local.json` file.

Keep the tracked [user.cmake](../../../cmake/ScoreTimerBench/default/user.cmake). Like the working Lab3 project, it corrects MPLAB's SNAP debug boot reservation to end at `0x1FC00BEF`, immediately before DEVCFG3. This prevents `.config_BFC00BF0 overlaps reserve_boot` while retaining the full debug executive region and all config bits. After adding it, run **MPLAB CMake: Clean and build**. Do not edit `.generated` files.

Based on Lab2 Pre-lab0.5–0.6 and Part1.1–1.4, Lab3 Part2.1, and the existing Lab3 project configuration. See the [Microchip workflow](https://developerhelp.microchip.com/xwiki/bin/view/software-tools/ides/extensions/workflow/). The MPLAB-generated SNAP debug CMake clean build passes and produces ELF/HEX; the link map preserves all four config words and the full debug reservation. The user subsequently programmed and ran this bench successfully.

### Terminal alternative

From the repository root:

```sh
make -C firmware score-timer
```

Load **[score_timer_bench.hex](../../build/score_timer/score_timer_bench.hex)** with your existing MPLAB/SNAP workflow; select **PIC32MX170F256B** and externally power the target as in the lab. The command builds but does not flash.

`Nothing to be done for 'all'` means the compiled files are already up to date. It is not an error and does not mean the PIC has been programmed.

## Expected behavior

1. `Welcome to Panic at the Pan` scrolls right to left once, using both strips as one 16×32 screen (~12 seconds).
2. After the text fully exits, top shows `SCORE` / `TIME`; bottom shows `0` / `60`.
3. Once those values reach the display, the countdown starts: score adds10 each second; time counts60 → 0 seconds.
4. `600` / `0` hold three seconds, then counters repeat. A PIC reset replays the welcome banner.

Edit `BENCH_WELCOME_TEXT` or `BENCH_WELCOME_STEP_MS` in [BenchConfig.h](BenchConfig.h) to change the message or speed. These are demo values. Timing uses the internal oscillator and is not calibrated.

## If it looks wrong

Edit [BenchConfig.h](BenchConfig.h) and rebuild:

| Observation | Change / check |
|---|---|
| Labels and values on the wrong strips | Toggle `top_first`. |
| Rotated characters | Change that strip's `rotation`: 0/90/180/270. Default180 reproduces Lab row/bit reversal. |
| Four blocks reversed | Toggle that strip's `reverse_modules`; a physically rotated strip may need rotation changed too. |
| Both blank | Check power/GND, buffer enables, DIN side and pins22/26/24. Reset after both rails are powered. |
| Only first strip works | Check DOUT→DIN, second strip CLK/SS and power. |

Logic analyzer: **100 kHz, idle-low SCK, MSB-first, 128 clocks per SS-low interval**. Low brightness is intentional. Never use register0x0F=1 for routine brightness testing.

## Module and validation

[ScoreTimerDisplay.h](../../drivers/include/ScoreTimerDisplay.h): `ShowLabels()`, `SetScore()`, `SetTimerSeconds()` (seconds). Both value setters update separate bottom-strip regions. `SetBanner(text, left_x)` renders large text across both strips; `SetText()` / `SetFrame()` target one strip for diagnostics. Call `Service()` frequently from one foreground owner; it advances SPI without wait loops and keeps in-flight images immutable. It exclusively owns SPI2; poll well under the 5 ms per-word timeout.

Debugger watches: `DisplayStatus`, `DisplayBenchPhase`, `DisplayBenchMilliseconds`. A latched `SCORE_TIMER_FAULT` needs reset/reinitialization. SPI completion cannot detect a disconnected display because MAX7219 has no acknowledgement wire.

Run `make -C firmware score-timer-test` for host checks. XC32 build and ASan/UBSan checks pass: initialization, chain order, formatting, panel isolation, orientation, snapshots and faults. The34 copied Lab/framework files are unchanged; the reused font retains its existing parentheses warning. **User-reported bench success:** labels/values and the scrolling welcome banner displayed correctly on the two-strip chain. Integrated hardware and adding the heat driver require later work.

References: [MAX7219](https://www.analog.com/media/en/technical-documentation/data-sheets/MAX7219-MAX7221.pdf), [PIC32 SPI/PPS](https://www.microchip.com/content/dam/mchp/documents/MCU32/ProductDocuments/DataSheets/PIC32MX1XX2XX283644-PIN_Datasheet_DS60001168L.pdf).
