/* Real GameSM + IngredientSM + ScoreSM + CookSM + UART adapter; fake hardware,
 * actuators (Servo50Hz/Treat/Stirrer) and ES queue/timers. Dispatch uses the
 * same higher-priority-first ordering as the course framework.
 */
#include "BenchIO.h"
#include "GameButtons.h"
#include "ButtonSensor.h"
#include "ButtonEInk.h"
#include "ButtonEInkPort.h"
#include "PeerUart.h"
#include "GameSM.h"
#include "IngredientSM.h"
#include "ScoreSM.h"
#include "CookSM.h"
#include "Servo50Hz.h"
#include "Treat.h"
#include "Stirrer.h"
#include <string.h>
#include "GameConfig.h"
#include "ScoreTimerDisplay.h"
#include "ES_Framework.h"
#include "xc.h"
#include <assert.h>
#include <stdio.h>

#if NUM_SERVICES != 4
#error "This integration fixture requires the four-service final-game configuration."
#endif
HostUARTStatus U1STAbits;
uint32_t U1STACLR, U1RXREG;
static uint32_t clock_ms;
static uint32_t (*pan_clock)(void),refresh_at;
static bool pan_refreshing, pan_fault;
static bool pan_send(bool data,const uint8_t *p,size_t n) {
    assert(p && n && n<=32);
    if(!data && *p==0x12) { refresh_at=clock_ms; pan_refreshing=true; }
    return true;
}
static EInkBusState pan_poll(void) { return pan_fault?EINK_BUS_FAULT:EINK_BUS_IDLE; }
static void pan_reset(bool high) { (void)high; }
static bool pan_busy(void) { return !pan_refreshing || (uint32_t)(pan_clock()-refresh_at)>=3000u; }
const EInkAsyncPort *ButtonEInkPort_Init(uint32_t (*clock)(void)) {
    static EInkAsyncPort port;
    pan_clock=clock; port=(EInkAsyncPort){pan_send,pan_poll,pan_reset,pan_busy,clock}; return &port;
}

/* --- Actuator fakes (Treat.c / Stirrer.c / Servo50Hz.c are PIC32-only). --- */
static bool treat_rotated, stir_off, stir_activity, stir_cooking;
static unsigned treat_releases, treat_closes, treat_services, treat_start_closes;
static char treat_key;
void Servo50Hz_Init(void) {}
bool Servo50Hz_Write(Servo50Hz_Channel c,uint16_t us) { (void)c; return us>=SERVO50HZ_MIN_US && us<=SERVO50HZ_MAX_US; }
void Servo50Hz_Disable(Servo50Hz_Channel c) { (void)c; }
bool Servo50Hz_Routed(void) { return true; }
void Treat_Init(uint32_t now) { (void)now; treat_rotated=false; }
void Treat_Release(uint32_t now) { (void)now; ++treat_releases; treat_rotated=true; }
void Treat_CloseIfRotated(uint32_t now) { (void)now; if(treat_rotated) { ++treat_closes; treat_rotated=false; } }
void Treat_Close(uint32_t now) { (void)now; ++treat_start_closes; treat_rotated=false; }
bool Treat_Rotated(void) { return treat_rotated; }
void Treat_Service(uint32_t now) { (void)now; ++treat_services; }
bool Treat_Key(char key,uint32_t now) { (void)now; treat_key=key; return key=='o'||key=='c'||key=='+'||key=='-'; }
void Stirrer_Init(uint32_t now) { (void)now; }
void Stirrer_Service(uint32_t now,bool cooking) { (void)now; stir_cooking=cooking; }
bool Stirrer_OffCentre(void) { return stir_off; }
bool Stirrer_TakeActivity(void) { bool a=stir_activity; stir_activity=false; return a; }
uint16_t Stirrer_RawX(void) { return 512; }
uint16_t Stirrer_PulseUs(void) { return STIR_PULSE_CENTER_US; }
void Stirrer_Report(void) {}

/* --- LED strip fake: tracks which screen owns the strips. --- */
static enum { D_BANNER, D_DASH, D_END, D_BIG } dmode;
static char banner_text[80], top_text[80], bottom_text[16], big_text[16];
static int banner_x, top_x;
static uint32_t end_msg_at, big_at;
static unsigned remaining, score;
static bool display_fault;
bool ScoreTimerDisplay_Init(const ScoreTimerDisplay_Config *c) { return c != 0; }
ScoreTimerDisplay_State ScoreTimerDisplay_Service(void) { return display_fault?SCORE_TIMER_FAULT:SCORE_TIMER_IDLE; }
bool ScoreTimerDisplay_ShowLabels(void) { dmode = D_DASH; return true; }
bool ScoreTimerDisplay_SetScore(int32_t n) { assert(dmode == D_DASH && n >= 0 && n <= 999); score = (unsigned)n; return true; }
bool ScoreTimerDisplay_SetTimerSeconds(uint32_t n) { assert(dmode == D_DASH && n <= 60); remaining = n; return true; }
bool ScoreTimerDisplay_SetBanner(const char *s, int16_t x)
{
    assert(s && x >= -(int)strlen(s) * 8 && x <= 32 && strlen(s) < sizeof banner_text);
    if (s[0] >= '0' && s[0] <= '9') {
        /* Big final score: centred digits across both strips. */
        assert(dmode == D_END || dmode == D_BIG);
        assert(x == (32 - (int)strlen(s) * 8) / 2);
        if (dmode != D_BIG) big_at = clock_ms;
        dmode = D_BIG; strcpy(big_text, s);
    } else {
        dmode = D_BANNER; strcpy(banner_text, s); banner_x = x;
    }
    return true;
}
bool ScoreTimerDisplay_SetStripBanner(ScoreTimerDisplay_Panel panel, const char *s, int16_t x)
{
    assert(s && (dmode == D_DASH || dmode == D_END) && x <= 32 && x >= -(int)strlen(s) * 8);
    dmode = D_END;
    if (panel == DISPLAY_TOP) {
        assert(strlen(s) < sizeof top_text);
        if (x == 32) end_msg_at = clock_ms;
        strcpy(top_text, s); top_x = x;
    } else {
        assert(panel == DISPLAY_BOTTOM && strlen(s) < sizeof bottom_text);
        assert(x == (32 - (int)strlen(s) * 8) / 2);
        strcpy(bottom_text, s);
    }
    return true;
}

/* --- ES fakes: 4 queues, timers routed like ES_Configure.h. --- */
static struct { ES_Event_t events[32]; unsigned head, count; } queues[4];
static struct { bool active; uint32_t due; } timers[16];
uint16_t ES_Timer_GetTime(void) { return (uint16_t)clock_ms; }
uint8_t Terminal_ReadByte(void)
{
    assert(U1STAbits.URXDA); U1STAbits.URXDA = 0; return (uint8_t)U1RXREG;
}
void Terminal_MoveBuffer2UART(void) {}
bool ES_PostToService(uint8_t priority, ES_Event_t event)
{
    assert(priority < 4);
    if (queues[priority].count == 32) return false;
    queues[priority].events[(queues[priority].head + queues[priority].count++) % 32] = event;
    return true;
}
ES_TimerReturn_t ES_Timer_InitTimer(uint8_t timer, uint16_t delay)
{
    assert(timer < 16 && delay > 0);
    timers[timer].active = true; timers[timer].due = clock_ms + delay;
    return ES_Timer_OK;
}
ES_TimerReturn_t ES_Timer_StopTimer(uint8_t timer)
{
    assert(timer < 16); timers[timer].active = false; return ES_Timer_OK;
}
static bool dispatch(unsigned p)
{
    assert(queues[p].count);
    ES_Event_t event = queues[p].events[queues[p].head];
    queues[p].head = (queues[p].head + 1) % 32; --queues[p].count;
    ES_Event_t result = p == 3 ? SERV_3_RUN(event) : p == 2 ? SERV_2_RUN(event) :
                        p == 1 ? SERV_1_RUN(event) : SERV_0_RUN(event);
    if (result.EventType == ES_ERROR) return false;
    assert(result.EventType == ES_NO_EVENT);
    return true;
}
static bool drain(void)
{
    unsigned guard = 400;
    while (queues[0].count || queues[1].count || queues[2].count || queues[3].count) {
        assert(guard--);
        unsigned p = queues[3].count ? 3 : queues[2].count ? 2 : queues[1].count ? 1 : 0;
        if (!dispatch(p)) return false;
    }
    return true;
}
static void tick(void)
{
    ++clock_ms;
    /* Deliberately queue idle before game tick at simultaneous expiration. */
    for (int t = 15; t >= 0; --t) {
        if (timers[t].active && clock_ms == timers[t].due) {
            timers[t].active = false;
            ES_Event_t e = {ES_TIMEOUT, (uint16_t)t};
            assert(t == COOK_TICK_TIMER ? PostCookSM(e) : PostGameSM(e));
        }
    }
}

/* --- PIC2 side: real ButtonSensor + PeerLink over an in-memory UART. --- */
static ButtonSensor sensor;
static uint8_t gpio=0xff;
static bool connected=true;
static const uint16_t *hand_pattern; /* mm every 100 ms, cycling; 0 entry = invalid */
static unsigned hand_len, hand_index;
static struct { uint8_t bytes[4096]; unsigned count; } to_pic1,to_pic2;
static uint32_t sensor_now(void *unused) { (void)unused; return clock_ms; }
static bool sensor_send(const uint8_t *data,size_t size,void *unused) {
    (void)unused;
    if(!connected) return true;
    assert(size+to_pic1.count<=sizeof to_pic1.bytes);
    memcpy(to_pic1.bytes+to_pic1.count,data,size); to_pic1.count+=(unsigned)size; return true;
}
void PeerUart_Init(void) {}
PeerUartStats PeerUart_GetStats(void) { return (PeerUartStats){0}; }
PeerUartDiagnostics PeerUart_GetDiagnostics(void) {
    return (PeerUartDiagnostics){.loopback_passed=true};
}
bool PeerUart_Send(const uint8_t *data,size_t size,void *unused) {
    (void)unused;
    if(!connected) return true;
    assert(size+to_pic2.count<=sizeof to_pic2.bytes);
    memcpy(to_pic2.bytes+to_pic2.count,data,size); to_pic2.count+=(unsigned)size; return true;
}
void PeerUart_Service(PeerLink *controller) {
    for(unsigned i=0;i<to_pic2.count;i++) PeerLink_ReceiveByte(&sensor.link,to_pic2.bytes[i]);
    to_pic2.count=0;
    for(unsigned i=0;i<to_pic1.count;i++) PeerLink_ReceiveByte(controller,to_pic1.bytes[i]);
    to_pic1.count=0;
}
static bool cycle(void) {
    tick();
    ButtonSensor_Sample(&sensor,gpio);
    if(hand_len && clock_ms%100u==0) {
        uint16_t mm=hand_pattern[hand_index++%hand_len];
        (void)ButtonSensor_SendRange(&sensor,mm,mm!=0,clock_ms);
    }
    PeerLink_Service(&sensor.link);
    CheckGameBenchIO();
    return drain();
}
static void step(uint32_t duration) { while(duration--) assert(cycle()); }
static void send_key(char c) { U1STAbits.URXDA=1; U1RXREG=(uint8_t)c; CheckGameBenchIO(); }
static void key(char c) { send_key(c); assert(drain()); }
static void press(uint8_t bit) { gpio&=(uint8_t)~bit; step(150); }
static void release(uint8_t bit) { gpio|=bit; step(150); }
static void hand(const uint16_t *pattern,unsigned n) { hand_pattern=pattern; hand_len=n; hand_index=0; }
static bool cooking(void) {
    return QueryGameSM()==GAME_COOKING_EARLY || QueryGameSM()==GAME_COOKING_FINISHABLE;
}
static uint32_t cooking_start;
static void begin(void) {
    assert(QueryGameSM()==GAME_WELCOME);
    assert(!ButtonSensor_Lamp(&sensor));
    assert(ButtonSensor_StartLamp(&sensor));
    release(0xa0);
    gpio&=(uint8_t)~0x80u;
    unsigned guard=150, start_closes=treat_start_closes;
    while(QueryGameSM()==GAME_WELCOME) { assert(guard--); step(1); }
    uint32_t intro_at=clock_ms;
    assert(QueryGameSM()==GAME_DISH_INTRO && dmode==D_BANNER && !strcmp(banner_text,DISH_TEXT));
    assert(treat_start_closes==start_closes+1 && !treat_rotated); /* Every game starts closed. */
    step(150);
    assert(!ButtonSensor_StartLamp(&sensor));
    assert(!ButtonSensor_Lamp(&sensor));
    release(0x80);
    while(QueryGameSM()==GAME_DISH_INTRO) step(1);
    /* 2x scroll: one 312-column pass at 25 ms = 7.8 s. */
    assert(clock_ms-intro_at>=DISH_INTRO_MS && clock_ms-intro_at<=DISH_INTRO_MS+1u);
    assert(DISH_INTRO_MS==7800u);
    assert(QueryGameSM()==GAME_COOKING_EARLY && remaining==60 && dmode==D_DASH && score==0);
    cooking_start=clock_ms;
    step(400); /* Session sync then a stable release arms new physical edges. */
    assert(PeerLink_IsSynchronized(&sensor.link));
}
static void elapsed(uint32_t ms) {
    assert(clock_ms-cooking_start<=ms);
    step(ms-(clock_ms-cooking_start));
}
static void wait_welcome(uint32_t limit) {
    while(QueryGameSM()!=GAME_WELCOME) { assert(limit--); step(1); }
}
static void control_matches_cook(void) {
    CookOutput_t c=CookSM_Output();
    PeerControl p=ButtonSensor_Control(&sensor);
    assert(p.audio_enabled==c.sizzle && p.audio_zone==(uint8_t)c.zone);
    assert(p.lcd_mode==(uint8_t)c.lcd_mode && p.burnt==c.burnt);
    assert(p.burn_seq==c.burn_seq && p.target_cm==c.target_cm);
}
static void console_noise(void) {
    /* Even a corrupted byte that looks like an ingredient must be ignored. */
    for(unsigned kind=0;kind<3;++kind) {
        U1RXREG='1'; U1STAbits.URXDA=1;
        U1STAbits.FERR=kind==0; U1STAbits.PERR=kind==1; U1STAbits.OERR=kind==2;
        assert(cycle());
        assert(!U1STAbits.URXDA);
        if(kind==2) assert(U1STACLR==_U1STA_OERR_MASK);
        /* Host SFR writes have no hardware side effects. */
        U1STAbits=(HostUARTStatus){0};
        assert(!strcmp(GameButtons_FaultReason(),"NONE"));
    }
}

static void test_welcome_scroll(void) {
    assert(QueryGameSM()==GAME_WELCOME && dmode==D_BANNER && !strcmp(banner_text,WELCOME_TEXT));
    int x0=banner_x; step(250);
    assert(x0-banner_x==10); /* 25 ms per column. */
    puts("PASS: Welcome scrolls at 2x (25 ms per column)");
}

static void test_finish_flow(void) {
    key('b'); key('f'); assert(QueryGameSM()==GAME_WELCOME); /* Physical-only Start/Finish. */
    release(0x80);
    gpio=0x7f; step(5); gpio=0xff; step(5); gpio=0x7f; step(5); gpio=0xff; step(100);
    assert(QueryGameSM()==GAME_WELCOME); /* Contact bounce has no edge. */
    unsigned releases=treat_releases, closes=treat_closes;
    begin();
    assert(stir_cooking && CookSM_Output().lcd_mode==COOK_LCD_WAITING);
    control_matches_cook();
    elapsed(10000); press(1u); assert(score==10);
    assert(ButtonEInk_Status().desired==1u);
    step(200); control_matches_cook();
    assert(ButtonSensor_Control(&sensor).lcd_mode==COOK_LCD_ZONE &&
           ButtonSensor_Control(&sensor).target_cm==14);
    release(1u); assert(ButtonEInk_Status().desired==1u); /* OFF keeps the icon. */
    press(1u); assert(score==10); /* Duplicate ON is activity, never extra points. */
    elapsed(20000); key('a');
    elapsed(29000); press(0x20); /* Early Finish is ignored. */
    assert(QueryGameSM()==GAME_COOKING_EARLY && !ButtonSensor_Lamp(&sensor));
    elapsed(29999); assert(!ButtonSensor_Lamp(&sensor));
    elapsed(30000); assert(QueryGameSM()==GAME_COOKING_FINISHABLE);
    step(150); assert(ButtonSensor_Lamp(&sensor));
    step(2000); assert(QueryGameSM()==GAME_COOKING_FINISHABLE); /* Holding cannot auto-finish. */
    release(0x20); press(0x20);
    /* End message: GAME OVER on top, score on the bottom; icons stay. */
    assert(QueryGameSM()==GAME_OVER && !ButtonSensor_Lamp(&sensor));
    assert(!ButtonSensor_StartLamp(&sensor) && dmode==D_END);
    assert(!strcmp(top_text,END_FINISH_TEXT) && !strcmp(bottom_text,"10"));
    assert(ButtonEInk_Status().desired==1u && !ButtonEInk_Status().clearing);
    while(dmode==D_END) step(1);
    assert(big_at-end_msg_at==(32u+9u*8u)*WELCOME_SCROLL_MS); /* 2.6 s */
    assert(dmode==D_BIG && !strcmp(big_text,"10") && QueryGameSM()==GAME_OVER);
    assert(ButtonEInk_Status().desired==0 && ButtonEInk_Status().clearing);
    assert(treat_releases==releases); /* 10 < 50: no treat. */
    step(2990); assert(QueryGameSM()==GAME_OVER);
    wait_welcome(20);
    assert(clock_ms-big_at==END_SCORE_MS && dmode==D_BANNER);
    assert(treat_releases==releases && treat_closes==closes); /* Untouched. */
    step(150); assert(!ButtonSensor_Lamp(&sensor) && ButtonSensor_StartLamp(&sensor));
    step(4000); assert(ButtonEInk_Status().known && ButtonEInk_Status().shown==0);
    release(0x21);
    puts("PASS: Finish -> GAME OVER top / score bottom -> big score 3 s -> Welcome, no treat below 50");
}

static void test_timeout_treat(void) {
    begin();
    /* Protein, Carb, Spice, Oil: 40; oil's zero stirring adds +10 at End -> 50. */
    elapsed(5000); press(1u); press(2u); press(8u); press(16u);
    assert(score==40);
    for(unsigned t=15000;t<=55000;t+=10000) { elapsed(t); key('a'); }
    elapsed(59999); assert(cooking());
    elapsed(60000); assert(QueryGameSM()==GAME_OVER && remaining==0);
    assert(!strcmp(top_text,END_TIMEUP_TEXT));
    assert(!strcmp(bottom_text,"40") || !strcmp(bottom_text,"50"));
    assert(ButtonEInk_Status().desired==0x1bu);
    unsigned releases=treat_releases;
    while(dmode==D_END) step(1);
    assert(big_at-end_msg_at==(32u+20u*8u)*WELCOME_SCROLL_MS); /* 4.8 s */
    assert(!strcmp(big_text,"50") && treat_releases==releases+1 && treat_rotated);
    assert(ButtonEInk_Status().desired==0);
    unsigned closes=treat_closes;
    wait_welcome(END_SCORE_MS+5);
    assert(treat_closes==closes+1 && !treat_rotated); /* Closed only because it rotated. */
    step(4000); release(0x1b);
    puts("PASS: 60 s -> TIME'S UP. GAME OVER (4.8 s), treat at big score >= 50, closed at Welcome");
}

static void test_late_points(void) {
    /* Oil (ideal stir 0 s) earns its stir score at End, after the message starts. */
    begin(); elapsed(5000); press(16u); assert(score==10);
    for(unsigned t=15000;t<=25000;t+=10000) { elapsed(t); key('a'); }
    elapsed(30200); release(0x20); press(0x20);
    assert(QueryGameSM()==GAME_OVER && !strcmp(top_text,END_FINISH_TEXT));
    assert(ScoreSM_Value()==20 && !strcmp(bottom_text,"20") && dmode==D_END);
    while(dmode==D_END) step(1);
    assert(!strcmp(big_text,"20"));
    wait_welcome(END_SCORE_MS+5); step(4000); release(0x30);
    puts("PASS: late End points update the bottom strip and never overwrite end screens");
}

static void test_idle(void) {
    unsigned releases=treat_releases;
    begin(); press(1u); /* ON at ~0.4 s of cooking is activity. */
    elapsed(20300); assert(cooking() && ButtonEInk_Status().desired==1u);
    elapsed(20600);
    assert(QueryGameSM()==GAME_WELCOME && dmode==D_BANNER && treat_releases==releases);
    step(150); assert(!ButtonSensor_Lamp(&sensor));
    assert(ButtonSensor_StartLamp(&sensor) && ButtonEInk_Status().desired==0);
    /* OFF after a held ingredient is activity, without adding that ingredient
     * to the new round. The idle deadline must move by another 20 seconds. */
    begin(); elapsed(19000); release(1u); elapsed(21000);
    assert(QueryGameSM()==GAME_COOKING_EARLY && ButtonEInk_Status().desired==0);
    elapsed(39200); assert(QueryGameSM()==GAME_WELCOME); step(200);
    /* Early Finish presses are not activity. */
    begin(); elapsed(10000); press(0x20); release(0x20);
    elapsed(19900); assert(cooking());
    elapsed(20100); assert(QueryGameSM()==GAME_WELCOME && treat_releases==releases);
    step(200);
    puts("PASS: idle -> Welcome with no treat; ingredient OFF is activity; early Finish is not");
}

static void test_activity_sources(void) {
    /* Pan flip (MCP GPA6, input id 6): activity; +2 only with food in the pan. */
    begin(); elapsed(10000); press(0x40); release(0x40);
    assert(score==0 && cooking());
    elapsed(29500); assert(cooking()); /* Flip at ~10 s renewed idle. */
    press(1u); press(0x40); release(0x40); assert(score==12);
    elapsed(49000); assert(cooking()); /* Last flip at ~29.8 s. */
    wait_welcome(2000); step(200); release(1u);

    /* Joystick move beyond the threshold is activity. */
    begin(); elapsed(15000); stir_activity=true; step(1); assert(!stir_activity);
    elapsed(34500); assert(cooking());
    elapsed(35500); assert(QueryGameSM()==GAME_WELCOME && !stir_cooking); step(200);

    /* A held hand (3 readings in range) keeps the game alive. */
    static const uint16_t steady[]={200}, flicker[]={200,200,450}, far[]={450}, near[]={20};
    begin(); elapsed(5000); hand(steady,1); elapsed(5500);
    uint16_t mm=0;
    assert(GameButtons_DistanceMm(&mm) && mm==200);
    elapsed(30000); hand(0,0);
    step(400); assert(!GameButtons_DistanceMm(&mm)); /* Stale after 350 ms. */
    elapsed(49500); assert(cooking());
    elapsed(50500); assert(QueryGameSM()==GAME_WELCOME); step(200);
    /* Two in range then out never reaches three in a row; out of range is no hand. */
    begin(); hand(flicker,3); elapsed(19900); assert(cooking());
    elapsed(20100); assert(QueryGameSM()==GAME_WELCOME); step(200);
    begin(); hand(far,1); elapsed(5000); assert(!GameButtons_DistanceMm(&mm));
    hand(near,1); elapsed(10000); assert(!GameButtons_DistanceMm(&mm));
    elapsed(20100); assert(QueryGameSM()==GAME_WELCOME); hand(0,0); step(200);
    puts("PASS: activity from flip id 6, joystick, held hand; flicker/out-of-range hand is not");
}

static void test_recipe(void) {
    begin(); elapsed(5000);
    press(4u); assert(ScoreSM_Value()==0 && score==0); /* Vegetables wrong: floored. */
    press(1u); assert(ScoreSM_Value()==10 && score==10);
    elapsed(20000); key('a'); elapsed(30200); release(0x20); press(0x20);
    wait_welcome(10000); step(4000); release(0x05);
    puts("PASS: recipe vegetables first -> 0 (floored), then protein -> 10");
}

static void test_link_recovery(void) {
    unsigned releases=treat_releases;
    begin(); elapsed(10000); press(1u); key('a'); elapsed(20000); key('a'); elapsed(30150);
    assert(ButtonSensor_Lamp(&sensor));
    connected=false;
    /* 600 ms link timeout, then the 1.2 s resync grace before aborting. */
    for(unsigned n=0;n<3000 && QueryGameSM()!=GAME_WELCOME;n++) assert(cycle());
    assert(QueryGameSM()==GAME_WELCOME && !GameSM_HasFault());
    assert(!strcmp(GameButtons_FaultReason(),"NONE"));
    assert(!strcmp(GameButtons_RecoveredReason(),"PEER_SYNC_TIMEOUT"));
    assert(treat_releases==releases && ButtonEInk_Status().desired==0);
    step(2000); assert(QueryGameSM()==GAME_WELCOME);
    connected=true; step(3000);
    assert(PeerLink_IsSynchronized(&sensor.link) && ButtonSensor_StartLamp(&sensor));
    release(1u);
    /* Link loss during the end sequence also returns to Welcome. */
    begin(); elapsed(10000); key('a'); elapsed(20000); key('a'); elapsed(30150);
    release(0x20); press(0x20); assert(QueryGameSM()==GAME_OVER);
    connected=false;
    for(unsigned n=0;n<3000 && QueryGameSM()!=GAME_WELCOME;n++) assert(cycle());
    assert(QueryGameSM()==GAME_WELCOME && !strcmp(GameButtons_FaultReason(),"NONE"));
    connected=true; step(3000);
    assert(ButtonSensor_StartLamp(&sensor));
    begin(); assert(cooking()); wait_welcome(25000);
    /* A momentary dropout (both sides time out, then resync within the grace)
     * must not end the round. */
    step(500); begin(); elapsed(5000); key('a');
    connected=false; step(700); connected=true; step(1500);
    assert(cooking() && PeerLink_IsSynchronized(&sensor.link) && !GameSM_HasFault());
    wait_welcome(25000);
    puts("PASS: link loss mid-cooking / end sequence -> Welcome after grace; momentary dropout keeps the round");
}

static void test_eink_fault(void) {
    step(300); begin(); pan_fault=true; elapsed(5000); press(1u); elapsed(8000);
    assert(ButtonEInk_Status().fault && cooking());
    elapsed(15000); key('a'); elapsed(30200); release(0x20); press(0x20);
    assert(QueryGameSM()==GAME_OVER); wait_welcome(10000);
    assert(!strcmp(GameButtons_FaultReason(),"NONE"));
    step(200); release(1u); begin(); assert(cooking());
    puts("PASS: E-ink transfer fault is logged once; the game keeps running");
}

int main(int argc,char **argv) {
    ButtonSensor_Init(&sensor,sensor_now,sensor_send,0);
    gpio=0x7f; /* Held Start while both processors boot. */
    assert(GameBenchIO_Init());
    assert(SERV_0_INIT(0)); assert(SERV_1_INIT(1)); assert(SERV_2_INIT(2)); assert(SERV_3_INIT(3));
    assert(drain());
    if(argc>1 && !strcmp(argv[1],"no-peer")) {
        connected=false; step(20000);
        assert(QueryGameSM()==GAME_WELCOME && dmode==D_BANNER);
        assert(!strcmp(GameButtons_FaultReason(),"NONE"));
        assert(ButtonSensor_Outputs(&sensor)==0);
        puts("Welcome continues when PIC2 sends no UART2 data."); return 0;
    }
    step(2000);
    assert(treat_services>1000); /* Serviced every pass. */
    if(argc>1) {
        if(!strcmp(argv[1],"uart-noise")) {
            console_noise(); step(100);
            assert(QueryGameSM()==GAME_WELCOME && ButtonSensor_StartLamp(&sensor));
            begin(); elapsed(10000);
            console_noise(); step(100);
            assert(QueryGameSM()==GAME_COOKING_EARLY && score==0);
            assert(ButtonEInk_Status().desired==0);
            key('1'); step(100);
            assert(score==10 && ButtonEInk_Status().desired==1u);
            key('o'); assert(treat_key=='o'); /* Unused keys reach Treat calibration. */
            elapsed(25000); key('a'); elapsed(30150); press(0x20);
            assert(QueryGameSM()==GAME_OVER && !ButtonSensor_Lamp(&sensor));
            puts("Console framing/parity/overrun noise is discarded; keyboard and physical Start/Finish still work.");
            return 0;
        }
        assert(!strcmp(argv[1],"display-fault"));
        display_fault=true;
        assert(!cycle() && QueryGameSM()==GAME_FAULT);
        assert(!strcmp(GameButtons_FaultReason(),"STATUS_DISPLAY_SPI"));
        GameButtons_Stop(); /* Generic cleanup must never overwrite the cause. */
        assert(!strcmp(GameButtons_FaultReason(),"STATUS_DISPLAY_SPI"));
        puts("First fault survives GameSM/cleanup propagation."); return 0;
    }
    assert(PeerLink_IsSynchronized(&sensor.link));
    assert(QueryGameSM()==GAME_WELCOME && !ButtonSensor_Lamp(&sensor));
    assert(ButtonSensor_StartLamp(&sensor));
    test_welcome_scroll();
    test_finish_flow();
    test_timeout_treat();
    test_late_points();
    test_idle();
    test_activity_sources();
    test_recipe();
    test_link_recovery();
    test_eink_fault();
    assert(!strcmp(GameButtons_FaultReason(),"NONE"));
    puts("Physical game integration passed: 2x scroll, end sequence, treat, idle, activity, recipe, link recovery.");
    return 0;
}
