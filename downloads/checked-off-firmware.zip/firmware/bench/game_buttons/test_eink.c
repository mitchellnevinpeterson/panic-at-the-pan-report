/* Real scheduler, canvas and asynchronous IL0373 sequence; fake SPI/BUSY. */
#include "ButtonEInk.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static uint32_t ms,refreshed_at;
static bool refreshing,bus_fault,busy_stuck;
static uint8_t command;
static unsigned frames,white_frames;
static size_t plane_bytes;
static bool frame_white;
static uint32_t now(void) { return ms; }
static void reset(bool high) { (void)high; }
static bool busy(void) { return !busy_stuck && (!refreshing || (uint32_t)(ms-refreshed_at)>=3000); }
static EInkBusState poll(void) { return bus_fault?EINK_BUS_FAULT:EINK_BUS_IDLE; }
static bool send(bool data,const uint8_t *p,size_t n) {
    assert(n && n<=32);
    if(!data) {
        command=*p;
        if(command==0x10) { frame_white=true; plane_bytes=0; }
        if(command==0x12) {
            assert(plane_bytes==2*EINK_PLANE_BYTES);
            ++frames; if(frame_white) ++white_frames;
            refreshing=true; refreshed_at=ms;
        }
    } else if(command==0x10 || command==0x13) {
        for(size_t i=0;i<n;i++) if(p[i]!=0xff) frame_white=false;
        plane_bytes+=n;
    }
    return true;
}
static void setup(uint32_t at) {
    ms=at; frames=white_frames=0; refreshing=bus_fault=busy_stuck=false;
    const EInkAsyncPort io={send,poll,reset,busy,now}; assert(ButtonEInk_Init(&io));
}
static void step(unsigned n) { while(n--) { ++ms; assert(ButtonEInk_Service()); } }
static void settle(void) {
    for(unsigned i=0;i<20000;i++) {
        step(1); ButtonEInkStatus s=ButtonEInk_Status();
        if(s.known && !s.clearing && !s.building && !s.refreshing && s.shown==s.desired) return;
    }
    assert(!"pan did not settle");
}
int main(void) {
    setup(0); settle();
    assert(frames==1 && white_frames==1 && ButtonEInk_Status().shown==0);
    ButtonEInk_Add(0); ButtonEInk_Add(1); ButtonEInk_Add(0); settle();
    assert(frames==2 && white_frames==1 && ButtonEInk_Status().shown==3);
    ButtonEInk_Clear(); settle(); assert(frames==3 && white_frames==2);
    ButtonEInk_Clear(); step(10000); assert(frames==3); /* Already white. */

    /* Finish during a real icon transfer. New-round additions must wait for
     * an intervening white frame, even though they supersede desired=0. */
    ButtonEInk_Add(2);
    while(!ButtonEInk_Status().refreshing) step(1);
    ButtonEInk_Clear(); ButtonEInk_Add(4);
    settle(); assert(frames==6 && white_frames==3 && ButtonEInk_Status().shown==16);

    /* Cancel an obsolete canvas before any SPI refresh starts. */
    ButtonEInk_Clear(); settle(); step(3000);
    unsigned before=frames; ButtonEInk_Add(0);
    step(BUTTON_EINK_BATCH_MS-1); assert(!ButtonEInk_Status().building);
    step(1); assert(ButtonEInk_Status().building); ButtonEInk_Clear(); settle();
    assert(frames==before && ButtonEInk_Status().shown==0);

    /* Switches flipped in a quick burst share one refresh. The first icon
     * must not be drawn alone while the rest wait a whole refresh+cooldown. */
    setup(0); settle(); step(3000);
    ButtonEInk_Add(0); step(400); ButtonEInk_Add(1); step(400); ButtonEInk_Add(2);
    settle(); assert(frames==2 && white_frames==1 && ButtonEInk_Status().shown==7);

    setup(UINT32_MAX-1500u); ButtonEInk_Add(1); settle();
    assert(frames==2 && white_frames==1 && ButtonEInk_Status().shown==2);
    ButtonEInk_Clear(); bus_fault=true;
    bool failed=false;
    for(unsigned i=0;i<10000 && !failed;i++) { ++ms; failed=!ButtonEInk_Service(); }
    assert(failed && !ButtonEInk_Service());
    assert(ButtonEInk_Status().fault && !ButtonEInk_Status().refreshing);
    setup(0); busy_stuck=true; failed=false;
    for(unsigned i=0;i<20000 && !failed;i++) { ++ms; failed=!ButtonEInk_Service(); }
    assert(failed && !ButtonEInk_Service());
    assert(ButtonEInk_Status().fault && !ButtonEInk_Status().refreshing);
    puts("Game E-ink tests passed: boot white, coalescing, clear barrier, canvas cancellation, clock wrap, SPI/BUSY faults.");
}
