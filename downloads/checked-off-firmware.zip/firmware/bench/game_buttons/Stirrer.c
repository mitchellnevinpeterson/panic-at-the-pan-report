#include "Stirrer.h"
#include "../joystick_servo_2/Follower.h"
#include "JoystickADC.h"
#include "Servo50Hz.h"
#include "SpoonServo.h"         /* Follower_Init's pulse bounds */
#include <stdio.h>

/* The joystick's resting position is LEARNED, not assumed to be 512: on the
 * bench this stick rests near X=330, which never armed the old fixed-centre
 * follower (spoon never moved) and counted as constant stirring.
 * "Moving" (stir time + idle activity) is a CHANGE of stick direction: the
 * angle around the learned centre changes by >= 8 degrees, or the stick leaves
 * or returns to the centre zone (so side-to-side pushes through the centre
 * count too). Holding the stick still, centred or deflected, is not moving. */
#define SAMPLE_MS 10u
#define DEADBAND 40u
#define STABLE_COUNTS 8         /* "still" = within +/-8 counts on both axes */
#define LEARN_MS 300u           /* still this long at boot -> centre */
#define RELEARN_MS 3000u        /* still this long while not cooking -> re-centre */
#define LEARN_TIMEOUT_MS 3000u  /* no stillness at boot: use the running average */
#define CENTRE_RADIUS 60        /* counts; inside = centre zone */
#define ANGLE_SIN2_X10000 194   /* sin^2(8 deg) = 0.0194 */
#define MOVE_HOLD_MS 300u       /* stir time keeps counting this long after a move */
#define CENTRE_MIN 200u         /* keeps Follower_Init's band checks valid */
#define CENTRE_MAX 823u
/* Each side's full-travel point is the farthest X actually reached, starting
 * at centre +/-120 and growing as the stick is pushed. On the bench the spoon
 * reached full travel one way only: this stick's two sides span very
 * different counts (rest ~330), so a fixed 0/1023 end left one side short. */
#define RANGE_START 120u

typedef char stir_pulse_bounds_ok[(STIR_PULSE_MIN_US >= SPOON_SERVO_MIN_US &&
    STIR_PULSE_MIN_US < STIR_PULSE_CENTER_US && STIR_PULSE_CENTER_US < STIR_PULSE_MAX_US &&
    STIR_PULSE_MAX_US <= SPOON_SERVO_MAX_US) ? 1 : -1];

static Follower follower;
static Follower_Config config;
static uint32_t last_start, last_sample, last_service, boot_ms, last_move, still_since;
static uint16_t raw_x = 512u, raw_y = 512u, centre_x = 512u, centre_y = 512u;
static uint16_t pulse_us = STIR_PULSE_CENTER_US, still_x, still_y;
static uint32_t still_sum_x, still_sum_y, still_n;
static int32_t ref_dx, ref_dy;
static bool fresh, learned, was_out, moved, activity, have_still;

static void restart_adc(uint32_t now_ms)
{
    JoystickADC_Init();
    last_start = now_ms - SAMPLE_MS;    /* start again on the next pass */
}

static void use_centre(uint16_t cx, uint16_t cy, uint32_t now_ms)
{
    if (cx < CENTRE_MIN) cx = CENTRE_MIN;
    if (cx > CENTRE_MAX) cx = CENTRE_MAX;
    centre_x = cx;
    centre_y = cy;
    config = (Follower_Config){
        .adc_min = (uint16_t)(cx - RANGE_START), .adc_center = cx,
        .adc_max = (uint16_t)(cx + RANGE_START), .deadband = DEADBAND,
        .pulse_min_us = STIR_PULSE_MIN_US, .pulse_center_us = STIR_PULSE_CENTER_US,
        .pulse_max_us = STIR_PULSE_MAX_US, .slew_us_per_step = 10, .reverse = false
    };
    (void)Follower_Init(&follower, &config, now_ms);
    learned = true;
    was_out = false;
    printf("STIR centre learned x=%u y=%u\r\n", (unsigned)cx, (unsigned)cy);
}

void Stirrer_Init(uint32_t now_ms)
{
    restart_adc(now_ms);
    raw_x = raw_y = centre_x = centre_y = 512u;
    fresh = learned = was_out = moved = activity = have_still = false;
    boot_ms = last_sample = last_service = now_ms;
    still_n = 0;
    pulse_us = STIR_PULSE_CENTER_US;
    (void)Servo50Hz_Write(SERVO_SPOON, pulse_us);
}

static void move(uint32_t now_ms)
{
    moved = true;
    last_move = now_ms;
    activity = true;
}

static bool angle_changed(int32_t ax, int32_t ay, int32_t bx, int32_t by)
{
    /* |delta angle| >= 8 deg  <=>  dot <= 0  or  cross^2 >= sin^2(8)*|a|^2*|b|^2. */
    int64_t dot = (int64_t)ax * bx + (int64_t)ay * by;
    int64_t cross = (int64_t)ax * by - (int64_t)ay * bx;
    int64_t a2 = (int64_t)ax * ax + (int64_t)ay * ay, b2 = (int64_t)bx * bx + (int64_t)by * by;
    return dot <= 0 || cross * cross * 10000 >= (int64_t)ANGLE_SIN2_X10000 * a2 * b2;
}

static void track_stillness(uint16_t x, uint16_t y, uint32_t now_ms, bool cooking)
{
    int dx = (int)x - (int)still_x, dy = (int)y - (int)still_y;
    if (!have_still || dx > STABLE_COUNTS || dx < -STABLE_COUNTS ||
        dy > STABLE_COUNTS || dy < -STABLE_COUNTS) {
        have_still = true;
        still_x = x; still_y = y; still_since = now_ms;
        still_sum_x = still_sum_y = still_n = 0;
    }
    still_sum_x += x; still_sum_y += y; ++still_n;
    uint32_t still_ms = now_ms - still_since;
    uint16_t ax = (uint16_t)(still_sum_x / still_n), ay = (uint16_t)(still_sum_y / still_n);
    if (!learned) {
        if (still_ms >= LEARN_MS || (uint32_t)(now_ms - boot_ms) >= LEARN_TIMEOUT_MS)
            use_centre(ax, ay, now_ms);
    } else if (!cooking && still_ms >= RELEARN_MS) {
        int ddx = (int)ax - (int)centre_x, ddy = (int)ay - (int)centre_y;
        if (ddx > STABLE_COUNTS || ddx < -STABLE_COUNTS || ddy > STABLE_COUNTS || ddy < -STABLE_COUNTS)
            use_centre(ax, ay, now_ms);
        still_since = now_ms;           /* at most one re-centre per still period */
    }
}

static void detect_motion(uint16_t x, uint16_t y, uint32_t now_ms)
{
    int32_t dx = (int32_t)x - centre_x, dy = (int32_t)y - centre_y;
    bool out = dx * dx + dy * dy >= CENTRE_RADIUS * CENTRE_RADIUS;
    if (out) {
        if (!was_out || angle_changed(ref_dx, ref_dy, dx, dy)) {
            move(now_ms);
            ref_dx = dx; ref_dy = dy;
        }
    } else if (was_out) {
        move(now_ms);                   /* returned to centre */
    }
    was_out = out;
}

static void take_sample(uint16_t x, uint16_t y, uint32_t now_ms, bool cooking)
{
    raw_x = x; raw_y = y;
    fresh = true;
    last_sample = now_ms;
    track_stillness(x, y, now_ms, cooking);
    if (!learned) return;
    detect_motion(x, y, now_ms);
    /* Grow each side's end to the farthest X reached (live config: no re-arm). */
    if (x < config.adc_min) config.adc_min = follower.config.adc_min = x;
    if (x > config.adc_max) config.adc_max = follower.config.adc_max = x;
    Follower_Sample(&follower, x, y, now_ms);
}

void Stirrer_Service(uint32_t now_ms, bool cooking)
{
    uint16_t x, y;
    Follower_State state = FOLLOWER_WAIT_CENTER;
    last_service = now_ms;
    JoystickADC_State adc = JoystickADC_Poll(&x, &y);
    if (adc == JOYSTICK_ADC_READY) {
        take_sample(x, y, now_ms, cooking);
    } else if (adc == JOYSTICK_ADC_FAULT) {
        restart_adc(now_ms);            /* conversion timeout: recover, never latch */
    }
    if ((uint32_t)(now_ms - last_start) >= SAMPLE_MS && JoystickADC_Start()) {
        last_start = now_ms;
    }
    if ((uint32_t)(now_ms - last_sample) >= FOLLOWER_SAMPLE_TIMEOUT_MS) {
        fresh = false;                  /* stale samples must not count as stirring */
    }
    if (learned) {
        state = Follower_Service(&follower, now_ms);
        if (state == FOLLOWER_FAULT) {  /* sample timeout: re-arm around the centre */
            (void)Follower_Init(&follower, &config, now_ms);
            state = follower.state;
        }
    }
    pulse_us = (cooking && state == FOLLOWER_ACTIVE) ? follower.pulse_us : STIR_PULSE_CENTER_US;
    (void)Servo50Hz_Write(SERVO_SPOON, pulse_us);
}

bool Stirrer_OffCentre(void)
{
    /* Name kept for the CookSM port: true while the stick is MOVING. */
    return fresh && learned && moved && (uint32_t)(last_service - last_move) < MOVE_HOLD_MS;
}

bool Stirrer_TakeActivity(void)
{
    bool taken = activity;
    activity = false;
    return taken;
}

uint16_t Stirrer_RawX(void) { return raw_x; }
uint16_t Stirrer_PulseUs(void) { return pulse_us; }

void Stirrer_Report(void)
{
    static const char *const names[] = {"WAIT_CENTRE", "ACTIVE", "FAULT"};
    int dx = (int)raw_x - (int)centre_x, dy = (int)raw_y - (int)centre_y;
    printf("STIR x=%u y=%u centre=%u,%u range=%u..%u learned=%u dx=%d dy=%d zone=%s moving=%u follower=%s spoon=%uus\r\n",
           (unsigned)raw_x, (unsigned)raw_y, (unsigned)centre_x, (unsigned)centre_y,
           (unsigned)config.adc_min, (unsigned)config.adc_max, (unsigned)learned,
           dx, dy, was_out ? "OUT" : "CENTRE", (unsigned)Stirrer_OffCentre(),
           learned && follower.state <= FOLLOWER_FAULT ? names[follower.state] : "LEARNING",
           (unsigned)pulse_us);
}
