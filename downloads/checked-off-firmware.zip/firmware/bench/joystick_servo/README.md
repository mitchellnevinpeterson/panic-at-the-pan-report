# Joystick + spoon servo bench

**JoystickServoBench:** circle the joystick clockwise/counterclockwise to move the S51 positional servo in the corresponding direction. Both X and Y are used. Release to return home. This standalone image does not run StirSM or GameSM.

- A first outward push establishes a reference; then rotate around the joystick center. Holding the stick still holds the target after any pending movement settles.
- Travel stops at the configured endpoint. Extra circles do not accumulate; reversing starts travel back after the direction detector responds.
- This is limited servo travel, not continuous 360-degree rotation. Physical direction and travel still need calibration on the mounted servo.

## Wiring

Keep the PIC core, SNAP and two display strips. Power off before changing wiring. Numbers are physical DIP pins.

| Connection | Destination |
|---|---|
| Joystick VCC / GND | 3.3 V / common GND |
| Joystick VRx / VRy | PIC **6 / RB2 / AN4** and **7 / RB3 / AN5** |
| Joystick SW | Leave open |
| PIC **12 / RA4 / OC4** | 74ACT244 **input 17**; 10 kΩ pull-down from this signal to GND |
| 74ACT244 **output 3** | Servo signal, typically orange |
| Servo power / ground | **5 V load supply** / common GND, typically red / brown |

**Remove input 17's previous direct GND wire.** Keep buffer pin 20 at 5 V, pins 10/1/19 at GND, and its 100 nF capacitor. Other unused inputs 2/4/6/8 stay grounded. Servo power comes from the course 5 V/3 A supply, sharing its current budget with displays; do not use the ~100 mA breadboard regulator or PIC 3.3 V rail.

Display DATA 22, SCK 26, SS 24 and buffer connections remain as in the [working display test](../score_timer/README.md#wiring--power-off-first). UART wiring may remain connected; this image does not transmit serial messages.

## Run

1. Initially detach the servo horn/linkage so the servo can center freely.
2. In MPLAB, select **JoystickServoBench**, `default`, **PIC32MX170F256B**, XC32 v6.00, DFP 1.7.380. **Configure Tool → Select Tool → SNAP**. Reload VS Code if the project is missing.
3. Run **MPLAB CMake: Build**, then program this project. Keep [user.cmake](../../../cmake/JoystickServoBench/default/user.cmake), which includes the Lab3 SNAP debug reservation fix.
4. Enable the external 5 V supply output. **Keep the joystick fully released during startup**: RELEASE → CAL → P 1500, normally about 1.5–2 seconds. The firmware measures both centers this boot; no fixed X/Y center edit is needed. If already running, reset PIC1 with the joystick released to repeat calibration.
5. Push outward, then draw a slow clockwise arc. Reverse the arc; verify the servo reverses. Try a full turn to reach an endpoint, reverse again, then release to return home. Calibrate direction with the linkage detached.

Top display alternates **X / Y** (0–1023) every 2 seconds. Bottom shows **RELEASE / CAL** during startup, then **CW / CCW + pulse width**, or **P + pulse width** when no rotation is detected. Direction labels describe detected joystick rotation; the pulse is a command, not measured servo feedback.

**CHECK XY** means no acceptable calibration within 8 seconds; pulses stay off. Release the stick and check VRy → PIC7, VRx → PIC6, 3.3 V and common GND, then reset. **FAULT** indicates an ADC, stale-sample, display or configuration fault; pulses stop until reset. A stable off-center hold or stable floating input cannot be identified from these readings alone: release is required, and this feature does not repair wiring.

Terminal alternative: `make -C firmware joystick-servo` produces `firmware/build/joystick_servo/joystick_servo_bench.hex` without programming the PIC.

Keep generated `.hex` / `.elf` files and host tests out of MPLAB filesets. Workspace auto-add is disabled; add new sources to the intended project explicitly. Otherwise MPLAB can try to merge overlapping firmware images and fail with Hexmate error 1600. After removing accidental entries, reload VS Code before rebuilding to clear MPLAB's cached file list.

## Calibration

Edit [BenchConfig.h](BenchConfig.h), rebuild and reprogram:

- Centers are measured once after a 500 ms settling period and a 1-second stable sample window. Acceptance requires at least 80 samples, at most 24 ADC counts of range per axis, early/late means within 6 counts, and 96 counts of margin from configured endpoints. Runtime centers stay fixed until reset; the nominal 512/512 values in the config are not startup acceptance thresholds.
- `x.min/max` and `y.min/max`: nominal 0/1023, independently adjustable to measured endpoints. Each half-axis is normalized to 512 units.
- `x.inverted` / `y.inverted`: default false; choose signs so X increases rightward and Y upward. If physical clockwise reads CCW, correct one axis inversion.
- `reverse`: toggle if the servo rotates opposite the correctly identified joystick direction. Default false makes CW increase pulse width; mounting determines actual direction.
- `deadband` / `track_radius`: normalized radius 64 / 128. Angle tracking starts outside 128, resets inside 64. Returning to the center commands home; angles near center are ignored.
- `pulse_us_per_turn`: **500 µs per 360 degrees of joystick rotation**; adjust sensitivity independently of travel limits.
- `pulse_min_us` / `pulse_center_us` / `pulse_max_us`: **1250 / 1500 / 1750 µs** initially.
- `slew_us_per_step`: at most 10 µs change per 20 ms; both axes are filtered. A 2-degree angular threshold rejects small noise while accumulating slow movement.

**Pulse width is not a measured angle.** The intended sweep is at most about 90° total; calibrate the actual servo and linkage before expanding the endpoints. Driver bounds 1000–2000 µs are not guaranteed mechanical limits.

## Resources and validation

ADC1 samples AN4/AN5 every 10 ms using AVDD/AVSS references, with a 2 ms conversion timeout and 100 ms stale-data fault. Timer2 + OC4 generate 50 Hz on RA4 (PBCLK 20 MHz, prescaler 8, PR2=49999). SPI2 runs the displays independently. This bench owns Timer2; coordinate it with the treat servo during game integration.

The [actuator schematic](../../../hardware/sheets/actuators.kicad_sch) now shows the S51 and the existing U2 17→3 connection. No game services or second PIC run here. Floating joystick wires and disconnected displays cannot reliably be detected; stopped pulses do not guarantee holding torque.

Watches: `JoystickRawX`, `JoystickRawY`, learned `JoystickCenterX` / `JoystickCenterY`, `JoystickRotation`, `ServoPulseUs` (0=disabled), `ServoBenchState`, `ServoBenchError`, `DisplayStatus`.

The previous X-only bench moved the real servo. Fixed-center angular builds stayed at CENTER as released Y changed between boots; the user reports readings stabilize within each boot. Startup calibration addresses that software limitation; the cause of the varying Y voltage remains unverified. New calibrated angular motion still needs a successful board test. ASan/UBSan tests cover learned offsets, calibration stability/drift/timeout, frozen centers, CW/CCW, gain, angle/clock wrap, hold/home, endpoint reversal, slew limits and faults (`make -C firmware joystick-servo-test`). [Build/review results](../../docs/validation.md). ADC and PWM drivers are unchanged; math uses the XC32 C library.
