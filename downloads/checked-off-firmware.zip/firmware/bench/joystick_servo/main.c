#include <xc.h>
#include <cp0defs.h>
#include "BenchConfig.h"
#include "JoystickADC.h"
#include "SpoonServo.h"

/* Watch these in MPLAB. No UART wiring or second PIC is required. */
volatile uint16_t JoystickRawX, JoystickRawY, ServoPulseUs;
volatile uint16_t JoystickCenterX, JoystickCenterY;
volatile Follower_State ServoBenchState = FOLLOWER_CALIBRATING;
volatile Follower_Error ServoBenchError;
volatile Follower_Motion JoystickRotation;
volatile ScoreTimerDisplay_State DisplayStatus = SCORE_TIMER_STARTING;
volatile uint32_t ServoBenchMilliseconds;

static Follower follower;
static uint32_t last_core_count;

static uint32_t milliseconds(void)
{
    uint32_t elapsed = (uint32_t)(_CP0_GET_COUNT() - last_core_count);
    uint32_t whole_ms = elapsed / 20000u; /* SYSCLK=40 MHz; CP0 Count=20 MHz. */
    last_core_count += whole_ms * 20000u;
    ServoBenchMilliseconds += whole_ms;
    return ServoBenchMilliseconds;
}

static void show_value(ScoreTimerDisplay_Panel panel, const char *name, uint16_t value)
{
    char text[9];
    unsigned int i = 0, end;
    while (*name && i < 3) text[i++] = *name++;
    text[i++] = ' ';
    end = i + 4;
    text[end] = '\0';
    while (end > i) {
        text[--end] = '0' + value % 10u;
        value /= 10u;
    }
    (void)ScoreTimerDisplay_SetText(panel, text);
}

static void show_diagnostics(uint32_t now)
{
    if ((now / 2000u) & 1u) show_value(DISPLAY_TOP, "Y", JoystickRawY);
    else show_value(DISPLAY_TOP, "X", JoystickRawX);
    if (ServoBenchState == FOLLOWER_FAULT) {
        (void)ScoreTimerDisplay_SetText(DISPLAY_BOTTOM,
            ServoBenchError == FOLLOWER_ERROR_CALIBRATION ? "CHECK XY" : "FAULT");
    } else if (ServoBenchState == FOLLOWER_CALIBRATING) {
        (void)ScoreTimerDisplay_SetText(DISPLAY_BOTTOM, follower.cal_samples ? "CAL" : "RELEASE");
    } else {
        const char *label = JoystickRotation == FOLLOWER_CW ? "CW" :
                            JoystickRotation == FOLLOWER_CCW ? "CCW" : "P";
        show_value(DISPLAY_BOTTOM, label, ServoPulseUs);
    }
}

int main(void)
{
    uint32_t now, last_sample_request, last_display;
    uint16_t x, y;
    JoystickADC_State adc_state;
    SpoonServo_Init();      /* Signal stays LOW until valid centered readings. */
    last_core_count = _CP0_GET_COUNT();
    while (milliseconds() < 100u) { }
    now = milliseconds();
    (void)Follower_Init(&follower, &BenchFollowerConfig, now);
    JoystickADC_Init();
    if (!ScoreTimerDisplay_Init(&BenchDisplayConfig)) {
        Follower_Fault(&follower);
    }
    (void)ScoreTimerDisplay_SetText(DISPLAY_TOP, "JOYSTICK");
    (void)ScoreTimerDisplay_SetText(DISPLAY_BOTTOM, "RELEASE");
    last_sample_request = now - 10u;
    last_display = now;

    for (;;) {
        now = milliseconds();
        DisplayStatus = ScoreTimerDisplay_Service();
        adc_state = JoystickADC_Poll(&x, &y);
        if (adc_state == JOYSTICK_ADC_READY) {
            JoystickRawX = x;
            JoystickRawY = y;
            Follower_Sample(&follower, x, y, now);
        } else if (adc_state == JOYSTICK_ADC_FAULT) {
            Follower_Fault(&follower);
        }
        if (DisplayStatus == SCORE_TIMER_FAULT) {
            Follower_Fault(&follower);
        }
        if ((uint32_t)(now - last_sample_request) >= 10u && JoystickADC_Start()) {
            last_sample_request = now;
        }
        ServoBenchState = Follower_Service(&follower, now);
        ServoBenchError = follower.error;
        if (ServoBenchState == FOLLOWER_ACTIVE) {
            JoystickCenterX = follower.config.x.center;
            JoystickCenterY = follower.config.y.center;
        }
        JoystickRotation = follower.motion;
        if (ServoBenchState == FOLLOWER_ACTIVE) {
            ServoPulseUs = follower.pulse_us;
            if (!SpoonServo_WritePulse(ServoPulseUs)) {
                Follower_Fault(&follower);
                ServoBenchState = FOLLOWER_FAULT;
                ServoBenchError = follower.error;
                SpoonServo_Disable();
                ServoPulseUs = 0;
            }
        } else {
            SpoonServo_Disable();
            ServoPulseUs = 0;
        }
        if ((uint32_t)(now - last_display) >= 100u) {
            last_display = now;
            show_diagnostics(now);
        }
    }
}
