#include <math.h>
#include "Follower.h"
#include "SpoonServo.h"

#define DEGREES_PER_RADIAN 57.2957795131f

static bool valid_axis(const Follower_Axis *a)
{
    return a->max <= 1023 && a->min < a->center && a->center < a->max &&
           a->max - a->min > 2 * FOLLOWER_CAL_EDGE_MARGIN;
}

static void fail(Follower *f, Follower_Error error)
{
    f->state = FOLLOWER_FAULT;
    f->error = error;
    f->motion = FOLLOWER_STOPPED;
    f->tracking = false;
}

static int32_t normalize(uint16_t raw, const Follower_Axis *a)
{
    int32_t value = raw, span;
    if (value < a->min) value = a->min;
    if (value > a->max) value = a->max;
    value -= a->center;
    span = value < 0 ? a->center - a->min : a->max - a->center;
    value = value * 512 / span;
    return a->inverted ? -value : value;
}

bool Follower_Init(Follower *f, const Follower_Config *c, uint32_t now)
{
    if (f == 0) return false;
    *f = (Follower){ .state = FOLLOWER_FAULT, .error = FOLLOWER_ERROR_CONFIG };
    if (c == 0 || !valid_axis(&c->x) || !valid_axis(&c->y) ||
        c->deadband == 0 || c->deadband >= c->track_radius ||
        c->track_radius > 512 || c->pulse_us_per_turn == 0 ||
        c->pulse_us_per_turn > 2000 ||
        c->pulse_min_us < SPOON_SERVO_MIN_US ||
        c->pulse_max_us > SPOON_SERVO_MAX_US ||
        c->pulse_min_us >= c->pulse_center_us ||
        c->pulse_center_us >= c->pulse_max_us || c->slew_us_per_step == 0) {
        return false;
    }
    f->config = *c;
    f->state = FOLLOWER_CALIBRATING;
    f->error = FOLLOWER_ERROR_NONE;
    f->pulse_us = c->pulse_center_us;
    f->target_pulse_us = c->pulse_center_us;
    f->last_sample_ms = now;
    f->last_step_ms = now;
    f->initialized_ms = now;
    return true;
}

void Follower_Fault(Follower *f)
{
    fail(f, FOLLOWER_ERROR_IO);
}

static void start_window(Follower *f, uint16_t x, uint16_t y, uint32_t now)
{
    f->cal_started_ms = now;
    f->cal_min_x = f->cal_max_x = x;
    f->cal_min_y = f->cal_max_y = y;
    f->cal_sum_x = f->cal_sum_y = 0;
    f->cal_early_sum_x = f->cal_early_sum_y = 0;
    f->cal_samples = f->cal_early_samples = 0;
}

static bool plausible_center(uint16_t raw, const Follower_Axis *axis)
{
    return raw >= axis->min + FOLLOWER_CAL_EDGE_MARGIN &&
           raw <= axis->max - FOLLOWER_CAL_EDGE_MARGIN;
}

static void calibrate(Follower *f, uint16_t x, uint16_t y, uint32_t now)
{
    uint32_t elapsed = (uint32_t)(now - f->initialized_ms);
    uint16_t late_samples;
    int32_t early_x, early_y, late_x, late_y;
    if (elapsed >= FOLLOWER_CAL_TIMEOUT_MS) {
        fail(f, FOLLOWER_ERROR_CALIBRATION);
        return;
    }
    if (elapsed < FOLLOWER_CAL_SETTLE_MS) return;
    if (!plausible_center(x, &f->config.x) || !plausible_center(y, &f->config.y)) {
        f->cal_samples = 0;
        return;
    }
    /* Only distinct sample timestamps contribute to the stability window. */
    if (f->cal_samples && now == f->cal_last_sample_ms) return;
    if (!f->cal_samples) start_window(f, x, y, now);
    if (x < f->cal_min_x) f->cal_min_x = x;
    if (x > f->cal_max_x) f->cal_max_x = x;
    if (y < f->cal_min_y) f->cal_min_y = y;
    if (y > f->cal_max_y) f->cal_max_y = y;
    if (f->cal_max_x - f->cal_min_x > FOLLOWER_CAL_MAX_SPAN ||
        f->cal_max_y - f->cal_min_y > FOLLOWER_CAL_MAX_SPAN) {
        start_window(f, x, y, now);
    }
    f->cal_last_sample_ms = now;
    f->cal_sum_x += x;
    f->cal_sum_y += y;
    ++f->cal_samples;
    elapsed = (uint32_t)(now - f->cal_started_ms);
    if (elapsed < FOLLOWER_CAL_WINDOW_MS / 2) {
        f->cal_early_sum_x += x;
        f->cal_early_sum_y += y;
        ++f->cal_early_samples;
    }
    late_samples = f->cal_samples - f->cal_early_samples;
    if (elapsed < FOLLOWER_CAL_WINDOW_MS || f->cal_samples < FOLLOWER_CAL_MIN_SAMPLES ||
        f->cal_early_samples < FOLLOWER_CAL_MIN_SAMPLES / 3 ||
        late_samples < FOLLOWER_CAL_MIN_SAMPLES / 3) return;
    early_x = (int32_t)(f->cal_early_sum_x / f->cal_early_samples);
    early_y = (int32_t)(f->cal_early_sum_y / f->cal_early_samples);
    late_x = (int32_t)((f->cal_sum_x - f->cal_early_sum_x) / late_samples);
    late_y = (int32_t)((f->cal_sum_y - f->cal_early_sum_y) / late_samples);
    if (early_x - late_x > FOLLOWER_CAL_MAX_DRIFT || late_x - early_x > FOLLOWER_CAL_MAX_DRIFT ||
        early_y - late_y > FOLLOWER_CAL_MAX_DRIFT || late_y - early_y > FOLLOWER_CAL_MAX_DRIFT) {
        /* A slowly moving stick must not qualify merely by having low noise. */
        start_window(f, x, y, now);
        return;
    }
    f->config.x.center = (uint16_t)((f->cal_sum_x + f->cal_samples / 2) / f->cal_samples);
    f->config.y.center = (uint16_t)((f->cal_sum_y + f->cal_samples / 2) / f->cal_samples);
    f->filtered_x_q8 = f->filtered_y_q8 = 0;
    f->has_sample = true;
    f->state = FOLLOWER_ACTIVE;
    f->last_step_ms = f->last_motion_ms = now;
}

static void forget_direction(Follower *f)
{
    f->tracking = false;
    f->motion = FOLLOWER_STOPPED;
    f->last_direction = FOLLOWER_STOPPED;
}

static void track_rotation(Follower *f, int32_t x, int32_t y)
{
    const Follower_Config *c = &f->config;
    int32_t radius2 = x * x + y * y;
    float angle, delta, increment;
    Follower_Motion direction;
    if (radius2 <= (int32_t)c->deadband * c->deadband) {
        /* Do not infer direction through the center, where angle is undefined. */
        forget_direction(f);
        f->target_pulse_us = f->pulse_us;
        return;
    }
    if (!f->tracking && radius2 < (int32_t)c->track_radius * c->track_radius) return;
    angle = atan2f((float)y, (float)x) * DEGREES_PER_RADIAN;
    if (!f->tracking) {
        f->tracking = true;
        f->reference_angle_deg = angle;
        f->target_pulse_us = f->pulse_us;
        return; /* A first outward push establishes direction, not a rotation. */
    }
    delta = angle - f->reference_angle_deg;
    if (delta > 180.0f) delta -= 360.0f;
    if (delta < -180.0f) delta += 360.0f;
    if (fabsf(delta) > FOLLOWER_MAX_ANGLE_STEP_DEG) {
        /* An ambiguous jump/reposition must not become a large servo move. */
        forget_direction(f);
        f->target_pulse_us = f->pulse_us;
        return;
    }
    if (fabsf(delta) < FOLLOWER_ANGLE_DEADBAND_DEG) return;
    f->reference_angle_deg = angle; /* Small genuine moves accumulate to 2 deg. */
    direction = delta < 0.0f ? FOLLOWER_CW : FOLLOWER_CCW;
    if (direction != f->last_direction) {
        /* Cancel pending old-direction travel when the player reverses. */
        f->target_pulse_us = f->pulse_us;
    }
    increment = -delta * c->pulse_us_per_turn / 360.0f;
    if (c->reverse) increment = -increment;
    f->target_pulse_us += increment;
    if (f->target_pulse_us < c->pulse_min_us) f->target_pulse_us = c->pulse_min_us;
    if (f->target_pulse_us > c->pulse_max_us) f->target_pulse_us = c->pulse_max_us;
    f->last_direction = direction;
    f->motion = direction;
    f->last_motion_ms = f->last_sample_ms;
}

void Follower_Sample(Follower *f, uint16_t raw_x, uint16_t raw_y, uint32_t now)
{
    int32_t x, y, radius2;
    bool centered;
    if (f->state == FOLLOWER_FAULT) return;
    if (raw_x > 1023 || raw_y > 1023) {
        fail(f, FOLLOWER_ERROR_INPUT);
        return;
    }
    if ((uint32_t)(now - f->last_sample_ms) >= FOLLOWER_SAMPLE_TIMEOUT_MS) {
        fail(f, FOLLOWER_ERROR_STALE);
        return;
    }
    f->raw_x = raw_x;
    f->raw_y = raw_y;
    f->last_sample_ms = now;
    if (f->state == FOLLOWER_CALIBRATING) {
        calibrate(f, raw_x, raw_y, now);
        return;
    }
    x = normalize(raw_x, &f->config.x);
    y = normalize(raw_y, &f->config.y);
    radius2 = x * x + y * y;
    centered = radius2 <= (int32_t)f->config.deadband * f->config.deadband;
    if (!f->has_sample || centered) {
        f->filtered_x_q8 = x * 256;
        f->filtered_y_q8 = y * 256;
        f->has_sample = true;
    } else {
        f->filtered_x_q8 += (x * 256 - f->filtered_x_q8) / 4;
        f->filtered_y_q8 += (y * 256 - f->filtered_y_q8) / 4;
    }
    if (centered) {
        forget_direction(f);
        f->target_pulse_us = f->config.pulse_center_us;
        return;
    }
    track_rotation(f, f->filtered_x_q8 / 256, f->filtered_y_q8 / 256);
}

Follower_State Follower_Service(Follower *f, uint32_t now)
{
    int32_t delta;
    if (f->state == FOLLOWER_FAULT) return f->state;
    if ((uint32_t)(now - f->last_sample_ms) >= FOLLOWER_SAMPLE_TIMEOUT_MS) {
        fail(f, FOLLOWER_ERROR_STALE);
    }
    if (f->state == FOLLOWER_CALIBRATING &&
        (uint32_t)(now - f->initialized_ms) >= FOLLOWER_CAL_TIMEOUT_MS) {
        fail(f, FOLLOWER_ERROR_CALIBRATION);
    }
    if ((uint32_t)(now - f->last_motion_ms) >= FOLLOWER_MOTION_HOLD_MS) {
        f->motion = FOLLOWER_STOPPED;
    }
    if (f->state != FOLLOWER_ACTIVE ||
        (uint32_t)(now - f->last_step_ms) < FOLLOWER_STEP_MS) return f->state;
    f->last_step_ms = now; /* No catch-up burst after a delayed loop. */
    delta = (int32_t)(f->target_pulse_us + 0.5f) - f->pulse_us;
    if (delta > f->config.slew_us_per_step) delta = f->config.slew_us_per_step;
    if (delta < -(int32_t)f->config.slew_us_per_step) delta = -(int32_t)f->config.slew_us_per_step;
    f->pulse_us = (uint16_t)((int32_t)f->pulse_us + delta);
    return f->state;
}
