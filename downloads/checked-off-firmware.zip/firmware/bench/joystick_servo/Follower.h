#ifndef PANIC_BENCH_FOLLOWER_H
#define PANIC_BENCH_FOLLOWER_H

#include <stdbool.h>
#include <stdint.h>

typedef enum { FOLLOWER_CALIBRATING, FOLLOWER_ACTIVE, FOLLOWER_FAULT } Follower_State;
typedef enum {
    FOLLOWER_ERROR_NONE, FOLLOWER_ERROR_CONFIG, FOLLOWER_ERROR_IO,
    FOLLOWER_ERROR_STALE, FOLLOWER_ERROR_INPUT, FOLLOWER_ERROR_CALIBRATION
} Follower_Error;
typedef enum { FOLLOWER_STOPPED, FOLLOWER_CW, FOLLOWER_CCW } Follower_Motion;
typedef struct {
    uint16_t min, center, max;
    bool inverted;
} Follower_Axis;
typedef struct {
    Follower_Axis x, y;
    uint16_t deadband, track_radius; /* Normalized radial units: full axis = 512. */
    uint16_t pulse_us_per_turn;     /* Gain for one 360-degree joystick turn. */
    uint16_t pulse_min_us, pulse_center_us, pulse_max_us;
    uint16_t slew_us_per_step;
    bool reverse;
} Follower_Config;

enum { FOLLOWER_SAMPLE_TIMEOUT_MS = 100,
       FOLLOWER_CAL_SETTLE_MS = 500, FOLLOWER_CAL_WINDOW_MS = 1000,
       FOLLOWER_CAL_TIMEOUT_MS = 8000, FOLLOWER_CAL_MIN_SAMPLES = 80,
       FOLLOWER_CAL_MAX_SPAN = 24, FOLLOWER_CAL_MAX_DRIFT = 6,
       FOLLOWER_CAL_EDGE_MARGIN = 96,
       FOLLOWER_STEP_MS = 20, FOLLOWER_MOTION_HOLD_MS = 150,
       FOLLOWER_ANGLE_DEADBAND_DEG = 2, FOLLOWER_MAX_ANGLE_STEP_DEG = 90 };

typedef struct {
    Follower_Config config;
    Follower_State state;
    Follower_Error error;
    Follower_Motion motion, last_direction;
    uint16_t raw_x, raw_y, pulse_us;
    int32_t filtered_x_q8, filtered_y_q8;
    float reference_angle_deg, target_pulse_us;
    uint32_t last_sample_ms, last_step_ms, last_motion_ms, initialized_ms;
    uint32_t cal_started_ms, cal_last_sample_ms, cal_sum_x, cal_sum_y;
    uint32_t cal_early_sum_x, cal_early_sum_y;
    uint16_t cal_min_x, cal_max_x, cal_min_y, cal_max_y;
    uint16_t cal_samples, cal_early_samples;
    bool has_sample, tracking;
} Follower;

/* Pure control logic; no PIC registers. Release the joystick during startup:
 * after settling, a stable X/Y window learns config.x/y.center once per Init.
 * Stability cannot prove release or detect every disconnected analog input.
 * Centers remain frozen during ACTIVE; reset to recalibrate.
 * Init rejects invalid calibration limits.
 * Feed one complete ADC pair every 10 ms; call Service frequently.
 * Positive X is right and positive Y is up after axis inversion. Angular
 * changes move a limited servo; endpoints clamp without accumulating excess
 * turns. Centering returns home; a stationary off-center stick holds its target.
 * Faults latch until Init. Only ACTIVE authorizes servo pulses.
 */
bool Follower_Init(Follower *f, const Follower_Config *config, uint32_t now_ms);
void Follower_Sample(Follower *f, uint16_t x, uint16_t y, uint32_t now_ms);
Follower_State Follower_Service(Follower *f, uint32_t now_ms);
void Follower_Fault(Follower *f);

#endif
