#ifndef PANIC_JOYSTICK_SERVO_BENCH_CONFIG_H
#define PANIC_JOYSTICK_SERVO_BENCH_CONFIG_H

#include "Follower.h"
#include "ScoreTimerDisplay.h"

/* Angular X/Y movement controls relative servo travel. Startup measures both
 * released centers once; these nominal centers are not startup thresholds.
 * Keep the joystick released until calibration finishes. Centers stay fixed
 * during operation; reset to recalibrate. Stability checks gate arming.
 * Start with the servo horn/linkage detached. These pulse widths do NOT
 * promise 90 degrees; calibrate travel on the actual S51 and linkage.
 */
static const Follower_Config BenchFollowerConfig = {
    .x = { .min = 0, .center = 512, .max = 1023, .inverted = false },
    .y = { .min = 0, .center = 512, .max = 1023, .inverted = false },
    .deadband = 64, .track_radius = 128,
    .pulse_us_per_turn = 500,
    .pulse_min_us = 1250, .pulse_center_us = 1500, .pulse_max_us = 1750,
    .slew_us_per_step = 10, /* At most 10 us pulse change per 20 ms update. */
    .reverse = false
};

/* Same two-strip wiring and orientation as the working ScoreTimerBench. */
static const ScoreTimerDisplay_Config BenchDisplayConfig = {
    .top_first = true,
    .reverse_modules = { false, false },
    .rotation = { 180, 180 },
    .intensity = 1
};

#endif
