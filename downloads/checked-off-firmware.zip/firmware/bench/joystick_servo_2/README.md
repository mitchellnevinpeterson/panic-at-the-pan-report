# JoystickServoBench_2 — checkpoint

Restores the original **X-only position follower** in a separate MPLAB project. The angular/calibration experiment remains in JoystickServoBench.

1. Select **JoystickServoBench_2 / default** in MPLAB. Reload the VS Code window if it is absent. Choose the connected SNAP, Build and Program; Continue if debugging stops at main.
2. Keep the existing wiring and enable the external **5 V supply Output**. Joystick uses **3.3 V**; all grounds are common.
3. Release the joystick for **0.5 seconds**. Only X must be near 512; Y does not gate startup.
4. Push left/right: servo follows X position. Hold: it stays there. Release: it returns home. No circular gesture is needed.

Top display shows **X**. Bottom starts at **CENTER**, then alternates **Y / P** every 2 seconds. P is the commanded pulse width, not measured feedback. FAULT disables pulses until reset.

| Connection | Existing destination |
|---|---|
| Joystick VRx / VRy | PIC 6 / PIC 7 |
| Servo signal | PIC 12 → 74ACT244 input 17; output 3 → orange |
| Servo power | Red → external 5 V; brown → common GND |
| Buffer | Pin 20 → 5 V; pins 10, 1, 19 → GND |
| Status displays | PIC DATA 22 / SCK 26 / SS 24, through buffer |

Original settings: X center 512, deadband 40, 1250–1500–1750 us, maximum 10 us change per 20 ms. Travel is limited; pulse width does not establish a measured angle. [Settings](BenchConfig.h).

Build: `make -C firmware joystick-servo-2`. Host checks: `make -C firmware joystick-servo-2-test`. Debug link: `make -C firmware/bench/joystick_servo_2 DEBUG=1`.

Make outputs `firmware/build/joystick_servo_2/joystick_servo_2_bench.hex`; MPLAB outputs its separate image under `out/JoystickServoBench_2/`. Source lists are explicit and do not include the angular bench. ADC, PWM, clock and display drivers are shared unchanged. No GameSM or E-ink runs in this test. This recreated image still needs a physical checkpoint run.
