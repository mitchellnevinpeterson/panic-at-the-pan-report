# Firmware

Two integrated targets now connect all six game state machines with the existing display, joystick libraries and a reliable UART2 link. PIC2 owns MCP switches, ultrasonic input, audio and the Finish lamp. The combined images are software-verified; hardware integration and calibration remain pending.

```sh
make -C firmware check
make -C firmware test
```

Start with [architecture](docs/architecture.md), [build choices](docs/build.md) and [remaining decisions](docs/pending_decisions.md). Default full-game behavior provides Welcome→dish intro → 60-second cooking, Finish after30 seconds, idle timeout, unique ingredients and zero score. Formal scoring/heat/stir need explicit tuning; spoon, treat and ninth-driver heat hardware remain gated. E-ink preserves the 180-second update interval.

| Checkpoint | Guide | Build |
|---|---|---|
| Game/Ingredient/explicit +10 Score | [GameSMBench](bench/game_sm/README.md) | `make -C firmware game-sm` |
| Two stacked score/timer strips | [ScoreTimerBench](bench/score_timer/README.md) | `make -C firmware score-timer` |
| Working X-only joystick/S51 | [JoystickServoBench_2](bench/joystick_servo_2/README.md) | `make -C firmware joystick-servo-2` |
| CW/CCW experiment | [JoystickServoBench](bench/joystick_servo/README.md) | `make -C firmware joystick-servo` |
| Tested ingredient e-ink icons | [EInkBench](bench/eink/README.md) | `make -C firmware eink` |

Standalone checkpoint sources and teammate source remain unchanged. [Validation history](docs/validation.md) · [reuse provenance](docs/reuse.md).
