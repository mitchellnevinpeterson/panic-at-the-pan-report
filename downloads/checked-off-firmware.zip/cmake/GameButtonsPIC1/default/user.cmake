# Preserve this file: MPLAB includes it after its generated build rules.
# Adapted from the working Lab3_Part4 project with the same device/toolchain.
# PIC32MX170F256B debug executive: 0x1FC00490 + 0x760 bytes, ending at
# 0x1FC00BEF. DEVCFG3 starts at 0x1FC00BF0 (KSEG1 alias 0xBFC00BF0).
# The generated reservation includes DEVCFG3; correct only that exact range.
get_property(_game_sm_targets DIRECTORY PROPERTY BUILDSYSTEM_TARGETS)
list(FILTER _game_sm_targets INCLUDE REGEX "^GameButtonsPIC1_default_image_")
foreach(_game_sm_image IN LISTS _game_sm_targets)
    get_target_property(_game_sm_options ${_game_sm_image} LINK_OPTIONS)
    if(_game_sm_options)
        list(TRANSFORM _game_sm_options REPLACE
            "^-mreserve=boot@0x1fc00490:0x1fc00bf0$"
            "-mreserve=boot@0x1fc00490:0x1fc00bef")
        set_target_properties(${_game_sm_image} PROPERTIES
            LINK_OPTIONS "${_game_sm_options}")
    endif()
    target_link_options(${_game_sm_image} PRIVATE
        "-Wl,--defsym=_min_stack_size=2048,--gc-sections")
endforeach()
unset(_game_sm_targets)
unset(_game_sm_image)
unset(_game_sm_options)

# Also support an existing MPLAB CMake cache until the extension regenerates
# its fileset from .vscode/GameButtonsPIC1.mplab.json. Add only missing sources.
set(_buttons_compile GameButtonsPIC1_default_default_XC32_compile)
if(TARGET ${_buttons_compile})
    get_filename_component(_buttons_root "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)
    get_target_property(_buttons_sources ${_buttons_compile} SOURCES)
    set(_buttons_absolute_sources)
    foreach(_source IN LISTS _buttons_sources)
        get_filename_component(_absolute "${_source}" ABSOLUTE BASE_DIR "${CMAKE_CURRENT_SOURCE_DIR}")
        list(APPEND _buttons_absolute_sources "${_absolute}")
    endforeach()
    foreach(_source IN ITEMS
        firmware/bench/game_buttons/ButtonEInk.c
        firmware/bench/game_buttons/ButtonEInkPort.c
        firmware/bench/ingredient_eink/BenchCanvas.c
        firmware/pic1/EInkAsync.c
        firmware/drivers/src/EInkDisplay.c)
        set(_absolute "${_buttons_root}/${_source}")
        if(NOT _absolute IN_LIST _buttons_absolute_sources)
            target_sources(${_buttons_compile} PRIVATE "${_absolute}")
        endif()
    endforeach()
    target_include_directories(${_buttons_compile} PRIVATE
        "${_buttons_root}/firmware/pic1"
        "${_buttons_root}/firmware/bench/ingredient_eink"
        "${_buttons_root}/firmware/bench/eink")
endif()
unset(_buttons_compile)
unset(_buttons_root)
unset(_buttons_sources)
unset(_buttons_absolute_sources)
unset(_source)
unset(_absolute)
