# Preserve this file: MPLAB includes it after its generated build rules.
# Adapted from the working Lab3_Part4 project with the same device/toolchain.
# PIC32MX170F256B debug executive: 0x1FC00490 + 0x760 bytes, ending at
# 0x1FC00BEF. DEVCFG3 starts at 0x1FC00BF0 (KSEG1 alias 0xBFC00BF0).
# The generated reservation includes DEVCFG3; correct only that exact range.
get_property(_game_sm_targets DIRECTORY PROPERTY BUILDSYSTEM_TARGETS)
list(FILTER _game_sm_targets INCLUDE REGEX "^GameButtonsPIC2_default_image_")
foreach(_game_sm_image IN LISTS _game_sm_targets)
    get_target_property(_game_sm_options ${_game_sm_image} LINK_OPTIONS)
    if(_game_sm_options)
        list(TRANSFORM _game_sm_options REPLACE
            "^-mreserve=boot@0x1fc00490:0x1fc00bf0$"
            "-mreserve=boot@0x1fc00490:0x1fc00bef")
        set_target_properties(${_game_sm_image} PROPERTIES
            LINK_OPTIONS "${_game_sm_options}")
    endif()
    target_link_options(${_game_sm_image} PRIVATE
        "-Wl,--defsym=_min_stack_size=2048,--gc-sections")
endforeach()
unset(_game_sm_targets)
unset(_game_sm_image)
unset(_game_sm_options)
