# Preserve this file: MPLAB includes it after its generated build rules.
# Adapted from the working Lab3_Part4 project with the same device/toolchain.
# PIC32MX170F256B debug executive: 0x1FC00490 + 0x760 bytes, ending at
# 0x1FC00BEF. DEVCFG3 starts at 0x1FC00BF0 (KSEG1 alias 0xBFC00BF0).
# The generated reservation includes DEVCFG3; correct only that exact range.
get_property(_joystick_servo_targets DIRECTORY PROPERTY BUILDSYSTEM_TARGETS)
list(FILTER _joystick_servo_targets INCLUDE REGEX "^JoystickServoBench_2_default_image_")
foreach(_joystick_servo_image IN LISTS _joystick_servo_targets)
    get_target_property(_joystick_servo_options ${_joystick_servo_image} LINK_OPTIONS)
    if(_joystick_servo_options)
        list(TRANSFORM _joystick_servo_options REPLACE
            "^-mreserve=boot@0x1fc00490:0x1fc00bf0$"
            "-mreserve=boot@0x1fc00490:0x1fc00bef")
        set_target_properties(${_joystick_servo_image} PROPERTIES
            LINK_OPTIONS "${_joystick_servo_options}")
    endif()
    target_link_options(${_joystick_servo_image} PRIVATE
        "-Wl,--defsym=_min_stack_size=2048,--gc-sections")
endforeach()
unset(_joystick_servo_targets)
unset(_joystick_servo_image)
unset(_joystick_servo_options)
