# Preserve this file: MPLAB includes it after its generated build rules.
# Adapted from the working Lab3_Part4 project with the same device/toolchain.
# PIC32MX170F256B debug executive: 0x1FC00490 + 0x760 bytes, ending at
# 0x1FC00BEF. DEVCFG3 starts at 0x1FC00BF0 (KSEG1 alias 0xBFC00BF0).
# The generated reservation includes DEVCFG3; correct only that exact range.
get_property(_lcd_targets DIRECTORY PROPERTY BUILDSYSTEM_TARGETS)
list(FILTER _lcd_targets INCLUDE REGEX "^LCDPIC2Bench_default_image_")
foreach(_lcd_image IN LISTS _lcd_targets)
    get_target_property(_lcd_options ${_lcd_image} LINK_OPTIONS)
    if(_lcd_options)
        list(TRANSFORM _lcd_options REPLACE
            "^-mreserve=boot@0x1fc00490:0x1fc00bf0$"
            "-mreserve=boot@0x1fc00490:0x1fc00bef")
        set_target_properties(${_lcd_image} PROPERTIES
            LINK_OPTIONS "${_lcd_options}")
    endif()
    target_link_options(${_lcd_image} PRIVATE
        "-Wl,--defsym=_min_stack_size=2048,--gc-sections")
endforeach()
unset(_lcd_targets)
unset(_lcd_image)
unset(_lcd_options)
