# Apply the same stack reservation and link settings to MPLAB production builds.
include("${CMAKE_CURRENT_LIST_DIR}/../default/user.cmake")
