"""Play the PIC32 pan sounds from the ultrasonic readings in GNU Screen."""

import argparse
from array import array
from pathlib import Path
import re
import subprocess
import tempfile
import time
import wave

SOURCE = Path(__file__).resolve().parents[1] / "src"
READING = re.compile(r"\s*(\d+) mm, echo \d+ us\s*")
ERRORS = ("no rising edge", "no falling edge", "echo already high", "out of range")
ZONES = {1: "not enough heat", 2: "just right", 3: "too much heat"}
HOT_BELOW_MM = 150
COOL_ABOVE_MM = 280
RENDERER = r"""
#include <stdio.h>
#include <stdlib.h>
#include "sizzle.h"

int main(int argc, char **argv)
{
    if (argc != 3) {
        return 1;
    }
    const HeatZone zone = (HeatZone)atoi(argv[1]);
    const unsigned frames = SIZZLE_SAMPLE_HZ * (unsigned)atoi(argv[2]);
    SizzleState state = SIZZLE_INITIAL_STATE;
    printf("%u\n", SIZZLE_SAMPLE_HZ);
    for (unsigned frame = 0; frame < frames; ++frame) {
        if (putchar(sizzle_sample(&state, zone) + 128) == EOF) {
            return 1;
        }
    }
    return 0;
}
"""


def render_clips(folder, seconds):
    renderer = folder / "render"
    subprocess.run(
        ["/usr/bin/clang", "-std=c99", "-O2", "-I", str(SOURCE), "-x", "c", "-", "-o", str(renderer)],
        input=RENDERER, text=True, check=True,
    )
    clips = {}
    for zone in ZONES:
        output = subprocess.check_output([renderer, str(zone), str(seconds)])
        header, samples = output.split(b"\n", 1)
        rate = int(header)
        if len(samples) != rate * seconds:
            raise RuntimeError("The audio renderer returned an incomplete clip.")
        audio = array("h", ((value - 128) * 230 for value in samples))
        clips[zone] = folder / f"zone-{zone}.wav"
        with wave.open(str(clips[zone]), "wb") as wav:
            wav.setparams((1, 2, rate, 0, "NONE", "not compressed"))
            wav.writeframes(audio.tobytes())
    return clips


def latest_distance(session, path):
    path.unlink(missing_ok=True)
    subprocess.run(
        ["screen", "-S", session, "-X", "hardcopy", "-h", str(path)],
        check=True, capture_output=True, text=True, timeout=2,
    )
    # Screen handles the command asynchronously and may still be writing.
    deadline = time.monotonic() + 0.25
    while time.monotonic() < deadline:
        if path.exists():
            for line in reversed(path.read_text().splitlines()):
                match = READING.fullmatch(line)
                if match:
                    return int(match[1])
                if any(error in line.lower() for error in ERRORS):
                    return None
        time.sleep(0.01)
    raise RuntimeError("The Screen window contains no ultrasonic readings.")


def heat_zone(distance):
    if not distance:
        return 0
    if distance < HOT_BELOW_MM:
        return 3
    if distance > COOL_ABOVE_MM:
        return 1
    return 2


def stop(player):
    if player is not None and player.poll() is None:
        player.terminate()
        player.wait(timeout=2)


def demo(seconds, session, check):
    with tempfile.TemporaryDirectory(prefix="pan-sear-") as temp:
        folder = Path(temp)
        snapshot = folder / "uart.txt"
        distance = latest_distance(session, snapshot)
        print(f"Sensor: {distance} mm" if distance else "Sensor: no valid distance", flush=True)
        clips = render_clips(folder, 2 if check else seconds + 1)
        if check:
            print("All three firmware audio clips rendered.")
            return

        player = None
        active = candidate = count = 0
        end = time.monotonic() + seconds
        print(f"Live audio running for {seconds} seconds. Press Control+C to stop.", flush=True)
        print(
            f"Too hot below {HOT_BELOW_MM / 10:g} cm, just right from "
            f"{HOT_BELOW_MM / 10:g} to {COOL_ABOVE_MM / 10:g} cm, "
            f"not enough heat above {COOL_ABOVE_MM / 10:g} cm.",
            flush=True,
        )
        try:
            while time.monotonic() < end:
                if player is not None and player.poll() is not None:
                    raise RuntimeError(f"Mac audio playback stopped: {player.stderr.read().strip()}")
                distance = latest_distance(session, snapshot)
                zone = heat_zone(distance)
                count = count + 1 if zone == candidate else 1
                candidate = zone
                if count >= 3 and zone != active:
                    stop(player)
                    player = None
                    if zone:
                        player = subprocess.Popen(
                            ["/usr/bin/afplay", "-v", "0.85", clips[zone]],
                            stderr=subprocess.PIPE, text=True,
                        )
                        print(f"{distance} mm — {ZONES[zone]}", flush=True)
                    else:
                        print("No valid distance — muted", flush=True)
                    active = zone
                time.sleep(0.18)
        finally:
            stop(player)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seconds", type=int, default=90)
    parser.add_argument("--screen", default="97025", help="GNU Screen session ID")
    parser.add_argument("--check", action="store_true", help="Check the sensor and render audio without playback")
    args = parser.parse_args()
    if not 1 <= args.seconds <= 600:
        parser.error("--seconds must be between 1 and 600")
    try:
        demo(args.seconds, args.screen, args.check)
    except KeyboardInterrupt:
        print("\nLive audio stopped.")
    except (OSError, RuntimeError, subprocess.SubprocessError) as error:
        parser.exit(1, f"{error}\n")
