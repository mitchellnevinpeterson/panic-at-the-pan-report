#include "board.h"
#include "heat_audio.h"
#include <stddef.h>

int main(void)
{
    static const uint32_t distances[] = {220u, 120u, 350u};
    heat_audio_start();
    for (;;) {
        for (unsigned i = 0; i < sizeof(distances) / sizeof(distances[0]); ++i) {
            while (heat_audio_update(distances[i]) == NULL) {
            }
            delay_us(3000000u);
        }
    }
}
