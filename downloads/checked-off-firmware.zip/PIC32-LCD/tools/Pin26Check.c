#include "board.h"

#define RB15_MASK (1u << 15)

int main(void)
{
    /* Drive pin 26 directly so a multimeter can read each level. */
    ANSELBCLR = RB15_MASK;
    LATBCLR = RB15_MASK;
    TRISBCLR = RB15_MASK;
    for (;;) {
        LATBSET = RB15_MASK;
        delay_us(2000000u);
        LATBCLR = RB15_MASK;
        delay_us(2000000u);
    }
}
