set(DEPENDENT_MP_BIN2HEXPic32Peripherals_LCD_Bench_fEbXsllF "/Applications/microchip/xc32/v6.00/bin/xc32-bin2hex")
set(DEPENDENT_DEPENDENT_TARGET_ELFPic32Peripherals_LCD_Bench_fEbXsllF ${CMAKE_CURRENT_LIST_DIR}/../../../../build/firmware/LCD_Bench.elf)
set(DEPENDENT_TARGET_DIRPic32Peripherals_LCD_Bench_fEbXsllF ${CMAKE_CURRENT_LIST_DIR}/../../../../build/firmware)
set(DEPENDENT_BYPRODUCTSPic32Peripherals_LCD_Bench_fEbXsllF ${DEPENDENT_TARGET_DIRPic32Peripherals_LCD_Bench_fEbXsllF}/${sourceFileNamePic32Peripherals_LCD_Bench_fEbXsllF}.c)
add_custom_command(
    OUTPUT ${DEPENDENT_TARGET_DIRPic32Peripherals_LCD_Bench_fEbXsllF}/${sourceFileNamePic32Peripherals_LCD_Bench_fEbXsllF}.c
    COMMAND ${DEPENDENT_MP_BIN2HEXPic32Peripherals_LCD_Bench_fEbXsllF} --image ${DEPENDENT_DEPENDENT_TARGET_ELFPic32Peripherals_LCD_Bench_fEbXsllF} --image-generated-c ${sourceFileNamePic32Peripherals_LCD_Bench_fEbXsllF}.c --image-generated-h ${sourceFileNamePic32Peripherals_LCD_Bench_fEbXsllF}.h --image-copy-mode ${modePic32Peripherals_LCD_Bench_fEbXsllF} --image-offset ${addressPic32Peripherals_LCD_Bench_fEbXsllF} 
    WORKING_DIRECTORY ${DEPENDENT_TARGET_DIRPic32Peripherals_LCD_Bench_fEbXsllF}
    DEPENDS ${DEPENDENT_DEPENDENT_TARGET_ELFPic32Peripherals_LCD_Bench_fEbXsllF})
add_custom_target(
    dependent_produced_source_artifactPic32Peripherals_LCD_Bench_fEbXsllF 
    DEPENDS ${DEPENDENT_TARGET_DIRPic32Peripherals_LCD_Bench_fEbXsllF}/${sourceFileNamePic32Peripherals_LCD_Bench_fEbXsllF}.c
    )
