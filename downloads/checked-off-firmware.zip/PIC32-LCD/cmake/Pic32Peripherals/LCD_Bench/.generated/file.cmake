# The following variables contains the files used by the different stages of the build process.
set(Pic32Peripherals_LCD_Bench_default_XC32_FILE_TYPE_assemble)
set_source_files_properties(${Pic32Peripherals_LCD_Bench_default_XC32_FILE_TYPE_assemble} PROPERTIES LANGUAGE ASM)

# For assembly files, add "." to the include path for each file so that .include with a relative path works
foreach(source_file ${Pic32Peripherals_LCD_Bench_default_XC32_FILE_TYPE_assemble})
        set_source_files_properties(${source_file} PROPERTIES INCLUDE_DIRECTORIES "$<PATH:NORMAL_PATH,$<PATH:REMOVE_FILENAME,${source_file}>>")
endforeach()

set(Pic32Peripherals_LCD_Bench_default_XC32_FILE_TYPE_assembleWithPreprocess)
set_source_files_properties(${Pic32Peripherals_LCD_Bench_default_XC32_FILE_TYPE_assembleWithPreprocess} PROPERTIES LANGUAGE ASM)

# For assembly files, add "." to the include path for each file so that .include with a relative path works
foreach(source_file ${Pic32Peripherals_LCD_Bench_default_XC32_FILE_TYPE_assembleWithPreprocess})
        set_source_files_properties(${source_file} PROPERTIES INCLUDE_DIRECTORIES "$<PATH:NORMAL_PATH,$<PATH:REMOVE_FILENAME,${source_file}>>")
endforeach()

set(Pic32Peripherals_LCD_Bench_default_XC32_FILE_TYPE_compile
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../src/DeviceConfig.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../src/heat_audio.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../src/heat_lcd.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../src/lcd_bench.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../src/st7789.c")
set_source_files_properties(${Pic32Peripherals_LCD_Bench_default_XC32_FILE_TYPE_compile} PROPERTIES LANGUAGE C)
set(Pic32Peripherals_LCD_Bench_default_XC32_FILE_TYPE_compile_cpp)
set_source_files_properties(${Pic32Peripherals_LCD_Bench_default_XC32_FILE_TYPE_compile_cpp} PROPERTIES LANGUAGE CXX)
set(Pic32Peripherals_LCD_Bench_default_XC32_FILE_TYPE_link)
set(Pic32Peripherals_LCD_Bench_image_name "LCD_Bench.elf")
set(Pic32Peripherals_LCD_Bench_image_base_name "LCD_Bench")

# The output directory of the final image.
set(Pic32Peripherals_LCD_Bench_output_dir "${CMAKE_CURRENT_SOURCE_DIR}/../../../build/firmware")

# The full path to the final image.
set(Pic32Peripherals_LCD_Bench_full_path_to_image ${Pic32Peripherals_LCD_Bench_output_dir}/${Pic32Peripherals_LCD_Bench_image_name})
