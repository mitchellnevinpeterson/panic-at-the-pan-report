set(DEPENDENT_MP_BIN2HEXPic32Peripherals_Ultrasonic_HCSR04_xYnfVIKA "/Applications/microchip/xc32/v6.00/bin/xc32-bin2hex")
set(DEPENDENT_DEPENDENT_TARGET_ELFPic32Peripherals_Ultrasonic_HCSR04_xYnfVIKA ${CMAKE_CURRENT_LIST_DIR}/../../../../build/firmware/Ultrasonic_HCSR04.elf)
set(DEPENDENT_TARGET_DIRPic32Peripherals_Ultrasonic_HCSR04_xYnfVIKA ${CMAKE_CURRENT_LIST_DIR}/../../../../build/firmware)
set(DEPENDENT_BYPRODUCTSPic32Peripherals_Ultrasonic_HCSR04_xYnfVIKA ${DEPENDENT_TARGET_DIRPic32Peripherals_Ultrasonic_HCSR04_xYnfVIKA}/${sourceFileNamePic32Peripherals_Ultrasonic_HCSR04_xYnfVIKA}.c)
add_custom_command(
    OUTPUT ${DEPENDENT_TARGET_DIRPic32Peripherals_Ultrasonic_HCSR04_xYnfVIKA}/${sourceFileNamePic32Peripherals_Ultrasonic_HCSR04_xYnfVIKA}.c
    COMMAND ${DEPENDENT_MP_BIN2HEXPic32Peripherals_Ultrasonic_HCSR04_xYnfVIKA} --image ${DEPENDENT_DEPENDENT_TARGET_ELFPic32Peripherals_Ultrasonic_HCSR04_xYnfVIKA} --image-generated-c ${sourceFileNamePic32Peripherals_Ultrasonic_HCSR04_xYnfVIKA}.c --image-generated-h ${sourceFileNamePic32Peripherals_Ultrasonic_HCSR04_xYnfVIKA}.h --image-copy-mode ${modePic32Peripherals_Ultrasonic_HCSR04_xYnfVIKA} --image-offset ${addressPic32Peripherals_Ultrasonic_HCSR04_xYnfVIKA} 
    WORKING_DIRECTORY ${DEPENDENT_TARGET_DIRPic32Peripherals_Ultrasonic_HCSR04_xYnfVIKA}
    DEPENDS ${DEPENDENT_DEPENDENT_TARGET_ELFPic32Peripherals_Ultrasonic_HCSR04_xYnfVIKA})
add_custom_target(
    dependent_produced_source_artifactPic32Peripherals_Ultrasonic_HCSR04_xYnfVIKA 
    DEPENDS ${DEPENDENT_TARGET_DIRPic32Peripherals_Ultrasonic_HCSR04_xYnfVIKA}/${sourceFileNamePic32Peripherals_Ultrasonic_HCSR04_xYnfVIKA}.c
    )
