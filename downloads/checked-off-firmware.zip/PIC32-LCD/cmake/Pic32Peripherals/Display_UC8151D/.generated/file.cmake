# The following variables contains the files used by the different stages of the build process.
set(Pic32Peripherals_Display_UC8151D_default_XC32_FILE_TYPE_assemble)
set_source_files_properties(${Pic32Peripherals_Display_UC8151D_default_XC32_FILE_TYPE_assemble} PROPERTIES LANGUAGE ASM)

# For assembly files, add "." to the include path for each file so that .include with a relative path works
foreach(source_file ${Pic32Peripherals_Display_UC8151D_default_XC32_FILE_TYPE_assemble})
        set_source_files_properties(${source_file} PROPERTIES INCLUDE_DIRECTORIES "$<PATH:NORMAL_PATH,$<PATH:REMOVE_FILENAME,${source_file}>>")
endforeach()

set(Pic32Peripherals_Display_UC8151D_default_XC32_FILE_TYPE_assembleWithPreprocess)
set_source_files_properties(${Pic32Peripherals_Display_UC8151D_default_XC32_FILE_TYPE_assembleWithPreprocess} PROPERTIES LANGUAGE ASM)

# For assembly files, add "." to the include path for each file so that .include with a relative path works
foreach(source_file ${Pic32Peripherals_Display_UC8151D_default_XC32_FILE_TYPE_assembleWithPreprocess})
        set_source_files_properties(${source_file} PROPERTIES INCLUDE_DIRECTORIES "$<PATH:NORMAL_PATH,$<PATH:REMOVE_FILENAME,${source_file}>>")
endforeach()

set(Pic32Peripherals_Display_UC8151D_default_XC32_FILE_TYPE_compile
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../src/DeviceConfig.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../src/display.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../src/heat_audio.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../src/ultrasonic.c")
set_source_files_properties(${Pic32Peripherals_Display_UC8151D_default_XC32_FILE_TYPE_compile} PROPERTIES LANGUAGE C)
set(Pic32Peripherals_Display_UC8151D_default_XC32_FILE_TYPE_compile_cpp)
set_source_files_properties(${Pic32Peripherals_Display_UC8151D_default_XC32_FILE_TYPE_compile_cpp} PROPERTIES LANGUAGE CXX)
set(Pic32Peripherals_Display_UC8151D_default_XC32_FILE_TYPE_link)
set(Pic32Peripherals_Display_UC8151D_image_name "Display_UC8151D.elf")
set(Pic32Peripherals_Display_UC8151D_image_base_name "Display_UC8151D")

# The output directory of the final image.
set(Pic32Peripherals_Display_UC8151D_output_dir "${CMAKE_CURRENT_SOURCE_DIR}/../../../build/firmware")

# The full path to the final image.
set(Pic32Peripherals_Display_UC8151D_full_path_to_image ${Pic32Peripherals_Display_UC8151D_output_dir}/${Pic32Peripherals_Display_UC8151D_image_name})
