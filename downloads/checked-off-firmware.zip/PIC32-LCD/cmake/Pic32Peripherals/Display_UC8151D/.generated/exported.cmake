set(DEPENDENT_MP_BIN2HEXPic32Peripherals_Display_UC8151D_oALbnVoN "/Applications/microchip/xc32/v6.00/bin/xc32-bin2hex")
set(DEPENDENT_DEPENDENT_TARGET_ELFPic32Peripherals_Display_UC8151D_oALbnVoN ${CMAKE_CURRENT_LIST_DIR}/../../../../build/firmware/Display_UC8151D.elf)
set(DEPENDENT_TARGET_DIRPic32Peripherals_Display_UC8151D_oALbnVoN ${CMAKE_CURRENT_LIST_DIR}/../../../../build/firmware)
set(DEPENDENT_BYPRODUCTSPic32Peripherals_Display_UC8151D_oALbnVoN ${DEPENDENT_TARGET_DIRPic32Peripherals_Display_UC8151D_oALbnVoN}/${sourceFileNamePic32Peripherals_Display_UC8151D_oALbnVoN}.c)
add_custom_command(
    OUTPUT ${DEPENDENT_TARGET_DIRPic32Peripherals_Display_UC8151D_oALbnVoN}/${sourceFileNamePic32Peripherals_Display_UC8151D_oALbnVoN}.c
    COMMAND ${DEPENDENT_MP_BIN2HEXPic32Peripherals_Display_UC8151D_oALbnVoN} --image ${DEPENDENT_DEPENDENT_TARGET_ELFPic32Peripherals_Display_UC8151D_oALbnVoN} --image-generated-c ${sourceFileNamePic32Peripherals_Display_UC8151D_oALbnVoN}.c --image-generated-h ${sourceFileNamePic32Peripherals_Display_UC8151D_oALbnVoN}.h --image-copy-mode ${modePic32Peripherals_Display_UC8151D_oALbnVoN} --image-offset ${addressPic32Peripherals_Display_UC8151D_oALbnVoN} 
    WORKING_DIRECTORY ${DEPENDENT_TARGET_DIRPic32Peripherals_Display_UC8151D_oALbnVoN}
    DEPENDS ${DEPENDENT_DEPENDENT_TARGET_ELFPic32Peripherals_Display_UC8151D_oALbnVoN})
add_custom_target(
    dependent_produced_source_artifactPic32Peripherals_Display_UC8151D_oALbnVoN 
    DEPENDS ${DEPENDENT_TARGET_DIRPic32Peripherals_Display_UC8151D_oALbnVoN}/${sourceFileNamePic32Peripherals_Display_UC8151D_oALbnVoN}.c
    )
