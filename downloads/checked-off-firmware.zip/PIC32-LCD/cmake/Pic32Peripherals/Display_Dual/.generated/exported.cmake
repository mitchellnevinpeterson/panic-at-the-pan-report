set(DEPENDENT_MP_BIN2HEXPic32Peripherals_Display_Dual_6nWcZwt2 "/Applications/microchip/xc32/v6.00/bin/xc32-bin2hex")
set(DEPENDENT_DEPENDENT_TARGET_ELFPic32Peripherals_Display_Dual_6nWcZwt2 ${CMAKE_CURRENT_LIST_DIR}/../../../../build/firmware/Display_Dual.elf)
set(DEPENDENT_TARGET_DIRPic32Peripherals_Display_Dual_6nWcZwt2 ${CMAKE_CURRENT_LIST_DIR}/../../../../build/firmware)
set(DEPENDENT_BYPRODUCTSPic32Peripherals_Display_Dual_6nWcZwt2 ${DEPENDENT_TARGET_DIRPic32Peripherals_Display_Dual_6nWcZwt2}/${sourceFileNamePic32Peripherals_Display_Dual_6nWcZwt2}.c)
add_custom_command(
    OUTPUT ${DEPENDENT_TARGET_DIRPic32Peripherals_Display_Dual_6nWcZwt2}/${sourceFileNamePic32Peripherals_Display_Dual_6nWcZwt2}.c
    COMMAND ${DEPENDENT_MP_BIN2HEXPic32Peripherals_Display_Dual_6nWcZwt2} --image ${DEPENDENT_DEPENDENT_TARGET_ELFPic32Peripherals_Display_Dual_6nWcZwt2} --image-generated-c ${sourceFileNamePic32Peripherals_Display_Dual_6nWcZwt2}.c --image-generated-h ${sourceFileNamePic32Peripherals_Display_Dual_6nWcZwt2}.h --image-copy-mode ${modePic32Peripherals_Display_Dual_6nWcZwt2} --image-offset ${addressPic32Peripherals_Display_Dual_6nWcZwt2} 
    WORKING_DIRECTORY ${DEPENDENT_TARGET_DIRPic32Peripherals_Display_Dual_6nWcZwt2}
    DEPENDS ${DEPENDENT_DEPENDENT_TARGET_ELFPic32Peripherals_Display_Dual_6nWcZwt2})
add_custom_target(
    dependent_produced_source_artifactPic32Peripherals_Display_Dual_6nWcZwt2 
    DEPENDS ${DEPENDENT_TARGET_DIRPic32Peripherals_Display_Dual_6nWcZwt2}/${sourceFileNamePic32Peripherals_Display_Dual_6nWcZwt2}.c
    )
