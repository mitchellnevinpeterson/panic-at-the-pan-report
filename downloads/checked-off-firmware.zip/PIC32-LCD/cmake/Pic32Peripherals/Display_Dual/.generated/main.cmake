include("${CMAKE_CURRENT_LIST_DIR}/rule.cmake")
include("${CMAKE_CURRENT_LIST_DIR}/file.cmake")

set(Pic32Peripherals_Display_Dual_library_list )

set(OUTPUT_SUFFIX elf)
# Handle files with suffix s, for group default-XC32
if(Pic32Peripherals_Display_Dual_default_XC32_FILE_TYPE_assemble)
add_library(Pic32Peripherals_Display_Dual_default_XC32_assemble OBJECT ${Pic32Peripherals_Display_Dual_default_XC32_FILE_TYPE_assemble})
    Pic32Peripherals_Display_Dual_default_XC32_assemble_rule(Pic32Peripherals_Display_Dual_default_XC32_assemble)
    list(APPEND Pic32Peripherals_Display_Dual_library_list "$<TARGET_OBJECTS:Pic32Peripherals_Display_Dual_default_XC32_assemble>")

endif()

# Handle files with suffix S, for group default-XC32
if(Pic32Peripherals_Display_Dual_default_XC32_FILE_TYPE_assembleWithPreprocess)
add_library(Pic32Peripherals_Display_Dual_default_XC32_assembleWithPreprocess OBJECT ${Pic32Peripherals_Display_Dual_default_XC32_FILE_TYPE_assembleWithPreprocess})
    Pic32Peripherals_Display_Dual_default_XC32_assembleWithPreprocess_rule(Pic32Peripherals_Display_Dual_default_XC32_assembleWithPreprocess)
    list(APPEND Pic32Peripherals_Display_Dual_library_list "$<TARGET_OBJECTS:Pic32Peripherals_Display_Dual_default_XC32_assembleWithPreprocess>")

endif()

# Handle files with suffix [cC], for group default-XC32
if(Pic32Peripherals_Display_Dual_default_XC32_FILE_TYPE_compile)
add_library(Pic32Peripherals_Display_Dual_default_XC32_compile OBJECT ${Pic32Peripherals_Display_Dual_default_XC32_FILE_TYPE_compile})
    Pic32Peripherals_Display_Dual_default_XC32_compile_rule(Pic32Peripherals_Display_Dual_default_XC32_compile)
    list(APPEND Pic32Peripherals_Display_Dual_library_list "$<TARGET_OBJECTS:Pic32Peripherals_Display_Dual_default_XC32_compile>")

endif()

# Handle files with suffix cpp, for group default-XC32
if(Pic32Peripherals_Display_Dual_default_XC32_FILE_TYPE_compile_cpp)
add_library(Pic32Peripherals_Display_Dual_default_XC32_compile_cpp OBJECT ${Pic32Peripherals_Display_Dual_default_XC32_FILE_TYPE_compile_cpp})
    Pic32Peripherals_Display_Dual_default_XC32_compile_cpp_rule(Pic32Peripherals_Display_Dual_default_XC32_compile_cpp)
    list(APPEND Pic32Peripherals_Display_Dual_library_list "$<TARGET_OBJECTS:Pic32Peripherals_Display_Dual_default_XC32_compile_cpp>")

endif()

# Handle files with suffix [cC], for group default-XC32
if(Pic32Peripherals_Display_Dual_default_XC32_FILE_TYPE_dependentObject)
add_library(Pic32Peripherals_Display_Dual_default_XC32_dependentObject OBJECT ${Pic32Peripherals_Display_Dual_default_XC32_FILE_TYPE_dependentObject})
    Pic32Peripherals_Display_Dual_default_XC32_dependentObject_rule(Pic32Peripherals_Display_Dual_default_XC32_dependentObject)
    list(APPEND Pic32Peripherals_Display_Dual_library_list "$<TARGET_OBJECTS:Pic32Peripherals_Display_Dual_default_XC32_dependentObject>")

endif()


# Main target for this project
add_executable(Pic32Peripherals_Display_Dual_image_6nWcZwt2 ${Pic32Peripherals_Display_Dual_library_list})

set_target_properties(Pic32Peripherals_Display_Dual_image_6nWcZwt2 PROPERTIES
    OUTPUT_NAME "Display_Dual"
    SUFFIX ".elf"
    RUNTIME_OUTPUT_DIRECTORY "${Pic32Peripherals_Display_Dual_output_dir}")
target_link_libraries(Pic32Peripherals_Display_Dual_image_6nWcZwt2 PRIVATE ${Pic32Peripherals_Display_Dual_default_XC32_FILE_TYPE_link})
# Add the link options from the rule file.
Pic32Peripherals_Display_Dual_link_rule( Pic32Peripherals_Display_Dual_image_6nWcZwt2)

# Add bin2hex target for converting built file to a .hex file.
string(REGEX REPLACE [.]elf$ .hex Pic32Peripherals_Display_Dual_image_name_hex ${Pic32Peripherals_Display_Dual_image_name})
add_custom_target(Pic32Peripherals_Display_Dual_Bin2Hex ALL
    COMMAND ${MP_BIN2HEX} \"${Pic32Peripherals_Display_Dual_output_dir}/${Pic32Peripherals_Display_Dual_image_name}\"
    DEPENDS "${Pic32Peripherals_Display_Dual_output_dir}/${Pic32Peripherals_Display_Dual_image_name}"
    BYPRODUCTS ${Pic32Peripherals_Display_Dual_output_dir}/${Pic32Peripherals_Display_Dual_image_name_hex}
    COMMENT "Convert built file to .hex")
add_dependencies(Pic32Peripherals_Display_Dual_Bin2Hex Pic32Peripherals_Display_Dual_image_6nWcZwt2)




